using System;
using System.Web;
using Telerik.Events;

namespace SEVDNUG.Web.HttpHandlers
{
    ///<summary>
    /// Provides a <see cref="IHttpHandler"/> to generate an ICalendar file for the specified event.
    ///</summary>
    public class CalendarHandler : IHttpHandler
    {

        #region IHttpHandler Implementation

        ///<summary>
        /// Handles the Http request
        ///</summary>
        ///<param name="context">The <see cref="HttpContext"/>.</param>
        public void ProcessRequest(HttpContext context)
        {

            try
            {
                vCalendar calendar = new vCalendar();
                EventsManager eventsManager = new EventsManager("Events");
                string domain = context.Request.Url.GetLeftPart(UriPartial.Authority);

                foreach (IEvent eventItem in eventsManager.GetEvents())
                {
                    calendar.Events.Add(createEvent(eventItem, domain));
                }
                // Write out the response
                outputFile(context.Response, calendar.ToString());
            }
            catch (Exception ex)
            {
                context.Response.Write(ex.ToString());
            }
        }

        ///<summary>
        /// Indicates if the <see cref="IHttpHandler"/> is reusable.
        ///</summary>
        public bool IsReusable
        {
            get { return true; }
        }

        #endregion IHttpHandler Implementation


        private static vCalendar.vEvent createEvent(IEvent eventItem, string domain)
        {
            
            vCalendar.vEvent calendarEvent = new vCalendar.vEvent();

            // This is available from the event object
            calendarEvent.DTStart = eventItem.Start;
            calendarEvent.DTEnd = eventItem.End;

            // Get the rest from the ContentItem
            if (eventItem.ContentItem.Content != null)
                calendarEvent.Description = eventItem.ContentItem.Content.ToString();
            calendarEvent.Location = eventItem.ContentItem.GetMetaData("LocationName").ToString();
            calendarEvent.Summary = eventItem.ContentItem.GetMetaData("Title").ToString();
            calendarEvent.UID = eventItem.ID.ToString();
            calendarEvent.URL =  domain + eventItem.ContentItem.UrlWithExtension;
            calendarEvent.LastModified = eventItem.ContentItem.DateModified;
            calendarEvent.Created = eventItem.ContentItem.DateCreated;

            return calendarEvent;
        }

        /// <summary>
        /// Writes the iCal text out to the browser.
        /// </summary>
        /// <param name="response">The <see cref="HttpResponse"/> object</param>
        /// <param name="calendar">The calendar to output.</param>
        private static void outputFile(HttpResponse response, string calendar)
        {
            response.Clear();
            response.ContentType = "text/calendar";
            response.AddHeader("Content-Disposition", "attachment;filename=events.ics");
            response.Write(calendar);
        }

    }
}
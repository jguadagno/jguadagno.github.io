﻿using System;
using System.ComponentModel;
using System.IO;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik;
using Telerik.Cms.Engine;
using Telerik.Cms.Web.UI;
using Telerik.Web;

namespace SEVDNUG.Web.Sitefinity.WebControls
{
    ///<summary>
    /// Displays random Generic Content.
    ///</summary>
    [ToolboxData("<{0}:RandomGCContent runat=\"server\"></{0}:RandomGCContent>"), DisplayName("Random Generic Content")]
    public class RandomGCContent : CompositeControl
    {

        #region Variables
        // Internal variables
        private static int gcCount;
        private IList<IContent> _dataSource;

        // Default values
        private const int DEFAULT_NUMBER_OF_ITEMS = 3;
        private const string DEFAULT_PROVIDER_NAME = "";
        private const string DEFAULT_ITEMLIST_TEMPLATE_FILE = "~/Sitefinity/UserControls/SEVDNUG/RandomGCContent.ascx";
        private const string DEFAULT_DATE_FORMAT_STRING = "";
        private const string DEFAULT_SINGLE_ITEM_URL = "~/Sitefinity/ControlTemplates/Generic_Content/ContentViewSingleItem.ascx";

        // Property Variables
        private ContentManager _manager;
        private ITemplate _itemListTemplate;
        private ItemListContainer _itemListContainer;

        private int _numberOfItems = DEFAULT_NUMBER_OF_ITEMS;
        private string _providerName = DEFAULT_PROVIDER_NAME;
        private string _itemListTemplateFile = DEFAULT_ITEMLIST_TEMPLATE_FILE;
        private string _dateFormatString = DEFAULT_DATE_FORMAT_STRING;
        private string _singleItemUrl = DEFAULT_SINGLE_ITEM_URL;

        #endregion Variables

        #region System.Web.UI.Controls methods

        /// <summary>
        /// Called by the ASP.NET page framework to notify server controls that use composition-based implementation to create any child controls they contain in preparation for posting back or rendering.
        /// </summary>
        protected override void CreateChildControls()
        {
            initializeGCManager();
            _itemListContainer = new ItemListContainer(this);
            if (_itemListTemplate == null)
            {
                string templateFile = _itemListTemplateFile;
                if (DesignMode)
                {
                    _itemListTemplate = new Page().LoadTemplate(templateFile);
                }
                else if (Page != null)
                {
                    if (File.Exists(Page.MapPath(templateFile)))
                    {
                        _itemListTemplate = Page.LoadTemplate(templateFile);
                    }
                    else
                    {
                        _itemListTemplate = new Telerik.Cms.Engine.WebControls.DefaultTemplate();
                    }
                }
            }

            ItemListTemplate.InstantiateIn(_itemListContainer);
            
            _dataSource = GetRandomGCItems(NumberOfItems);

            if ((_dataSource.Count > 0) && Visible)
            {
                _itemListContainer.RepeaterControl.DataSource = _dataSource;
                _itemListContainer.RepeaterControl.ItemDataBound += new RepeaterItemEventHandler(_repeaterControl_ItemDataBound);
                _itemListContainer.RepeaterControl.DataBind();
            }
            else
            {
                _itemListContainer.RepeaterControl.Visible = false;
            }

            Controls.Add(_itemListContainer);
            if (Page != null)
            {
                Page.MaintainScrollPositionOnPostBack = true;
            }
        }

        /// <summary>
        /// Gets the <see cref="T:System.Web.UI.HtmlTextWriterTag"/> value that corresponds to this Web server control. This property is used primarily by control developers.
        /// </summary>
        /// <value></value>
        /// <returns>One of the <see cref="T:System.Web.UI.HtmlTextWriterTag"/> enumeration values.</returns>
        protected override HtmlTextWriterTag TagKey
        {
            get
            {
                return HtmlTextWriterTag.Div;
            }
        }

        /// <summary>
        /// Restores control-state information from a previous page request that was saved by the <see cref="M:System.Web.UI.Control.SaveControlState"/> method.
        /// </summary>
        /// <param name="savedState">An <see cref="T:System.Object"/> that represents the control state to be restored.</param>
        protected override void LoadControlState(object savedState)
        {
            if (savedState != null)
            {
                object[] objArray = (object[])savedState;
                ProviderName = (string)objArray[0];
                NumberOfItems = (int)objArray[1];
                ItemListTemplateFile = (string) objArray[2];
                SingleItemUrl = (string) objArray[3];
            }
        }

        /// <summary>
        /// Saves any server control state changes that have occurred since the time the page was posted back to the server.
        /// </summary>
        /// <returns>
        /// Returns the server control's current state. If there is no state associated with the control, this method returns null.
        /// </returns>
        protected override object SaveControlState()
        {
            return new object[] { ProviderName, NumberOfItems, ItemListTemplateFile, SingleItemUrl };
        }

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.Init"/> event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"/> object that contains the event data.</param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (base.Page != null)
            {
                base.Page.RegisterRequiresControlState(this);
            }
            initializeGCManager();
            initializeGCCount();
        }

        /// <summary>
        /// Renders the HTML opening tag of the control to the specified writer. This method is used primarily by control developers.
        /// </summary>
        /// <param name="writer">A <see cref="T:System.Web.UI.HtmlTextWriter"/> that represents the output stream to render HTML content on the client.</param>
        public override void RenderBeginTag(HtmlTextWriter writer)
        {
            if (Controls.Count > 0)
            {
                base.RenderBeginTag(writer);
            }
        }

        /// <summary>
        /// Renders the HTML closing tag of the control into the specified writer. This method is used primarily by control developers.
        /// </summary>
        /// <param name="writer">A <see cref="T:System.Web.UI.HtmlTextWriter"/> that represents the output stream to render HTML content on the client.</param>
        public override void RenderEndTag(HtmlTextWriter writer)
        {
            if (Controls.Count > 0)
            {
                base.RenderEndTag(writer);
            }
        }

        #endregion System.Web.UI.Controls methods

        #region Events

        private void _repeaterControl_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            switch (e.Item.ItemType)
            {
                case ListItemType.Header:
                    break;
                case ListItemType.AlternatingItem:
                case ListItemType.Item:
                    {
                        IContent dataItem = (IContent)e.Item.DataItem;
                        string itemUrl = getItemUrl(dataItem, SingleItemUrl);

                        // Update the Content
                        Control ctrl = e.Item.FindControl("content");
                        if (ctrl != null)
                            ((ITextControl) ctrl).Text = dataItem.Content.ToString();

                        // Create the single item urls
                        for (int i = 1; i < 6; i++ )
                        {
                            Control c = e.Item.FindControl("fullContent" + i);
                            if (!(c is HyperLink))
                            {
                                break;
                            }
                            ((HyperLink) c).NavigateUrl = itemUrl;
                        }
                        
                        // Set the meta data content
                        SetItemMetadata(e.Item, dataItem);
                    }
                    break;
                case ListItemType.Footer:
                    break;
            }
        }

        /// <summary>
        /// Handles the Executed event of the contentManager control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="Telerik.ExecutedEventArgs"/> instance containing the event data.</param>
        protected void ContentManager_Executed(object sender, ExecutedEventArgs e)
        {
            gcCount = Manager.GetContent().Count;
        }

        #endregion Events

        #region Private Methods

        /// <summary>
        /// Initializes the Generic Content manager.
        /// </summary>
        private void initializeGCManager()
        {
            if ((_manager == null) || (_manager.Provider.Name != ProviderName))
            {
                Manager = new ContentManager(ProviderName);
            }
        }

        /// <summary>
        /// Initializes the GC count.
        /// </summary>
        private void initializeGCCount()
        {

            ManagerBase<ContentProviderBase>.Executed += new EventHandler<Telerik.ExecutedEventArgs>(ContentManager_Executed);
            if (gcCount == 0)
            {
                gcCount = Manager.GetContent().Count;
            }
        }

        /// <summary>
        /// Sets the item meta data.
        /// </summary>
        /// <param name="itemContainer">The item container.</param>
        /// <param name="contentItem">The content item.</param>
        protected virtual void SetItemMetadata(Control itemContainer, IContent contentItem)
        {
            ICollection<IMetaInfo> keys = Manager.MetaKeys.Values;
            foreach (IMetaInfo info in keys)
            {
                DateTime time;
                Control control = itemContainer.FindControl(info.Key);
                if (control != null)
                {
                    switch (info.ValueType)
                    {
                        case MetaValueTypes.ShortText:
                        case MetaValueTypes.LongText:
                            {
                                if (!(control is ITextControl))
                                {
                                    goto Label_0080;
                                }
                                ((ITextControl)control).Text = (string)contentItem.GetMetaData(info.Key);
                                continue;
                            }
                        case MetaValueTypes.DateTime:
                            goto Label_00A9;
                    }
                }
                continue;
            Label_0080:
                if (control is HyperLink)
                {
                    ((HyperLink)control).Text = (string)contentItem.GetMetaData(info.Key);
                }
                continue;
            Label_00A9:
                time = (DateTime)contentItem.GetMetaData(info.Key);
                if (control is DateTimeLiteral)
                {
                    DateTimeLiteral literal = (DateTimeLiteral)control;
                    if (!string.IsNullOrEmpty(DateFormatString))
                    {
                        literal.DateFormatString = DateFormatString;
                    }
                    literal.Date = time;
                    continue;
                }
                if (control is ITextControl)
                {
                    ((ITextControl)control).Text = time.ToString(DateFormatString);
                }
            }
        }

        ///<summary>
        ///Returns a random list of <see cref="IContent"/>
        ///</summary>
        ///<param name="count">The total number to return</param>
        ///<returns>A <see cref="IList{T}"/> of Generic Content items.</returns>
        protected IList<IContent> GetRandomGCItems(int count)
        {
            List<IContent> randomItems = new List<IContent>();

            int totalContentCount = gcCount;

            if (count > totalContentCount) count = totalContentCount;

            Random randomGenerator = new Random();
            for (int i = 0; i < count; i++)
            {
                int randomNum = randomGenerator.Next(0, totalContentCount); // index
                IContent rndCnt = (IContent)(Manager.GetContent(randomNum, randomNum + 1)[0]);
                if (!randomItems.Contains(rndCnt))
                    randomItems.Add(rndCnt);
                else
                    i--;
            }

            return randomItems;
        }

        /// <summary>
        /// Gets the item URL.
        /// </summary>
        /// <param name="contentItem">The content.</param>
        /// <param name="singleItemUrl">The single item URL.</param>
        /// <returns></returns>
        private string getItemUrl(IContent contentItem, string singleItemUrl)
        {
            string str = string.Empty;
            string str2 = string.Empty;
            string path = singleItemUrl;

            if (string.IsNullOrEmpty(path) && (CmsContext.CurrentUrl != null))
            {
                path = CmsContext.CurrentUrl.Path;
            }
            else
            {
                str = "&";
                if (string.IsNullOrEmpty(Context.Request.QueryString["ReturnURL"]))
                {
                    str2 = "ReturnURL=" + Context.Server.UrlEncode(Context.Request.RawUrl);
                }
                else
                {
                    str2 = "ReturnURL=" + Context.Server.UrlEncode(Context.Request.QueryString["ReturnURL"]);
                }
            }
            if (string.IsNullOrEmpty(contentItem.Url))
            {
                int index = path.IndexOf('?');
                if (index != -1)
                {
                    path = path.Substring(0, index);
                }
                path = string.Concat(new object[] { path, "?", ContentProviderKey, "=", contentItem.ProviderName, "&", ContentItemKey, "=", contentItem.ID, str, str2 });
            }
            else
            {
                string str4 = contentItem.Url + Manager.Provider.ContentExtension;
                if (this.Manager.Provider.UrlFormatQueryStringIndex != -1)
                {
                    str4 = str4 + "?" + ContentUrlRewriterService.FormatURL(contentItem, Manager.Provider, ContentUrlRewriterService.FormatOptions.QueryString);
                }
                else if (str.Length > 0)
                {
                    str = "?";
                }
                if (!str4.StartsWith("~"))
                {
                    int length = path.LastIndexOf('.');
                    if (length != -1)
                    {
                        path = path.Substring(0, length);
                    }
                    else
                    {
                        length = path.IndexOf('?');
                        if (length != -1)
                        {
                            path = path.Substring(0, length);
                        }
                    }
                    str4 = VirtualPathUtility.RemoveTrailingSlash(path) + str4;
                }
                path = str4 + str + str2;
            }

            IUrlService languageService = UrlServices.GetLanguageService();
            if (languageService != null)
            {
                return languageService.ResolveLanguageUrl(path);
            }
            return path;

        }

        #endregion Private Methods

        #region Public Properties

        /// <summary>
        /// Gets / Sets the content manager
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Never)]
        public ContentManager Manager
        {
            get
            {
                initializeGCManager();
                return _manager;
            }
            set
            {
                _manager = value;
            }
        }

        /// <summary>
        /// Get / Sets the ProviderName to use
        /// </summary>
        [Category("Data")]
        public virtual string ProviderName
        {
            get
            {
                return _providerName;
            }
            set
            {
                _providerName = value;
            }
        }

        /// <summary>
        ///  Returns / sets the number of Generic Content items that should be returned.
        /// </summary>
        [Category("Data")]
        public int NumberOfItems
        {
            get
            {
                return _numberOfItems;
            }
            set
            {
                if (value < 0 )
                    throw new ArgumentOutOfRangeException("NumberOfItems", value, "The number of items can not be less than zero");
                _numberOfItems = value;
            }
        }

        /// <summary> 
        /// Gets or sets the template used by <see cref="RandomGCContent"/> control 
        /// </summary> 
        [Category("Appearance")]
        public ITemplate ItemListTemplate
        {
            get
            {
                return _itemListTemplate;
            }
            set
            {
                _itemListTemplate = value;
            }
        }

        /// <summary> 
        /// Gets or sets the path of the template used by <see cref="RandomGCContent"/> control 
        /// </summary> 
        [Category("Appearance")]
        public string ItemListTemplateFile
        {
            get
            {
                return _itemListTemplateFile;
            }
            set
            {
                _itemListTemplateFile = value;
            }
        }

        /// <summary>
        /// Gets or sets the single item URL.
        /// </summary>
        /// <value>The single item URL.</value>
        [Category("Appearance"), DisplayName("Generic Content Details URL") ]
        public string SingleItemUrl
        {
            get
            {
                return _singleItemUrl;
            }
            set
            {
                _singleItemUrl = value;
            }
        }

        /// <summary>
        /// Gets or sets the date format string.
        /// </summary>
        /// <value>The date format string.</value>
        [Category("Appearance"), DefaultValue("")]
        public virtual string DateFormatString
        {
            get
            {
                return _dateFormatString;
            }
            set
            {
                _dateFormatString = value;
            }
        }

        /// <summary>
        /// Gets or sets the content item key.
        /// </summary>
        /// <value>The content item key.</value>
        [Category("QueryString Keys"), DefaultValue((string)null)]
        public virtual string ContentItemKey
        {
            get
            {
                object obj2 = ViewState["ContentItemKey"];
                if (obj2 == null)
                {
                    return "CntItem";
                }
                return (string)obj2;
            }
            set
            {
                ViewState["ContentItemKey"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the content provider key.
        /// </summary>
        /// <value>The content provider key.</value>
        [DefaultValue((string)null), Category("QueryString Keys")]
        public virtual string ContentProviderKey
        {
            get
            {
                object obj2 = ViewState["ContentProviderKey"];
                if (obj2 == null)
                {
                    return "CntProv";
                }
                return (string)obj2;
            }
            set
            {
                ViewState["ContentProviderKey"] = value;
            }
        }

        #endregion Public Properties

        #region ItemListContainer
        /// <summary>
        /// The implementation of the Item List for the Generic Content
        /// </summary>
        protected class ItemListContainer: GenericContainer<RandomGCContent>
        {
            #region Private Variables

            // Variables for controls
            private Repeater _repeater;
            private const string REPEATER_NAME = "GCRepeater";

            private bool _optionalControlsLoaded;

            #endregion Private Variables

            #region Constructors
            /// <summary>
            /// Initializes a new instance of the <see cref="ItemListContainer"/> class.
            /// </summary>
            /// <param name="owner">The owner.</param>
            public ItemListContainer(RandomGCContent owner) : base(owner)
            {
                
            }
            #endregion Constructors

            /// <summary>
            /// Loads the optional controls.
            /// </summary>
            protected virtual void LoadOptionalControls()
            {
                if (!_optionalControlsLoaded)
                {

                    _optionalControlsLoaded = true;
                }
            }

            #region Properties
            /// <summary>
            /// Gets a value indicating whether [optional controls loaded].
            /// </summary>
            /// <value>
            /// 	<c>true</c> if [optional controls loaded]; otherwise, <c>false</c>.
            /// </value>
            protected bool OptionalControlsLoaded
            {
               get
               {
                   return _optionalControlsLoaded;
               }
            }

            #endregion Properties

            #region Properties for the optional controls
            

            #endregion Properties for the optional controls

            #region Properties for the Required Controls

            /// <summary>
            /// Gets the repeater control.
            /// </summary>
            /// <value>The repeater control.</value>
            public virtual Repeater RepeaterControl
            {
                get
                {
                    if (_repeater == null)
                    {
                        _repeater = FindRequiredControl<Repeater>(REPEATER_NAME);
                    }
                    return _repeater;
                }
            }

            #endregion Properties for the Required Controls

        }

        #endregion ItemListContainer

    }
}

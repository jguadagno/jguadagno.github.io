function GetServerTime_Sync()
{
	document.getElementById("spanTime").innerHTML = AjaxVB.WebForm1.GetServerTime().value;
}

function GetServerTime_Async()
{
	// Use asynchronize call
	document.getElementById("spanTime").innerHTML = 'Getting time';
	// NOTE Syntax <namespace>.<classname>.method (params, callbackfunction)
	AjaxVB.WebForm1.GetServerTime(GetServerTime_Async_Callback);
}

function GetServerTime_Async_Callback(response)
{
	
	document.getElementById("spanTime").innerHTML = response.value;

}
/// <summary>
/// A shortcut function to access the document.getElementById
/// </summary>
/// <param name="elem">The ID of the element you want to get
/// a DOM object for</param>
/// <returns>A DOM object if a match was found for the specified id.</returns>
function $g(elem)
{
	return document.getElementById(elem);
}

/// <summary>
/// A collection of helper functions.
/// </summary>
var Utility  = function () {
    /// <summary>
    /// Gets a DOM object from the parent or opening document
    /// </summary>
    /// <param name="elem">The ID of the element you want to get
    /// a DOM object for</param>
    /// <returns>A DOM object if a match was found for the specified id.</returns>
    this.getOpenerElem = function(Jb)
    {
	    return window.opener.document.getElementById(Jb);
    }
    /// <summary>
    /// Toggles the display of the of the specified DOM object.
    /// </summary>
    /// <param name="elemId">The ID of the DOM object to toggle.</param>
    this.ToggleDisplay = function (elemId) {
        var elem = $g(elemId);
 	    elem.style.display = (elem.style.display != 'none') ? 'none' : '';
 	}
 	
 	/// <summary>
    /// Sets the diplay style of the specified DOM element
    /// </summary>
    /// <param name="elemId">The ID of the DOM object or a DOM object.</param>
    /// <param name="v">A valid CSS display style, like 'block', 'inline' or 'none'.</param>
 	this.DisplayDiv = function (elemId, v) {
 	    var elem;
	    if (typeof(elemId) =='string')
		    elem = $g(elemId);
	    else
		    elem = elemId;
	    elem.style.display=v;
	}
	
 	/// <summary>
    /// Hides the specified div.
    /// </summary>
    /// <param name="elemId">The ID of the DOM object or a DOM object.</param>
 	this.HideDiv = function (elemId) {
 	    this.DisplayDiv(elemId, 'none');
 	}
 	/// <summary>
    /// Shows the specified div.
    /// </summary>
    /// <param name="elemId">The ID of the DOM object or a DOM object.</param>
 	this.ShowDiv = function (elemId) {
 	    this.DisplayDiv(elemId, '');
 	}
    
    /// <summary>
    /// The following are for browsers like NS4 or IE5Mac which don't support either
    /// attachEvent or addEventListener
    /// </summary>
    this.MyAttachEvent = function (obj,evt,fnc){
	    if (!obj.myEvents) obj.myEvents={};
	    if (!obj.myEvents[evt]) obj.myEvents[evt]=[];
	    var evts = obj.myEvents[evt];
	    evts[evts.length]=fnc;
    }
    
    /// <summary>
    /// Triggers an event.
    /// </summary>
    this.MyFireEvent = function (obj,evt){
	    if (!obj || !obj.myEvents || !obj.myEvents[evt]) return;
	    var evts = obj.myEvents[evt];
	    for (var i=0,len=evts.length;i<len;i++) evts[i]();
    }
    
    /// <summary>
    /// Attaches the event based on the browser.
    /// </summary>
    this.AttachEvent = function (obj,evt,fnc,useCapture){
	    if (!useCapture) useCapture=false;
	    if (obj.addEventListener){
		    obj.addEventListener(evt,fnc,useCapture);
		    return true;
	    } 
	    else if (obj.attachEvent) 
	        return obj.attachEvent("on"+evt,fnc);
	    else{
		    MyAttachEvent(obj,evt,fnc);
		    obj['on'+evt]=function(){ MyFireEvent(obj,evt) };
		}
	}
}

// Instantiate the Utility class
var Util = new Utility();



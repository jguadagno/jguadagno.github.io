function OnLoadPage404() {
	if (myGSearch == null)
	    // Required because within Internet Explorer 6 the
	    //  value of myGSearch is not created.
	    InitializeMyGSearch();
	// We want the main content to still display
	myGSearch.HideMainContent = false;
	// Execute the query
	myGSearch.Execute(lookForMe);
	// Call the OnBlur method so that the search button
	//  contains the correct CSS Style.
	OnBlur();
}

// The var lookForMe is used in OnLoadPage404 function to
//  search for the text.  You can provide a default value
//  for this.  In the ASPX demo it is set inside the 
//  Page_Load event.
var lookForMe="";
// Google helper method for Window.OnLoad.
google.setOnLoadCallback(OnLoadPage404);



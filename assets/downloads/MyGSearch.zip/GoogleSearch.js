﻿// This Global variable is used to reference the 
//  MyGSearch object.
var myGSearch;

/// <summary>
/// Initializes the myGSearch variable. Sets all of the properties that
///     are required for the google search to work.
/// </summary>
function InitializeMyGSearch() {
	
	if (myGSearch != null && myGSearch.IsInitialized == true)
	    return;
	
	myGSearch = new MyGSearch();
	// Initial the myGSearch object
	myGSearch.Initialize("divSearchResults", "txtSearchInput", "divGoogleBranding", "divMainContent", "divSearchStarting", "divSearchClose");
	// Sets the CSS Style for the watermarking.
	myGSearch.CSS.Watermark = 'watermark';
	myGSearch.CSS.InputBox = 'search';
	// Sets the watermark text.
	myGSearch.WatermarkText = 'Search for ...';
	
	// Hide all of the Search related divs.
	Util.HideDiv(myGSearch.Divs.SearchStarting);
	Util.HideDiv(myGSearch.Divs.SearchResults);
	Util.HideDiv(myGSearch.Divs.SearchClose);
	
	var input = myGSearch.SearchControl.input;
	// Hooks the blur event of the input object
	// This is used to implement the 'watermark' feature
	Util.AttachEvent(input, 'blur', OnBlur, false);
	Util.AttachEvent(input, 'focus', OnFocus, false)
	// Call the onInputBlur event so the watermark takes effect
	myGSearch.onInputBlur(myGSearch);
	
}

/// <summary>
/// Helper function to call the search objects ClearResults
/// </summary>
function ClearResults() {
	myGSearch.ClearResults();
}

/// <summary>
/// Helper function to call the execute method.  It used the
/// google search objects input field for the searching.
/// </summary>
function Search() {
    myGSearch.Execute(myGSearch.SearchControl.input.value);
}
/// <summary>
/// Calls the onInputBlur event of the Google Search object.
/// </summary>
function OnBlur() {
    myGSearch.onInputBlur(myGSearch);
}
/// <summary>
/// Calls the onInputFocus event of the Google Search object.
/// </summary>
function OnFocus() {
    myGSearch.onInputFocus(myGSearch);
}

// Loads all of the Google Search APIs
google.load("search", "1");
// Call a google helper function which will call
//  InitializeMyGSearch on the Windows.OnLoad event for the browser.
google.setOnLoadCallback(InitializeMyGSearch);

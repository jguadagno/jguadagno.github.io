/*
MyGSearch

MyGSearch is a helper object which wraps some of the Google
Search API (http://code.google.com/apis/ajaxsearch)

In order for this API to work you need to get your own 
Google API key.  The API key is placed in the calling HTML file.

Authored By Joseph Guadagno (http://wwww.josephguadagno.net)
jguadagno@hotmail.com.

Version: 1.0
Release: Oct 19, 2007

*/

/// <summary>

/// </summary>
function MyGSearch() {

    // ----------------------------------------
    // Properties
    // ----------------------------------------
    this.HideMainContent = true;
    this.SearchControl = null;
    this.WatermarkText = "Search for ...";
    this.IsInitialized = false;
    
    // Divs Property
    this.Divs = new Object();
    this.Divs.SearchResults = null;
    this.Divs.SearchInputBox = null;
    this.Divs.SearchBranding = null;
    this.Divs.SearchStarting = null;
    this.Divs.SearchClose = null;
    this.Divs.MainContent = null;
    
    // CSS Property
    this.CSS = new Object();
    this.CSS.Watermark = "";
    this.CSS.InputBox = "";
    
    // ----------------------------------------
    // Methods
    // ----------------------------------------
    
    /// <summary>
    /// Initialized the all of the properties and google.search object.
    /// </summary>
    /// <param name="resultsDiv">This is where all of the results will be placed
    /// by the Google Search API</param>
    /// <param name="inputBox">The input box that is used by the Google API to 
    /// execute the search.</param>
    /// <param name="brandingDiv">The div where the Google branding will be placed.
    ///  This is required by the Google API.</param>
    /// <param name="mainDiv">The main content div.  This is used to hide the div while
    ///  searching.</param>
    /// <param name="startSearchingDiv">This div will be displayed while the Google API
    /// is searching.</param>
    /// <param name="closeDiv">This div will be displayed after the Search is complete. 
    /// This allows you to essentially clear the google search results.</param>
    /// <returns></returns>
    this.Initialize = function (resultsDiv, inputBox, brandingDiv, mainDiv, startSearchingDiv, closeDiv) {
        // Set up the primary properties
        this.Divs.SearchResults = $g(resultsDiv);
        this.Divs.SearchInputBox = $g(inputBox);
        this.Divs.SearchBranding = $g(brandingDiv);
        this.Divs.MainContent = $g(mainDiv);
        this.Divs.SearchStarting = $g(startSearchingDiv);
        this.Divs.SearchClose = $g(closeDiv);
        
        // ************************
        // Start seting up the Google Search
        
        // Set up branding
        google.search.Search.getBranding(this.Divs.SearchBranding);
        // Create the "search form"
        this.SearchControl = new google.search.SearchControl();
        // Bind the searchComplete and searchStarting methods
        this.SearchControl.setSearchCompleteCallback(this, this.onSearchComplete);
        this.SearchControl.setSearchStartingCallback(this, this.onSearchStarting);
        // Set up the search result display options
        this.SearchControl.setResultSetSize(google.search.Search.LARGE_RESULTSET);
        this.SearchControl.setLinkTarget(google.search.Search.LINK_TARGET_BLANK);
        this.SearchControl.setNoResultsString("There are no results that match your query.");
        
        // *****************************
        // Create the Google Searcher(s)
        var searcher;
        var searcher2;
        
        // Add a search for the site search
        searcher = new google.search.WebSearch();
        // This is the label for the tab
        searcher.setUserDefinedLabel("JosephGuadagno.net");
        // This restricts the search to just josephguadagno.net
        searcher.setSiteRestriction("josephguadagno.net");

        // Add a search for the Internet
        searcher2 = new google.search.WebSearch();
        searcher2.setUserDefinedLabel("Internet Search");

        // now add the "searchers" to the google search control
        this.SearchControl.addSearcher(searcher);
        this.SearchControl.addSearcher(searcher2);
        
        //  assign some drawoptions to the searchcontrol
        var drawOptions = new google.search.DrawOptions();
        drawOptions.setDrawMode(google.search.SearchControl.DRAW_MODE_TABBED);
        drawOptions.setInput(this.Divs.SearchInputBox);

        // draw the control
        this.SearchControl.draw(this.Divs.SearchResults, drawOptions);
        
        this.IsInitialized = true;        
    }
    
    /// <summary>
    /// Clears the search results
    /// </summary>
    this.ClearResults = function () {
        
        this.SearchControl.clearAllResults();
	    Util.HideDiv(this.Divs.SearchClose);
	    this.onInputBlur(this);
    	
	    Util.HideDiv(this.Divs.SearchResults);
	    Util.ShowDiv(this.Divs.MainContent);
    }
    
    /// <summary>
    /// Executes the query specified
    /// </summary>
    this.Execute = function (query) {
       this.SearchControl.execute(query);
       this.onInputBlur(this);
       return false;
    }
    
    // ----------------------------------------
    // Events
    // ----------------------------------------
    
    /// <summary>
    /// This event is raised by the google.search component.  In it
    /// we will hide the SearchStarting div and show the SearchResults
    /// and SearchClose div.
    /// </summary>
    this.onSearchComplete = function (searchControl, searcher) {
        Util.HideDiv(this.Divs.SearchStarting);
	    Util.ShowDiv(this.Divs.SearchResults);
	    Util.ShowDiv(this.Divs.SearchClose);
	    if (this.HideMainContent)
		    Util.HideDiv(this.Divs.MainContent);
	    else
		    Util.ShowDiv(this.Divs.MainContent);
    }
    
    /// <summary>
    /// This event is raised by the google.search component. In it
    /// we will Hide the Main Content and show the SearchStarting Div
    /// </summary>
    this.onSearchStarting = function (searchControl, searcher, query) {
        // TODO: Use the query value for display
        Util.ShowDiv(this.Divs.SearchStarting);
        Util.HideDiv(this.Divs.MainContent);
    }
    
    /// <summary>
    /// This mimics the Ajax ASP.NET Watermark extender control by
    /// changing the CSS class of the SearchControls input based
    /// on the value of the input when you leave the input control.
    /// </summary>
    this.onInputBlur = function (gSearch) {
        var input = gSearch.SearchControl.input;
	
	    var searchText = input.value;
	    if (searchText == "")
	    {
		    gSearch.SearchControl.clearAllResults();
		    input.value = gSearch.WatermarkText;
		    input.className = gSearch.CSS.Watermark;
		    Util.HideDiv(gSearch.Divs.SearchClose);	
	    }
    }
    
    /// <summary>
    /// This mimics the Ajax ASP.NET Watermark extender control by
    /// changing the CSS class of the SearchControls input based
    /// on the value of the input when you enter the input control.
    /// </summary>
    this.onInputFocus = function (gSearch) {
        var input = gSearch.SearchControl.input;
        input.className = gSearch.CSS.InputBox;
        var searchText = input.value;
        if (searchText == gSearch.WatermarkText)
	        input.value = "";
    }

}
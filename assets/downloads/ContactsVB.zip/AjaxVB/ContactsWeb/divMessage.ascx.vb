
Imports System
Imports System.Data
Imports System.Drawing
Imports System.Web
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls

Namespace Contacts
   
   '/ <summary>
   '/		Summary description for divMessage.
   '/ </summary>
   
   Public Class divMessage
      Inherits System.Web.UI.UserControl
      
      
      Private Sub Page_Load(sender As Object, e As System.EventArgs)
      End Sub 'Page_Load
      ' Put user code to initialize the page here
      
#Region "Web Form Designer generated code"

        Protected Overrides Sub OnInit(ByVal e As EventArgs)
            '
            ' CODEGEN: This call is required by the ASP.NET Web Form Designer.
            '
            InitializeComponent()
            AddHandler Me.Load, AddressOf Page_Load
            MyBase.OnInit(e)
        End Sub 'OnInit


        '/ <summary>
        '/ Required method for Designer support - do not modify
        '/ the contents of this method with the code editor.
        '/ </summary>
        Private Sub InitializeComponent()
        End Sub 'InitializeComponent

#End Region
    End Class 'divMessage
End Namespace 'Contacts
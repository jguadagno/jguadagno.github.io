function LeagueClicked(s)
{
	DisplayMessage (msgTypePleaseWait, "Please wait... Loading Conferences...", "");
	var sId = s.value;
	var oControl = getElem("ddlTeam")
	if (oControl != null) oControl.length=0;
	oControl = getElem("ddlDivision");
	if (oControl != null) oControl.length=0;
	oControl = getElem("ddlConference");
	if (oControl != null) oControl.length=0;
	
	if (sId == "") return;
	Contacts.Sample9_Keydown.GetConferencesByLeague("", sId, CreateConference);
}
function ConferenceClicked(s)
{
	DisplayMessage (msgTypePleaseWait, "Please wait... Loading Conferences...", "");
	
	var sId = s.value;
	
	var oControl = getElem("ddlTeam")
	if (oControl != null) oControl.length=0;
	oControl = getElem("ddlDivision");
	if (oControl != null) oControl.length=0;
	
	if (sId == "") return;
	Contacts.Sample9_Keydown.GetDivisionsByConference("", sId,  CreateDivision);
}
function DivisionClicked(s)
{
	DisplayMessage (msgTypePleaseWait, "Please wait... Loading Conferences...", "");
	
	var sId = s.value;
	
	var oControl = getElem("ddlTeam")
	if (oControl != null) oControl.length=0;
	
	if (sId == "") return;
	Contacts.Sample9_Keydown.GetTeamsByDivision("", sId, CreateTeam);
}
function TeamClicked(s)
{
	DisplayMessage (msgTypeOk, "You selected " + s.options[s.selectedIndex].text + "(" + s.value + ")", "");
}

// Callback functions
function CreateConference(response)
{
	
	if (response.error != null)
	{
		DisplayMessage(msgTypeCritical, response.error, "LeagueClicked");
		return;
	}

	if (response.value == null)
	{
		// Nothing returned from the server
		return;
	}

	oControl = getElem("divConference");
	oControl.innerHTML = response.value;
	
	oControl = null;
	response = null;
	
	DisplayMessage(msgTypeSuccessComplete, "Load was successful!", "");

}
function CreateDivision(response)
{
	
	if (response.error != null)
	{
		DisplayMessage(msgTypeCritical, response.error, "ConferenceClicked");
		return;
	}

	if (response.value == null)
	{
		// Nothing returned from the server
		return;
	}

	oControl = getElem("divDivision");
	oControl.innerHTML = response.value;
	
	oControl = null;
	response = null;
	
	DisplayMessage(msgTypeSuccessComplete, "Load was successful!", "");


}
function CreateTeam(response)
{

	if (response.error != null)
	{
		DisplayMessage(msgTypeCritical, response.error, "DivisionClicked");
		return;
	}

	if (response.value == null)
	{
		// Nothing returned from the server
		return;
	}

	oControl = getElem("divTeam");
	oControl.innerHTML = response.value;
	
	oControl = null;
	response = null;

	
	DisplayMessage(msgTypeSuccessComplete, "Load was successful!", "");
}


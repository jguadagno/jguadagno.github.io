
Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Web
Imports System.Web.SessionState
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls


Namespace Contacts
   '/ <summary>
   '/ Ajax Post Backs
   '/ </summary>
   
   Public Class Sample5a_ComboBoxes
      Inherits System.Web.UI.Page
      Protected ddlLeague As System.Web.UI.WebControls.DropDownList
      
      
      Private Sub Page_Load(sender As Object, e As System.EventArgs)
         
         AjaxPro.Utility.RegisterTypeForAjax(GetType(Contacts.Sample5a_ComboBoxes))
         If Not Page.IsPostBack Then
            LoadControls()
         End If
      End Sub 'Page_Load
       
      Public Sub LoadControls()
         Dim dsLeague As DataSet = Sport.LoadLeagues()
         'DataSet dsConference = Sport.LoadConferences();
         'DataSet dsDivision = Sport.LoadDivisions();
         'DataSet dsTeam = Sport.LoadTeams();
         Utility.DBHelper.AddBlankRowsToTable(dsLeague.Tables(0))
            Utility.utility.BindDataSet(dsLeague, ddlLeague, "LeagueName", "LeagueId")
            Utility.utility.SelectComboboxItemByValue(ddlLeague, "")
         ddlLeague.Attributes("onchange") = "LeagueClicked(this);"
         
         dsLeague.Dispose()
         dsLeague = Nothing
      End Sub 'LoadControls 
      
      
      
#Region "Web Form Designer generated code"

        Protected Overrides Sub OnInit(ByVal e As EventArgs)
            '
            ' CODEGEN: This call is required by the ASP.NET Web Form Designer.
            '
            InitializeComponent()
            AddHandler Me.Load, AddressOf Page_Load
            MyBase.OnInit(e)
        End Sub 'OnInit


        '/ <summary>
        '/ Required method for Designer support - do not modify
        '/ the contents of this method with the code editor.
        '/ </summary>
        Private Sub InitializeComponent()
        End Sub 'InitializeComponent

#End Region

#Region "Ajax Methods"


        <AjaxPro.AjaxMethod()> _
        Public Function GetConferenceByLeague(ByVal LeagueId As Integer) As DataSet
            Return Sport.LoadConferenceByLeague(LeagueId)
        End Function 'GetConferenceByLeague

        <AjaxPro.AjaxMethod()> _
        Public Function GetDivisionByConference(ByVal ConferenceId As Integer) As DataSet
            Return Sport.LoadDivisionsByConference(ConferenceId)
        End Function 'GetDivisionByConference

        <AjaxPro.AjaxMethod()> _
        Public Function GetTeamsByDivision(ByVal DivisionId As Integer) As DataSet
            Return Sport.LoadTeamsByDivision(DivisionId)
        End Function 'GetTeamsByDivision

#End Region
    End Class 'Sample5a_ComboBoxes 
End Namespace 'Contacts
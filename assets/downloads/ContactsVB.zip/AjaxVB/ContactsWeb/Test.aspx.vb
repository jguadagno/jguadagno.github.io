
Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Web
Imports System.Web.SessionState
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls


Namespace Contacts
   '/ <summary>
   '/ Summary description for Test.
   '/ </summary>
   
   Public Class Test
      Inherits System.Web.UI.Page
      Protected ddlGetCities As System.Web.UI.WebControls.DropDownList
      Protected ddlGetStates As System.Web.UI.WebControls.DropDownList
      Protected ddlGetZipCodes As System.Web.UI.WebControls.DropDownList
      Protected ddlLookupCityByName As System.Web.UI.WebControls.DropDownList
      Protected ddlLookupZipCodeByZipCode As System.Web.UI.WebControls.DropDownList
      Protected ddlLookupStatesByState As System.Web.UI.WebControls.DropDownList
      Protected ddlLookupStatesByStateName As System.Web.UI.WebControls.DropDownList
      Protected ddlLookupCityByZipCode As System.Web.UI.WebControls.DropDownList
      
      
      Private Sub Page_Load(sender As Object, e As System.EventArgs)
         
         ' Need to register the ajax functions
         'AjaxPro.Utility.RegisterTypeForAjax(typeof(Namespace.class));
         AjaxPro.Utility.RegisterTypeForAjax(GetType(Contacts.Test))
         
         
         ' Put user code to initialize the page here
         If Not Page.IsPostBack Then
            LoadDropDownLists()
         End If
      End Sub 'Page_Load
       
      Private Sub LoadDropDownLists()
         
            Utility.utility.BindDataSet(PO.GetCities(), ddlGetCities, "CityName", "CityName")
            Utility.utility.BindDataSet(PO.GetStates(), ddlGetStates, "StateName", "State")
            Utility.utility.BindDataSet(PO.GetZipCodes(), ddlGetZipCodes, "ZipCode", "ZipCode")
            Utility.utility.BindDataSet(PO.LookupCityByName(), ddlLookupCityByName, "CityName", "CityName")
            Utility.utility.BindDataSet(PO.LookupCityByZipCode(), ddlLookupCityByZipCode, "CityName", "CityName")
            Utility.utility.BindDataSet(PO.LookupStatesByState(), ddlLookupStatesByState, "StateName", "State")
            Utility.utility.BindDataSet(PO.LookupStatesByStateName(), ddlLookupStatesByStateName, "StateName", "State")
            Utility.utility.BindDataSet(PO.LookupZipCodeByZipCode(), ddlLookupZipCodeByZipCode, "ZipCode", "ZipCode")
      End Sub 'LoadDropDownLists
       
      <AjaxPro.AjaxMethod()>  _
      Public Function GetZipCodes() As DataSet
         Return PO.GetZipCodes()
      End Function 'GetZipCodes
      
      <AjaxPro.AjaxMethod()>  _
      Public Function LookupZipCodeByZipCode(ZipCode As String) As DataSet
         Return PO.LookupZipCodeByZipCode(ZipCode)
      End Function 'LookupZipCodeByZipCode
      
#Region "Web Form Designer generated code"

        Protected Overrides Sub OnInit(ByVal e As EventArgs)
            '
            ' CODEGEN: This call is required by the ASP.NET Web Form Designer.
            '
            InitializeComponent()
            AddHandler Me.Load, AddressOf Page_Load
            MyBase.OnInit(e)
        End Sub 'OnInit


        '/ <summary>
        '/ Required method for Designer support - do not modify
        '/ the contents of this method with the code editor.
        '/ </summary>
        Private Sub InitializeComponent()
        End Sub 'InitializeComponent

#End Region
    End Class 'Test
End Namespace 'Contacts
function LeagueClicked(s)
{
	DisplayMessage (msgTypePleaseWait, "Please wait... Loading Conferences...", "");
	var sId = s.value;
	getElem("ddlTeam").length=0;
	getElem("ddlDivision").length=0;
	getElem("ddlConference").length=0;
	
	if (sId == "") return;
	Contacts.Sample5a_ComboBoxes.GetConferenceByLeague(sId, League_Callback);
}
function ConferenceClicked(s)
{
	DisplayMessage (msgTypePleaseWait, "Please wait... Loading Conferences...", "");
	
	var sId = s.value;
	
	getElem("ddlTeam").length=0;
	getElem("ddlDivision").length=0;
	
	if (sId == "") return;
	Contacts.Sample5a_ComboBoxes.GetDivisionByConference(sId, Conference_Callback);
}
function DivisionClicked(s)
{
	DisplayMessage (msgTypePleaseWait, "Please wait... Loading Conferences...", "");
	
	var sId = s.value;
	
	getElem("ddlTeam").length=0;
	
	if (sId == "") return;
	Contacts.Sample5a_ComboBoxes.GetTeamsByDivision(sId, Division_Callback);
}
function TeamClicked(s)
{
	var team = document.getElementById("lblTeam");
	
	team.innerHTML = s.value + ' - ' + s.options[s.selectedIndex].text;
}

// Callback functions
function League_Callback(response)
{
	
	if (response.error != null)
	{
		DisplayMessage(msgTypeCritical, response.error, "LeagueClicked");
		return;
	}

	if (response.value == null)
	{
		// Nothing returned from the server
		return;
	}

	var oOptionList = response.value.Tables[0];

	oControl = getElem("ddlConference");

	oControl.options.length = 0; //reset the teams dropdown    

	// Add a blank row
	oControl.options[oControl.options.length] = new Option("", ""); 

	for (var i = 0; i < oOptionList.Rows.length; ++i)
	{
		oControl.options[oControl.options.length] = new Option(oOptionList.Rows[i].ConferenceName, oOptionList.Rows[i].ConferenceId);       
	} 
	
	DisplayMessage(msgTypeSuccessComplete, "Load was successful!", "");

}
function Conference_Callback(response)
{
	
	if (response.error != null)
	{
		DisplayMessage(msgTypeCritical, response.error, "ConferenceClicked");
		return;
	}

	if (response.value == null)
	{
		// Nothing returned from the server
		return;
	}

	var oOptionList = response.value.Tables[0];

	oControl = getElem("ddlDivision");

	oControl.options.length = 0; //reset the teams dropdown    

	// Add a blank row
	oControl.options[oControl.options.length] = new Option("", ""); 

	for (var i = 0; i < oOptionList.Rows.length; ++i)
	{
		oControl.options[oControl.options.length] = new Option(oOptionList.Rows[i].DivisionName, oOptionList.Rows[i].DivisionId);       
	} 
	
	DisplayMessage(msgTypeSuccessComplete, "Load was successful!", "");


}
function Division_Callback(response)
{

	if (response.error != null)
	{
		DisplayMessage(msgTypeCritical, response.error, "DivisionClicked");
		return;
	}

	if (response.value == null)
	{
		// Nothing returned from the server
		return;
	}

	var oOptionList = response.value.Tables[0];

	oControl = getElem("ddlTeam");

	oControl.options.length = 0; //reset the teams dropdown    

	// Add a blank row
	oControl.options[oControl.options.length] = new Option("", ""); 

	for (var i = 0; i < oOptionList.Rows.length; ++i)
	{
		oControl.options[oControl.options.length] = new Option(oOptionList.Rows[i].TeamName, oOptionList.Rows[i].TeamId);       
	} 
	
	DisplayMessage(msgTypeSuccessComplete, "Load was successful!", "");
}


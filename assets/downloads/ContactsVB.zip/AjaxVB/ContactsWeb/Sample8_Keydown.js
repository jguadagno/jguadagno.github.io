
function Window_OnLoad()
{
	ReadOnlyClicked();
}
function GetContact(contactId)
{

	DisplayMessage(msgTypePleaseWait, "Loading record", "");
	// Clear the table
	ClearTable("tblContact");
	CreateRowTitle("Property", "&nbsp;", "Value");
	
	// Get the contact id
	if (typeof(contactId) == "undefined")
	{
		var oContactId = getElem("txtLoadContactId");
		if (oContactId == null)
		{
			DisplayMessage(msgTypeCritical, "No contact id was entered", "GetContact");
			return;
		}
		contactId = oContactId.value;
	}
	
	if (contactId == "")
	{
		DisplayMessage(msgTypeCritical, "No contact id was entered", "GetContact");
		return;
	}
	
	// Short cut to avoid Callback rountine
	Contacts.Sample8_Keydown.ReturnClass(contactId, GetContact_Callback); 

}
function GetContact_Callback(response)
{

	if (response.error != null)
	{
		//alert (response.message);
		DisplayMessage(msgTypeCritical, response.error, "GetContact");
		return;
	}

	var oReadOnly = getElem("chkReadOnly");
	var bReadOnly = oReadOnly.checked;

	var contact = response.value;
	
	CreateRow("ContactId", contact.ContactId, 1, bReadOnly);
	CreateRow("FirstName", contact.FirstName, 0, bReadOnly);
	CreateRow("MiddleName", contact.MiddleName, 1, bReadOnly);
	CreateRow("LastName", contact.LastName, 0, bReadOnly);
	CreateRow("HomeNumber", contact.HomeNumber, 1, bReadOnly);
	CreateRow("WorkNumber", contact.WorkNumber, 0, bReadOnly);
	CreateRow("MobileNumber", contact.MobileNumber, 1, bReadOnly);
	CreateRow("Email1", contact.Email1, 0, bReadOnly);
	CreateRow("Email2", contact.Email2, 1, bReadOnly);
	CreateRow("Email3", contact.Email3, 0, bReadOnly);
	CreateRow("Address1", contact.Address1, 1, bReadOnly);
	CreateRow("Address2", contact.Address2, 0, bReadOnly);
	CreateRow("CityName", contact.CityName, 1, bReadOnly);
	CreateRow("State", contact.State, 0, bReadOnly);
	CreateRow("ZipCode", contact.ZipCode, 1, bReadOnly);
	CreateRow("ZipPlus4", contact.ZipPlus4, 0, bReadOnly);
	
	if (typeof(contact.Team) != "undefined" && contact.Team != null)
	{
		CreateDDLRow("League", contact.Team.LeagueName, contact.Team.LeagueId, "", 1, bReadOnly);
		CreateDDLRow("Conference", contact.Team.ConferenceName, contact.Team.ConferenceId, contact.Team.LeagueId, 0, bReadOnly);
		CreateDDLRow("Division", contact.Team.DivisionName, contact.Team.DivisionId, contact.Team.ConferenceId, 1, bReadOnly);
		CreateDDLRow("Team", contact.Team.TeamName, contact.Team.TeamId, contact.Team.DivisionId, 0, bReadOnly);
	}
	else
	{
		CreateDDLRow("League", "","", "", 1, bReadOnly);
		CreateDDLRow("Conference", "","", "", 0, bReadOnly);
		CreateDDLRow("Division", "","", "", 1, bReadOnly);
		CreateDDLRow("Team", "","", "", 0, bReadOnly);
	}
	
	DisableControl("txtContactId");
	
	contact = null;
	DisplayMessage(msgTypeSuccessComplete, "Done!", "")
	
}

function AddContact()
{

	// Clear the table
	ClearTable(tblContact);
	CreateRowTitle("Property", "&nbsp;", "Value");

	var oReadOnly = getElem("chkReadOnly");
	var bReadOnly = oReadOnly.checked = false;
	
	CreateRow("ContactId", "0", 1, bReadOnly);
	CreateRow("FirstName", "", 0, bReadOnly);
	CreateRow("MiddleName", "", 1, bReadOnly);
	CreateRow("LastName", "", 0, bReadOnly);
	CreateRow("HomeNumber", "", 1, bReadOnly);
	CreateRow("WorkNumber", "", 0, bReadOnly);
	CreateRow("MobileNumber", "", 1, bReadOnly);
	CreateRow("Email1", "", 0, bReadOnly);
	CreateRow("Email2", "", 1, bReadOnly);
	CreateRow("Email3", "", 0, bReadOnly);
	CreateRow("Address1", "", 1, bReadOnly);
	CreateRow("Address2", "", 0, bReadOnly);
	CreateRow("CityName", "", 1, bReadOnly);
	CreateRow("State", "", 0, bReadOnly);
	CreateRow("ZipCode", "", 1, bReadOnly);
	CreateRow("ZipPlus4", "", 0, bReadOnly);

	CreateDDLRow("League", "", "", "", 1, bReadOnly);
	CreateDDLRow("Conference", "", "", "", 0, bReadOnly);
	CreateDDLRow("Division", "", "", "", 1, bReadOnly);
	CreateDDLRow("Team", "", "", "", 0, bReadOnly);

	
	DisableControl("txtContactId");
}

function SaveContact()
{
	DisplayMessage(msgTypePleaseWait, "Saving Record", "");
	
	var contact = new Object();
	
	contact.ContactId = getElem("txtContactId").value;
	contact.FirstName = getElem("txtFirstName").value;
	contact.MiddleName = getElem("txtMiddleName").value;
	contact.LastName = getElem("txtLastName").value;
	contact.HomeNumber = getElem("txtHomeNumber").value;
	contact.WorkNumber = getElem("txtWorkNumber").value;
	contact.MobileNumber  = getElem("txtMobileNumber").value;
	contact.Email1 = getElem("txtEmail1").value;
	contact.Email2  = getElem("txtEmail2").value;
	contact.Email3 = getElem("txtEmail3").value;
	contact.Address1  = getElem("txtAddress1").value;
	contact.Address2  = getElem("txtAddress2").value;
	contact.CityName = getElem("txtCityName").value;
	contact.State  = getElem("txtState").value;
	contact.ZipCode = getElem("txtZipCode").value;
	contact.ZipPlus4 = getElem("txtZipPlus4").value;
	var Team = new Object();
	Team.TeamId = getElem("ddlTeam").value;
	contact.Team = Team;
	
	Contacts.Sample8_Keydown.SaveContact(contact, SaveContact_Callback);
	
	contact = null;

}

function SaveContact_Callback(response)
{

	if (response.error != null)
	{
		DisplayMessage(msgTypeCritical, response.error, "SaveContact");
		return;
	}

	DisplayMessage(msgTypeSuccessComplete, "Save was successful!", "");
}

function CreateRowTitle(Field1, Field2, Field3)
{
	var otblContact = getElem("tblContact");
	var oTR = otblContact.insertRow(-1);
	var oTDName;
	var oTDBlank;
	var oTDValue;
	oTR.className="PropertyGridSubHeader";
	oTDName = oTR.insertCell(-1);
	oTDName.innerHTML = Field1
	oTDBlank = oTR.insertCell(-1);
	oTDBlank.innerHTML = Field2
	oTDValue = oTR.insertCell(-1);
	oTDValue.width="100%";
	oTDValue.innerHTML = Field3
	
	otblContact = null;
	oTR = null;
	oTDName = null;
	oTDBlank = null;
	oTDValue = null;

}
function CreateRow(PropertyName, PropertyValue, OddOrEven, ReadOnly)
{
	var oTR = getElem("tblContact").insertRow(-1);
	var oTDName;
	var oTDBlank;
	var oTDValue;

	if (OddOrEven == 0)
		oTR.className = "PropertyRow";
	else
		oTR.className = "PropertyRowAlt";

	oTDName = oTR.insertCell(-1);
	oTDName.innerHTML = GetHTMLText(PropertyName, false);
	oTDBlank = oTR.insertCell(-1);
	oTDBlank.innerHTML = "&nbsp;"
	oTDValue = oTR.insertCell(-1);
	oTDValue.width="100%";
	if (ReadOnly == true)
		oTDValue.innerHTML = GetHTMLText(PropertyValue, false);
	else
	{
		var oText = document.createElement("INPUT");
		oText.type = "text";
		oText.value = GetText(PropertyValue, false);
		oText.width=255;
		oText.id = "txt" + PropertyName;
		oTDValue.insertBefore(oText, null);
		oText = null;
	}
	
	oTDName = null;
	oTDBlank = null;
	oTDValue = null;
			
}

function CreateDDLRow(PropertyName, PropertyText, PropertyValue, ParentId, OddOrEven, ReadOnly)
{
	var oTR = getElem("tblContact").insertRow(-1);
	var oTDName;
	var oTDBlank;
	var oTDValue;

	if (OddOrEven == 0)
		oTR.className = "PropertyRow";
	else
		oTR.className = "PropertyRowAlt";

	oTDName = oTR.insertCell(-1);
	oTDName.innerHTML = GetHTMLText(PropertyName, false);
	oTDBlank = oTR.insertCell(-1);
	oTDBlank.innerHTML = "&nbsp;"
	oTDValue = oTR.insertCell(-1);
	oTDValue.width="100%";
	if (ReadOnly == true)
		oTDValue.innerHTML = GetHTMLText(PropertyText  + " (" + PropertyValue + ")", false);
	else
	{
		// Create the drop down list
		
		var oDiv = document.createElement("DIV");
		oDiv.id = "div" + PropertyName;
		oTDValue.insertBefore(oDiv, null);
		DisplayMessage(msgTypePleaseWait, "Loading the list for '" + PropertyName + "'...", "");
		switch(PropertyName)
		{
			case "League":
				Contacts.Sample8_Keydown.GetLeagues(PropertyValue, CreateLeague);
				break;
				
			case "Conference":
				if (ParentId != "")
					Contacts.Sample8_Keydown.GetConferencesByLeague(PropertyValue, ParentId, CreateConference);
				break;
				
			case "Division":
				if (ParentId != "")
					Contacts.Sample8_Keydown.GetDivisionsByConference(PropertyValue, ParentId, CreateDivision);
				break;
				
			case "Team":
				if (ParentId != "")
					Contacts.Sample8_Keydown.GetTeamsByDivision(PropertyValue, ParentId, CreateTeam);
				break;
		}
		
	}
	
	oTDName = null;
	oTDBlank = null;
	oTDValue = null;
}
function ReadOnlyClicked()
{
	if (getElem("chkReadOnly").checked == true)
		DisableButton("tbSave");
	else
		EnableButton("tbSave");
}
function CreateLeague(response)
{
	if (response.error != null)
	{
		DisplayMessage(msgTypeCritical, response.error, "LeagueClicked");
		return;
	}

	if (response.value == null)
	{
		// Nothing returned from the server
		return;
	}

	oControl = getElem("divLeague");
	oControl.innerHTML = response.value;
	
	DisplayMessage(msgTypeSuccessComplete, "Load was successful!", "");

	response = null;
}

// Example 7

function ShowSearch()
{
	ShowControl('tblSearch');
	HideControl('aShow');
}

function HideSearch()
{
	ShowControl('aShow');
	HideControl('tblSearch');
}

function Search()
{
	DisplayMessage(msgTypePleaseWait, "Searching for records", "");
	
	// Get the first name and last name for now
	var oFirstName = getElem("txtSFirstName");
	var oLastName = getElem("txtSLastName");
	var oSearch = getElem("txtSSearch");
	
	if (oSearch.value != "")
		Contacts.Sample8_Keydown.Search(oSearch.value, Search_Callback);
	else
		Contacts.Sample8_Keydown.NameSearch(oFirstName.value, oLastName.value, Search_Callback);

	oFirstName = null;
	oLastName = null;
	oSearch = null;
}

function Search_Callback(response)
{

  //if the server side code threw an exception
  if (response.error != null)
  {    
	DisplayMessage(msgTypeCritical, response.error, "Search");
    return;
  }  
	
  var searchResults = response.value;  
  //if the response wasn't what we expected  
  if (searchResults == null || typeof(searchResults) != "object")
  {
	var Message = "An unexpected error happened retrieving the teams list";
	DisplayMessage (msgTypeWarning, Message, "Search");
  }
  
  var results = searchResults.Tables[0];
  
  ClearTable("tblResults");
  CreateResultsHeading();
  
  for (var i = 0; i < results.Rows.length; ++i)
  {
	CreateResultsRow(results.Rows[i], false);
  }  
    DisplayMessage (msgTypeSuccessComplete, "Search complete! <b>" + results.Rows.length + "</b> row(s) returned!", "");
}

function CreateResultsHeading()
{
	var oTable = getElem("tblResults");
	var oTr = oTable.insertRow(-1);
	oTr.className = "Results";
	
	// ContactId
	var tdContact = oTr.insertCell(-1);
	tdContact.id = "tdContactId";
	tdContact.width="60";
	tdContact.innerHTML = "Contact";
	
	// FirstName
	var tdFirstName = oTr.insertCell(-1);
	tdFirstName.id = "tdFirstName";
	tdFirstName.width="60";
	tdFirstName.innerHTML = "First Name";

	// MiddleName
	var tdMiddleName = oTr.insertCell(-1);
	tdMiddleName.id = "tdMiddleName";
	tdMiddleName.width="60";
	tdMiddleName.innerHTML = "Middle Name";

	// LastName
	var tdLastName = oTr.insertCell(-1);
	tdLastName.id = "tdLastName";
	tdLastName.width="60";
	tdLastName.innerHTML = "LastName";

	// Email1
	var tdEmail1 = oTr.insertCell(-1);
	tdEmail1.id = "tdEmail1";
	tdEmail1.width="60";
	tdEmail1.innerHTML = "Email1";

	// Email2
	var tdEmail2 = oTr.insertCell(-1);
	tdEmail2.id = "tdEmail2";
	tdEmail2.width="60";
	tdEmail2.innerHTML = "Email2";

	// Email3
	var tdEmail3 = oTr.insertCell(-1);
	tdEmail3.id = "tdEmail3";
	tdEmail3.width="60";
	tdEmail3.innerHTML = "Email3";
	
	tdContact = null;
	tdFirstName = null;
	tdMiddleName = null;
	tdLastName = null;
	tdEmail1 = null;
	tdEmail2 = null;
	tdEmail3 = null;
	oTr = null;
	
}
function CreateResultsRow(oData, CanEdit)
{
	
	var oResults = getElem("tblResults");
		
	// remove the previous add button
	var RowNumber = oResults.rows.length;
	
	// Start adding the new row
	var tr = oResults.insertRow(-1);
	tr.id = "trResults_" + RowNumber;
	if (oResults.rows.length % 2 == 0)
		tr.className="ResultsRowAlt";
	else
		tr.className="ResultsRow";

	// link row
	
	var tdContact = tr.insertCell(-1);
	tdContact.id = "tdContactId_" + RowNumber;
	tdContact.width="32";

	var link = document.createElement("A");
	link.id = "lnkContactId_" + RowNumber;
	link.innerHTML = oData.ContactId;
	link.href="javascript:GetContact(" + oData.ContactId + ");";
	
	tdContact.insertBefore(link, null);
	tdContact = null;
	
	if (CanEdit == false)
	{
		// First Name
		var tdCell = tr.insertCell(-1);
		tdCell.id = "tdFirstName_" + RowNumber;
		tdCell.width="60";
		tdCell.innerHTML  = oData.FirstName;
			
		// Middle Name
		tdCell = tr.insertCell(-1);
		tdCell.id = "tdMiddleName_" + RowNumber;
		tdCell.width="60";
		tdCell.innerHTML  = oData.MiddleName;
		
		// Last Name
		tdCell = tr.insertCell(-1);
		tdCell.id = "tdLastName_" + RowNumber;
		tdCell.width="60";
		tdCell.innerHTML  = oData.LastName;
		
		// Email1
		tdCell = tr.insertCell(-1);
		tdCell.id = "tdEmail1_" + RowNumber;
		tdCell.width="60";
		tdCell.innerHTML  = oData.Email1;
		
		// Email2
		tdCell = tr.insertCell(-1);
		tdCell.id = "tdEmail2_" + RowNumber;
		tdCell.width="60";
		tdCell.innerHTML  = oData.Email2;
		
		// Email3 
		tdCell = tr.insertCell(-1);
		tdCell.id = "tdEmail3_" + RowNumber;
		tdCell.width="60";
		tdCell.innerHTML  = oData.Email3;
	
	}
	else
	{
		// Need to create input boxes

		// First Name
		var tdCell = tr.insertCell(-1);
		tdCell.id = "tdFirstName_" + RowNumber;
		tdCell.width="60";
		var txtBox = document.createElement("INPUT");
		txtBox.id = "txtFirstName_" + RowNumber;
		txtBox.type = "text";
		txtBox.width = "60";
		txtBox.value = oData.FirstName;
		tdCell.insertBefore(txtBox, null);
			
		// Middle Name
		tdCell = tr.insertCell(-1);
		tdCell.id = "tdMiddleName_" + RowNumber;
		tdCell.width="60";
		txtBox = document.createElement("INPUT");
		txtBox.id = "txtMiddleName_" + RowNumber;
		txtBox.type = "text";
		txtBox.width = "60";
		txtBox.value = oData.MiddleName;
		tdCell.insertBefore(txtBox, null);
		
		// Last Name
		tdCell = tr.insertCell(-1);
		tdCell.id = "tdLastName_" + RowNumber;
		tdCell.width="60";
		txtBox = document.createElement("INPUT");
		txtBox.id = "txtLastName_" + RowNumber;
		txtBox.type = "text";
		txtBox.width = "60";
		txtBox.value = oData.LastName;
		tdCell.insertBefore(txtBox, null);
		
		// Email1
		tdCell = tr.insertCell(-1);
		tdCell.id = "tdEmail1_" + RowNumber;
		tdCell.width="60";
		txtBox = document.createElement("INPUT");
		txtBox.id = "txtEmail1_" + RowNumber;
		txtBox.type = "text";
		txtBox.width = "60";
		txtBox.value = oData.Email1;
		tdCell.insertBefore(txtBox, null);
		
		// Email2
		tdCell = tr.insertCell(-1);
		tdCell.id = "tdEmail2_" + RowNumber;
		tdCell.width="60";
		txtBox = document.createElement("INPUT");
		txtBox.id = "txtEmail2_" + RowNumber;
		txtBox.type = "text";
		txtBox.width = "60";
		txtBox.value = oData.Email2;
		tdCell.insertBefore(txtBox, null);
		
		// Email3 
		tdCell = tr.insertCell(-1);
		tdCell.id = "tdEmail3_" + RowNumber;
		tdCell.width="60";
		txtBox = document.createElement("INPUT");
		txtBox.id = "txtEmail3_" + RowNumber;
		txtBox.type = "text";
		txtBox.width = "60";
		txtBox.value = oData.Email3;
		tdCell.insertBefore(txtBox, null);
		
		tdCell = null;
		txtBox = null;		
	}
	oResults = null;
	tr=null;
}
// Example 8
function OnOtherSearchKeyDown()
{
	var oSearch = getElem("txtSSearch");
	if (oSearch.value == "")
	{
		ClearTable("tblResults");
		HideControl("divDropDown");
		getElem("divDropDown").innerHTML = "";
		return;
	}

	DisplayMessage(msgTypePleaseWait, "Looking ...", "");
	
	// Option 1
	//Contacts.Sample8_Keydown.Search(oSearch.value, Search_Callback);
	// Option 2
	Contacts.Sample8_Keydown.Search(oSearch.value, BuildDropDown);

}

function BuildDropDown(response)
{

	//if the server side code threw an exception
	if (response.error != null)
	{    
		DisplayMessage(msgTypeCritical, response.error, "Search");
		HideControl("divDropDown");
		return;
	}  

	var searchResults = response.value;  
	//if the response wasn't what we expected  
	if (searchResults == null || typeof(searchResults) != "object")
	{
		var Message = "An unexpected error happened retrieving the teams list";
		HideControl("divDropDown");
		DisplayMessage (msgTypeWarning, Message, "Search");
	}

	var results = searchResults.Tables[0];

	ShowControl("divDropDown");
	var oDiv = BuildDropDownList(results);
	PlaceDropDownList(oDiv);
	DisplayMessage(msgTypeSuccessComplete, "Done.", "");
	oDiv = null;
	
	// Update the Search Results (optional)
	Search_Callback(response);
	response = null;
}

function BuildDropDownList(oData)
{

	var oDiv = getElem("divDropDown");
	oDiv.innerHTML = "";
	
	var sHTML = "";
	
	for (var i = 0; i < oData.Rows.length; ++i)
	{
		sHTML += "<a class=DropDownItem href='javascript:SearchDropDownClick(" + oData.Rows[i].ContactId + ")'>" + GetName(oData.Rows[i]) + "</a><br>";
		//CreateResultsRow(oData.Rows[i], false);
	}  

	oDiv.innerHTML = sHTML;
	
	return oDiv;
	
}
function PlaceDropDownList(oDiv)
{
	
	// Position the control underneath the txtSSearch
	oSearch = getElem("txtSSearch");
	
	oDiv.style.left = CalculateLeft(oSearch) + "px";
	oDiv.style.top = (CalculateTop(oSearch) + oSearch.offsetHeight) + "px";
	oDiv.style.width = oSearch.clientWidth + "px";
	
	oSearch = null;	
}

function SearchDropDownClick(ContactId)
{
	oDiv = getElem("divDropDown").innerHTML = "";
	HideControl(oDiv);
	GetContact(ContactId);
}

function GetName(oRow)
{
	var sName = ""
	sName = oRow.FirstName + " " + oRow.LastName + " &lt;" + oRow.Email1 + "&gt;";
	// bold the found part
	
	return sName;
}

function CalculateTop(oNode)
{
    var iTop = 0;

    while(oNode.tagName != "BODY") {
        iTop += oNode.offsetTop;
        oNode = oNode.offsetParent; 
    }

    return iTop;
}

function CalculateLeft(oNode)
{

    var iLeft = 0;

    while(oNode.tagName != "BODY") {
        iLeft += oNode.offsetLeft;
        oNode = oNode.offsetParent; 
    }

    return iLeft;
    
}



Imports System
Imports System.Web
Imports System.Web.UI.WebControls



Namespace Utility
   '/ <summary>
   '/ Summary description for Utility.
   '/ </summary>
   
   Public Class utility
      
      Public Sub New()
      End Sub 'New
      
      '
      ' TODO: Add constructor logic here
      '
      '/ <summary>
      '/ Searchs the dropdownlist for the value passed
      '/ </summary>
      '/ <param name="dropdownList">The DropDownList to search for</param>
      '/ <param name="SearchFor">The value to search for</param>
      Public Shared Sub SelectComboboxItemByValue(dropdownList As System.Web.UI.WebControls.DropDownList, SearchFor As String)
         
         Dim ddItem As ListItem
         
         ' Clear out any previous selections
         ddItem = dropdownList.Items.FindByValue(SearchFor)
         If ddItem Is Nothing Then
            Dim ddNewItem As New ListItem(SearchFor, SearchFor)
            dropdownList.Items.Add(ddNewItem)
            ddNewItem.Selected = True
            ddNewItem = Nothing
         Else
            ddItem.Selected = True
         End If
         
         ddItem = Nothing
      End Sub 'SelectComboboxItemByValue
       
      
      '/ <summary>
      '/ Searchs the dropdownlist for the text passed
      '/ </summary>
      '/ <param name="dropdownList">The DropDownList to search for</param>
      '/ <param name="SearchFor">The text value to search for</param>
      Public Shared Sub SelectComboboxItemByText(dropdownList As System.Web.UI.WebControls.DropDownList, SearchFor As String)
         
         Dim ddItem As ListItem
         
         ddItem = dropdownList.Items.FindByText(SearchFor)
         If ddItem Is Nothing Then
            Dim ddNewItem As New ListItem(SearchFor, SearchFor)
            dropdownList.Items.Add(ddNewItem)
            ddNewItem.Selected = True
            ddNewItem = Nothing
         Else
            ddItem.Selected = True
         End If
         
         ddItem = Nothing
      End Sub 'SelectComboboxItemByText
      
      
      
      '/ <summary>
      '/ Binds the passed DataSet to the DropDownList
      '/ </summary>
      '/ <param name="ds">The DataSet</param>
      '/ <param name="comboboxItem">The DropDownList to bind</param>
      '/ <param name="textField">The column to bind the text to</param>
      Overloads Public Shared Sub BindDataSet(ds As System.Data.DataSet, comboboxItem As System.Web.UI.WebControls.DropDownList, textField As String)
         BindDataSet(ds, comboboxItem, textField, textField)
      End Sub 'BindDataSet
      
      
      
      '/ <summary>
      '/ Binds the passed DataSet to the DropDownList
      '/ </summary>
      '/ <param name="ds">The DataSet</param>
      '/ <param name="comboboxItem">The DropDownList to bind</param>
      '/ <param name="textField">The column to bind the text to</param>
      '/ <param name="valueField">The column to bind the value to</param>
      Overloads Public Shared Sub BindDataSet(ds As System.Data.DataSet, comboboxItem As System.Web.UI.WebControls.DropDownList, textField As String, valueField As String)
         comboboxItem.DataSource = ds
         comboboxItem.DataTextField = textField
         comboboxItem.DataValueField = valueField
         comboboxItem.DataBind()
      End Sub 'BindDataSet
      
      Public Shared Function NotNullDBValue(Invalue As String) As String
         If Invalue Is Nothing Then
            Return ""
         Else
            Return Invalue
         End If
      End Function 'NotNullDBValue
      
      
      '/ <summary>
      '/ Adds a blank row to the passed DataTable
      '/ </summary>
      '/ <param name="dt">The DataTable to add the blank rows to</param>
      '/ <returns></returns>
      Overloads Public Shared Function AddBlankRowsToTable(dt As System.Data.DataTable) As System.Data.DataTable
         ' create the "dummy" record used to add blank rows
         Dim dummyData(0) As String
         
         ' Add and extra row
         dt.Rows.Add(dummyData)
         Return dt
      End Function 'AddBlankRowsToTable
       
      Overloads Public Shared Function AddBlankRowsToTable(dt As System.Data.DataTable, NumberOfRowsToAdd As Integer) As System.Data.DataTable
         Dim i As Integer
         For i = 1 To NumberOfRowsToAdd
            dt = AddBlankRowsToTable(dt)
         Next i
         
         Return dt
      End Function 'AddBlankRowsToTable 
      
      #Region "ControlOnOrOff"
      
      '/ <summary>
      '/ Enables or disables a control with a standard look
      '/ </summary>
      '/ <param name="controlIn">The System.Web.UI.WebControls.Textbox control to set the attributes for.</param>
      '/ <param name="OnOrOff">True indicates the control is enabled, false indicates it is disabled.</param>
      Overloads Public Shared Sub ControlOnOrOff(controlIn As System.Web.UI.WebControls.TextBox, OnOrOff As Boolean)
         If OnOrOff = True Then
            controlIn.BackColor = System.Drawing.Color.White
            controlIn.ReadOnly = False
         Else
            controlIn.BackColor = System.Drawing.Color.Gainsboro
            controlIn.ReadOnly = True
         End If
      End Sub 'ControlOnOrOff
      
      
      '/ <summary>
      '/ Enables or disables a control with a standard look
      '/ </summary>
      '/ <param name="controlIn">The System.Web.UI.WebControls.Label control to set the attributes for.</param>
      '/ <param name="OnOrOff">True indicates the control is enabled, false indicates it is disabled.</param>
      Overloads Public Shared Sub ControlOnOrOff(controlIn As System.Web.UI.WebControls.Label, OnOrOff As Boolean)
         If OnOrOff = True Then
            controlIn.BackColor = System.Drawing.Color.White
            controlIn.Enabled = True
         Else
            controlIn.BackColor = System.Drawing.Color.Gainsboro
            controlIn.Enabled = False
         End If
      End Sub 'ControlOnOrOff
      
      
      '/ <summary>
      '/ Enables or disables a control with a standard look
      '/ </summary>
      '/ <param name="controlIn">The System.Web.UI.WebControls.DropDownList control to set the attributes for.</param>
      '/ <param name="OnOrOff">True indicates the control is enabled, false indicates it is disabled.</param>
      Overloads Public Shared Sub ControlOnOrOff(controlIn As System.Web.UI.WebControls.DropDownList, OnOrOff As Boolean)
         If OnOrOff = True Then
            controlIn.BackColor = System.Drawing.Color.White
            controlIn.Enabled = True
         Else
            controlIn.BackColor = System.Drawing.Color.Gainsboro
            controlIn.Enabled = False
         End If
      End Sub 'ControlOnOrOff
      
      
      '/ <summary>
      '/ Enables or disables a control with a standard look
      '/ </summary>
      '/ <param name="controlIn">The System.Web.UI.HtmlInputButton control to set the attributes for.</param>
      '/ <param name="OnOrOff">True indicates the control is enabled, false indicates it is disabled.</param>
      Overloads Public Shared Sub ControlOnOrOff(controlIn As System.Web.UI.HtmlControls.HtmlInputButton, OnOrOff As Boolean)
         If OnOrOff = True Then
            controlIn.Disabled = False
         Else
            controlIn.Disabled = True
         End If
      End Sub 'ControlOnOrOff
      #End Region
   End Class 'utility
End Namespace 'Utility

Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Web
Imports System.Web.SessionState
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls


Namespace Contacts
   '/ <summary>
   '/ Added team selection to the contact list.
   '/ </summary>
   
   Public Class Sample6_ContactWithTeam
      Inherits System.Web.UI.Page
      
      
      Private Sub Page_Load(sender As Object, e As System.EventArgs)
         ' Put user code to initialize the page here
         AjaxPro.Utility.RegisterTypeForAjax(GetType(Contacts.Sample6_ContactWithTeam))
      End Sub 'Page_Load
      
#Region "Web Form Designer generated code"

        Protected Overrides Sub OnInit(ByVal e As EventArgs)
            '
            ' CODEGEN: This call is required by the ASP.NET Web Form Designer.
            '
            InitializeComponent()
            AddHandler Me.Load, AddressOf Page_Load
            MyBase.OnInit(e)
        End Sub 'OnInit


        '/ <summary>
        '/ Required method for Designer support - do not modify
        '/ the contents of this method with the code editor.
        '/ </summary>
        Private Sub InitializeComponent()
        End Sub 'InitializeComponent

#End Region


        <AjaxPro.AjaxMethod()> _
        Public Function ReturnClass(ByVal ContactId As Integer) As Contact
            Return Contact.Load(ContactId)
        End Function 'ReturnClass


        <AjaxPro.AjaxMethod()> _
        Public Function SaveContact(ByVal oContact As Contact) As String
            Return oContact.Save()
        End Function 'SaveContact

#Region "DropDownList Methods"


        <AjaxPro.AjaxMethod()> _
        Public Function GetLeagues(ByVal selectedItem As String) As System.Web.UI.HtmlControls.HtmlSelect

            Dim dropdown As System.Web.UI.HtmlControls.HtmlSelect = New HtmlSelect

            Dim ds As DataSet = Sport.LoadLeagues()
            Utility.DBHelper.AddBlankRowsToTable(ds.Tables(0))
            dropdown.Items.Clear()
            dropdown.ID = "ddlLeague"
            Dim dr As DataRow
            For Each dr In ds.Tables(0).Rows
                Dim oItem As New System.Web.UI.WebControls.ListItem
                oItem.Text = dr("LeagueName").ToString().Trim()
                oItem.Value = dr("LeagueId").ToString().Trim()
                oItem.Selected = dr("LeagueId").ToString().Trim() = selectedItem.Trim()
                dropdown.Items.Add(oItem)
            Next dr
            dropdown.Attributes("onchange") = "LeagueClicked(this);"
            ds = Nothing
            Return dropdown
        End Function 'GetLeagues


        <AjaxPro.AjaxMethod()> _
        Public Function GetConferencesByLeague(ByVal selectedItem As String, ByVal LeagueId As String) As System.Web.UI.HtmlControls.HtmlSelect

            Dim dropdown As System.Web.UI.HtmlControls.HtmlSelect = New HtmlSelect

            Dim ds As DataSet = Sport.LoadConferenceByLeague(Integer.Parse(LeagueId))
            Utility.DBHelper.AddBlankRowsToTable(ds.Tables(0))
            dropdown.Items.Clear()
            dropdown.ID = "ddlConference"
            Dim dr As DataRow
            For Each dr In ds.Tables(0).Rows
                Dim oItem As New System.Web.UI.WebControls.ListItem
                oItem.Text = dr("ConferenceName").ToString().Trim()
                oItem.Value = dr("ConferenceId").ToString().Trim()
                oItem.Selected = dr("ConferenceId").ToString().Trim() = selectedItem.Trim()
                dropdown.Items.Add(oItem)
            Next dr
            dropdown.Attributes("onchange") = "ConferenceClicked(this);"
            ds = Nothing
            Return dropdown
        End Function 'GetConferencesByLeague


        <AjaxPro.AjaxMethod()> _
        Public Function GetDivisionsByConference(ByVal selectedItem As String, ByVal ConferenceId As String) As System.Web.UI.HtmlControls.HtmlSelect

            Dim dropdown As System.Web.UI.HtmlControls.HtmlSelect = New HtmlSelect

            Dim ds As DataSet = Sport.LoadDivisionsByConference(Integer.Parse(ConferenceId))
            Utility.DBHelper.AddBlankRowsToTable(ds.Tables(0))
            dropdown.Items.Clear()
            dropdown.ID = "ddlDivision"
            Dim dr As DataRow
            For Each dr In ds.Tables(0).Rows
                Dim oItem As New System.Web.UI.WebControls.ListItem
                oItem.Text = dr("DivisionName").ToString().Trim()
                oItem.Value = dr("DivisionId").ToString().Trim()
                oItem.Selected = dr("DivisionId").ToString().Trim() = selectedItem.Trim()
                dropdown.Items.Add(oItem)
            Next dr
            dropdown.Attributes("onchange") = "DivisionClicked(this);"
            ds = Nothing
            Return dropdown
        End Function 'GetDivisionsByConference


        <AjaxPro.AjaxMethod()> _
        Public Function GetTeamsByDivision(ByVal selectedItem As String, ByVal divisionId As String) As System.Web.UI.HtmlControls.HtmlSelect

            Dim dropdown As System.Web.UI.HtmlControls.HtmlSelect = New HtmlSelect

            Dim ds As DataSet = Sport.LoadTeamsByDivision(Integer.Parse(divisionId))
            Utility.DBHelper.AddBlankRowsToTable(ds.Tables(0))
            dropdown.Items.Clear()
            dropdown.ID = "ddlTeam"
            Dim dr As DataRow
            For Each dr In ds.Tables(0).Rows
                Dim oItem As New System.Web.UI.WebControls.ListItem
                oItem.Text = dr("TeamName").ToString().Trim()
                oItem.Value = dr("TeamId").ToString().Trim()
                oItem.Selected = dr("TeamId").ToString().Trim() = selectedItem.Trim()
                dropdown.Items.Add(oItem)
            Next dr
            dropdown.Attributes("onchange") = "TeamClicked(this);"
            ds = Nothing
            Return dropdown
        End Function 'GetTeamsByDivision


#End Region
    End Class 'Sample6_ContactWithTeam
End Namespace 'Contacts 
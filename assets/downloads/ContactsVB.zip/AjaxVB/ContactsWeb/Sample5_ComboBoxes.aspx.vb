
Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Web
Imports System.Web.SessionState
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls


Namespace Contacts
   '/ <summary>
   '/ Combo boxes with Postback
   '/ </summary>
   
   Public Class Sample5_ComboBoxes
      Inherits System.Web.UI.Page
      Protected WithEvents ddlLeague As System.Web.UI.WebControls.DropDownList
      Protected WithEvents ddlConference As System.Web.UI.WebControls.DropDownList
      Protected WithEvents ddlDivision As System.Web.UI.WebControls.DropDownList
      Protected WithEvents ddlTeam As System.Web.UI.WebControls.DropDownList
      Protected lblTeam As System.Web.UI.WebControls.Label
      
      
      Private Sub Page_Load(sender As Object, e As System.EventArgs) Handles MyBase.Load
         ' Put user code to initialize the page here
         If Not Page.IsPostBack Then
            LoadControls()
         End If
      End Sub 'Page_Load
       
      Public Sub LoadControls()
         Dim dsLeague As DataSet = Sport.LoadLeagues()
         'DataSet dsConference = Sport.LoadConferences();
         'DataSet dsDivision = Sport.LoadDivisions();
         'DataSet dsTeam = Sport.LoadTeams();
         Utility.DBHelper.AddBlankRowsToTable(dsLeague.Tables(0))
            Utility.utility.BindDataSet(dsLeague, ddlLeague, "LeagueName", "LeagueId")
            Utility.utility.SelectComboboxItemByValue(ddlLeague, "")

            ddlConference.Items.Clear()
            ddlDivision.Items.Clear()
            ddlTeam.Items.Clear()
            'Utility.DBHelper.BindDataSet(dsConference, ddlConference,"ConferenceName", "ConferenceId");
            'Utility.DBHelper.BindDataSet(dsDivision, ddlDivision,"DivisionName", "DivisionId");
            'Utility.DBHelper.BindDataSet(dsTeam, ddlTeam,"TeamName", "TeamId");
            dsLeague.Dispose()
            dsLeague = Nothing
        End Sub 'LoadControls 




#Region "Web Form Designer generated code"

        Protected Overrides Sub OnInit(ByVal e As EventArgs)
            '
            ' CODEGEN: This call is required by the ASP.NET Web Form Designer.
            '
            InitializeComponent()
            AddHandler Me.Load, AddressOf Page_Load
            MyBase.OnInit(e)
        End Sub 'OnInit


        '/ <summary>
        '/ Required method for Designer support - do not modify
        '/ the contents of this method with the code editor.
        '/ </summary>
        Private Sub InitializeComponent()
        End Sub 'InitializeComponent

#End Region


        Private Sub ddlLeague_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlLeague.SelectedIndexChanged
            ddlConference.Items.Clear()
            ddlDivision.Items.Clear()
            ddlTeam.Items.Clear()

            Dim dsConference As DataSet = Sport.LoadConferenceByLeague(Integer.Parse(ddlLeague.SelectedValue))
            Utility.DBHelper.AddBlankRowsToTable(dsConference.Tables(0))
            Utility.utility.BindDataSet(dsConference, ddlConference, "ConferenceName", "ConferenceId")
            Utility.utility.SelectComboboxItemByValue(ddlConference, "")
            dsConference.Dispose()
            dsConference = Nothing
        End Sub 'ddlLeague_SelectedIndexChanged


        Private Sub ddlConference_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlConference.SelectedIndexChanged

            ddlDivision.Items.Clear()
            ddlTeam.Items.Clear()

            Dim dsDivision As DataSet = Sport.LoadDivisionsByConference(Integer.Parse(ddlConference.SelectedValue))
            Utility.DBHelper.AddBlankRowsToTable(dsDivision.Tables(0))
            Utility.utility.BindDataSet(dsDivision, ddlDivision, "DivisionName", "DivisionId")
            Utility.utility.SelectComboboxItemByValue(ddlDivision, "")
            dsDivision.Dispose()
            dsDivision = Nothing
        End Sub 'ddlConference_SelectedIndexChanged


        Private Sub ddlDivision_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlDivision.SelectedIndexChanged
            ddlTeam.Items.Clear()

            Dim dsTeam As DataSet = Sport.LoadTeamsByDivision(Integer.Parse(ddlDivision.SelectedValue))
            Utility.DBHelper.AddBlankRowsToTable(dsTeam.Tables(0))
            Utility.utility.BindDataSet(dsTeam, ddlTeam, "TeamName", "TeamId")
            Utility.utility.SelectComboboxItemByValue(ddlTeam, "")
            dsTeam.Dispose()
            dsTeam = Nothing
        End Sub 'ddlDivision_SelectedIndexChanged


        Private Sub ddlTeam_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlTeam.SelectedIndexChanged
            lblTeam.Text = "Value = " + ddlTeam.SelectedValue.ToString() + " - " + ddlTeam.SelectedItem.Text
        End Sub 'ddlTeam_SelectedIndexChanged
    End Class 'Sample5_ComboBoxes
End Namespace 'Contacts
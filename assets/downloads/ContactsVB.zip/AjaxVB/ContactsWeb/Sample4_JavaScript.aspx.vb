
Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Web
Imports System.Web.SessionState
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls


Namespace Contacts
   '/ <summary>
   '/ Seperate the JavaScript
   '/ </summary>
   
   Public Class Sample4JavaScript
      Inherits System.Web.UI.Page
      
      
      Private Sub Page_Load(sender As Object, e As System.EventArgs)
         ' Put user code to initialize the page here
         AjaxPro.Utility.RegisterTypeForAjax(GetType(Contacts.Sample4JavaScript))
      End Sub 'Page_Load
      
#Region "Web Form Designer generated code"

        Protected Overrides Sub OnInit(ByVal e As EventArgs)
            '
            ' CODEGEN: This call is required by the ASP.NET Web Form Designer.
            '
            InitializeComponent()
            AddHandler Me.Load, AddressOf Page_Load
            MyBase.OnInit(e)
        End Sub 'OnInit


        '/ <summary>
        '/ Required method for Designer support - do not modify
        '/ the contents of this method with the code editor.
        '/ </summary>
        Private Sub InitializeComponent()
        End Sub 'InitializeComponent

#End Region

        <AjaxPro.AjaxMethod()> _
        Public Function ReturnClass(ByVal ContactId As Integer) As Contact
            Return Contact.Load(ContactId)
        End Function 'ReturnClass


        <AjaxPro.AjaxMethod()> _
        Public Function SaveContact(ByVal oContact As Contact) As String
            Return oContact.Save()
        End Function 'SaveContact
    End Class 'Sample4JavaScript
End Namespace 'Contacts 
var msgTypeCritical = 0;
var msgTypeOk = 1;
var msgTypeSerious = 2;
var msgTypeSuccessComplete = 3;
var msgTypeWarning = 4;
var msgTypePleaseWait = 5

function DisplayMessage(MessageType, Message, Location)
{
	
	var sMsgClass;
	var sMsgImg = "<img src='";
	var sMsgHtml = "";
	var sMessage = "";
	
	switch (MessageType)
	{
		case msgTypePleaseWait:
		{
			sMsgImg += "images/spinner.gif'>";
			sMsgClass = "msgWait";
			break;
		}
		case msgTypeCritical:
		{
			sMsgImg += "images/critical.gif'>";
			sMsgClass = "msgCritical";
			break;
		}
		case msgTypeOk:
		{
			sMsgImg += "images/ok.gif'>";
			sMsgClass = "msgOk";
			setTimeout("HideControl('tblMessage')", 3000);
			break;
		}
		case msgTypeSerious:
		{
			sMsgImg += "images/Serious.gif'>";
			sMsgClass = "msgSerious";
			break;
		}
		case msgTypeSuccessComplete:
		{
			sMsgImg += "images/SuccessComplete.gif'>";
			sMsgClass = "msgSuccessComplete";
			setTimeout("HideControl('tblMessage')", 3000);
			break;
		}
		case msgTypeWarning:
		{
			sMsgImg += "images/Warning.gif'>";
			sMsgClass = "msgWarning";
			break;						
		}
	}
	
	if (typeof(Message) == "string")
	{
		sMessage = Message;	
	} 
	else
	{
		sMessage = Message.Message;
		sMsgHtml = "The exception type is: '" + Message.Type + "'<BR>";

	}
	
	if (Location.trim() != "")
		sMsgHtml += "The location of the error is: " + Location;

	getElem("tblMessage").className = sMsgClass;
	getElem("tdImg").innerHTML = sMsgImg;
	getElem("tdMessage").innerHTML = sMessage;
	getElem("tdExtra").innerHTML = sMsgHtml;
	
	ShowControl("tblMessage");
}

// Status Indicator functions   
function ShowControl(c)
{
	//get the indicator
	var oElem = getElem(c);
	if (oElem == null) return;
	
	//show the loading indicator
	oElem.style.display = "block";
}

function HideControl(c)
{
	var oElem = getElem(c);
	if (oElem == null) return;
	oElem.style.display = "none";
} 

// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//	Allows the adding of multiple events
// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
function eventAddHandler(eventSourceId, eventType, func)
{
var eventSource = document.getElementById(eventSourceId);
var eventRef = eventSourceId + "." + eventType;
var eventHandlers = eval(eventRef);
if (typeof eventHandlers == 'function') { // not first handler
eval(eventRef + " = function() {eventHandlers(); func();}"); 
} else { // first handler
eval(eventRef + " = func;");
}
} 
// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//	Allows the adding of another window_onload event
// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
function addLoadEvent(func) {
  var oldonload = window.onload;
  if (typeof window.onload != 'function') {
    window.onload = func;
  } else {
    window.onload = function() {
      oldonload();
      func();
    }
  }
}

function DockToLower(obj)
{
	obj.style.height=65;
	obj.style.width = document.body.clientWidth;
	obj.style.top = document.body.clientHeight - obj.clientHeight - 2 + document.body.scrollTop;
	
}

// DIV Functions
function divText(d, t)
{
	d.innerHTML=t;
}


// ------------------------------------------------------------------- 
// MoneyFormat (value) 
//   Pass a value to be converted to money format - 2 decimal places. 
//   Returns the formatted value 
// ------------------------------------------------------------------- 
function MoneyFormat(amount) { 
	var val = parseFloat(amount); 
	if (isNaN(val)) { return "0.00"; } 
	if (val <= 0) { return "0.00"; } 
	val += ""; 
	// Next two lines remove anything beyond 2 decimal places 
	if (val.indexOf('.') == -1) { return val+".00"; } 
	else { val = val.substring(0,val.indexOf('.')+3); } 
	val = (val == Math.floor(val)) ? val + '.00' : ((val*10 == 
	Math.floor(val*10)) ? val + '0' : val); 
	return val; 
 } 
 
// This function is compatible with the DateTime structure in C#
function GetCurrentDateTime()
{
	var d;
	var s;
	var slash = "/";
	var c = ":";

	d = new Date();

	s = (d.getMonth() + 1) + slash;
	s += d.getDate() + slash;
	s += d.getYear() + " ";

	// Time	
	s += d.getHours() + c;
	s += d.getMinutes() + c;
	s += d.getSeconds();
	return(s);
}
function GetCurrentDate()
{
	var d;
	var s;
	var slash = "/";
	var c = ":";

	d = new Date();

	s = (d.getMonth() + 1) + slash;
	s += d.getDate() + slash;
	s += d.getYear() + " ";

	return(s);
}
function CurrentDateAndTime()
{
	var d;
	var s;
	var slash = "-";
	var c = ":";

	d = new Date();

	s = d.getYear() + slash;
	s += (d.getMonth() + 1) + slash;
	s += d.getDate() + " ";

	// Time	
	s += d.getHours() + c;
	s += d.getMinutes() + c;
	s += d.getSeconds() + c;
	s += d.getMilliseconds();
	return(s);
}
function CurrentDate()
{
	var d;
	var s;
	var slash = "-";
	var c = ":";

	d = new Date();

	s = d.getYear() + slash;
	s += (d.getMonth() + 1) + slash;
	s += d.getDate();
	return(s);
}

function CurrentTime()
{
	var d;
	var s;
	var slash = "-";
	var c = ":";

	d = new Date();

	// Time	
	s = d.getHours() + c;
	s += d.getMinutes() + c;
	s += d.getSeconds() + c;
	s += d.getMilliseconds();
	return(s);
}
function FormatDateShort(d)
{
	var slash="/";
	var s = "";
	s = (d.getMonth() + 1) + slash;
	s += d.getDate() + slash;
	s += d.getYear();
	
	return (s);	
}
// Return the text value of the column or &nbsp; if the column
// is not an object, null or blank
function GetHTMLText(inColumnValue, IsMoney)
{
	
	if (inColumnValue != null || typeof(inColumnValue) != "object")
	{

		if (inColumnValue != "")
		{
			if (IsMoney == true)
				return MoneyFormat(inColumnValue);
			else
				return inColumnValue;
		}
		else
		{
			if (IsMoney == true)
				return MoneyFormat(0);
			else
				return "&nbsp;";
		}
	}
	else
		if (IsMoney == true)
			return MoneyFormat(0);
		else
			return "&nbsp;";
}
// Return the text value of the column or &nbsp; if the column
// is not an object, null or blank
function GetText(inColumnValue, IsMoney)
{
	if (inColumnValue != null || typeof(inColumnValue) != "object")
	{
		if (inColumnValue != "")
		{
			if (IsMoney == true)
				return MoneyFormat(inColumnValue);
			else
				return inColumnValue;
		}
		else
			if (IsMoney == true)
				return MoneyFormat(0);
			else
				return "";
	}
	else
		if (IsMoney == true)
			return MoneyFormat(0);
		else
			return "";
}

function EnableControl(sControl)
{
	if (sControl == "") return;

	var control = getElem(sControl)
	if (control == null) return;
	
	control.disabled = false;
	control.readOnly = false;
	control.style.backgroundColor = 'white';
	
}

function DisableControl(sControl)
{
	if (sControl == "") return;

	var control = getElem(sControl)
	if (control == null) return;
	
	control.disabled = true;
	control.readOnly = true;
	control.style.backgroundColor = 'gainsboro';
	
}

// Disable button
function DisableButton(buttonName)
{
	if (buttonName == "")
		return;
		
	var button = document.getElementById(buttonName);
	if (typeof(button) == "undefined")
		return;
		
	button.enabled = false;
	button.className="toolButtonDisabled";

}


// Enable button
function EnableButton(buttonName)
{
	if (buttonName == "")
		return;
		
	var button = document.getElementById(buttonName);
	if (typeof(button) == "undefined")
		return;
		
	button.enabled = true
	button.className="toolButton";

}

function getElem(Jb)
{
    return document.getElementById(Jb);
}
function getOpenerElem(Jb)
{
	return window.opener.document.getElementById(Jb);
}

// @~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@
//	SetObjectEqualTo
//		Sets the .Value property of object
//		based on the control id
//
//		Parameters
//			sControl: The string representation of the control
//			NewValue: The value to set the control to
//		Returns
//			The new object
// @~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@
function SetObjectEqualTo(sControl, NewValue)
{
	
	var oObject = getElem(sControl);
	oObject.value = NewValue;
	return oObject;
}
// @~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@
//	SetOpenerObjectEqualTo
//		Sets the .Value property of object
//		based on the control id
//
//		Parameters
//			sControl: The string representation of the control
//			NewValue: The value to set the control to
//		Returns
//			The new object
// @~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@
function SetOpenerObjectEqualTo(sControl, NewValue)
{

	var oObject = window.opener.document.getElementById(sControl);
	oObject.value = NewValue;
	return oObject;
}

		
function displayFixedDecimal(value) 
{
	var formattedValue;

	if (value.indexOf(".") == -1) 
		value = value + ".00";
	else
		if (value.indexOf(".") + 1 != value.length - value.indexOf(".")) value = value + "0";

	// Find decimal position 
	// Find position of decimal
	var decimalPos = value.indexOf('.');

	if (decimalPos > -1) 
	{
		var decimalLength = value.length - (decimalPos + 1);
		
		if (decimalPos == 0) 
		{
			value = "0" + value;
			decimalPos += 1;
		}

		if (decimalLength > 2) {
			//incase get formattedValue such as 17.253
			formattedValue = value.substr(0, decimalPos + 3);
		} else if (decimalLength == 2) {
			formattedValue = value + "";
		} else if (decimalLength == 1) {
			formattedValue = value + "0";
		} else if (decimalLength == 0) {
			formattedValue = value + "00";
		} else {
			formattedValue = value + ".00";
		}
		
		if (formattedValue.indexOf('.') == 0) formattedValue = "0" + formattedValue;
	} 
	
	return formattedValue;
}

// @~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@
//	TotalTableColumn
// @~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@
function TotalTableColumn(oTable, oTotalTable, ColumnNumber, SumColumnNumber, OnlyReadOnly)
{

	// Make sure we can get a reference to the tables
	if (oTable == null) return;
	
	if (OnlyReadOnly == null) OnlyReadOnly = false;
	
	var dTotal = 0;
	var iRowCount = oTable.rows.length;
	for(var iCurrentRow = 0; iCurrentRow < iRowCount; iCurrentRow++)
	{
		
		var dValue = GetCellValue(oTable, iCurrentRow, ColumnNumber, OnlyReadOnly);
		dTotal += dValue;
	}
	
	if (oTotalTable != null)
	{
		// Update the text value for the summary table
		oTotalTable.rows(0).cells(SumColumnNumber).innerText = MoneyFormat(dTotal);
	}
	
	return dTotal;

}
// @~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@
//	GetCellValue
//		Returns the value of a cell, the contents
//		can be just text or a HTML Element that
//		supports the value property
//
//		NOTE: OnlyReadOnly returns a value if
//		the text was found in a table cell (no Input)
// @~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@
function GetCellValue(oTable, RowNumber, ColumnNumber, OnlyReadOnly)
{
		
	var sValue;
	var dValue=0;
	var dReturn=0;
	// Get the column
	var oCell = oTable.rows(RowNumber).cells(ColumnNumber);
	
	if (oCell.innerText=="" || oCell.innerHTML=="")
	{
		if (OnlyReadOnly == false)
		{
			// must be input box
			sValue = oCell.childNodes.item(0).value;
			dValue = parseFloat(sValue);
			if (isNaN(dValue))
			{}
			else
				dReturn = dValue;
		}
	}
	else
	{
		// must be a read only row
		dValue = parseFloat(oCell.innerText);
		if (isNaN(dValue))
		{
		}
		else
			dReturn = dValue;
	}
	oCell = null;
	return dReturn;
	
}
// @~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@
//	GetCellValue
//		Returns the value of a cell, the contents
//		can be just text or a HTML Element that
//		supports the value property
//
//		NOTE: OnlyReadOnly returns a value if
//		the text was found in a table cell (no Input)
// @~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@
function GetCellText(oTable, RowNumber, ColumnNumber, OnlyReadOnly, ChildNodeNumber)
{
		
	var sReturn="";
	if (ChildNodeNumber == null) ChildNodeNumber = 0;
	
	// Get the column
	var oCell = oTable.rows(RowNumber).cells(ColumnNumber);
	
	if (oCell.getElementsByTagName("SELECT").length==1 && OnlyReadOnly == false)
	{
		sReturn = oCell.childNodes.item(ChildNodeNumber).value;
	}
	else if (oCell.getElementsByTagName("INPUT").length==1 && OnlyReadOnly == false)
	{
		sReturn = oCell.childNodes.item(ChildNodeNumber).value;
	}
	else if (oCell.getElementsByTagName("TEXTAREA").length==1 && OnlyReadOnly == false)
	{
		sReturn = oCell.childNodes.item(ChildNodeNumber).value;
	}
	else if (oCell.getElementsByTagName("A").length==1 && OnlyReadOnly == false)
	{
		sReturn = oCell.childNodes.item(ChildNodeNumber).value;
	}
	else
		sReturn = oCell.innerText;
		
	
	oCell = null;
	return sReturn;
	
}
// @~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@
//	ClearTable
//		sTable could be the ControlId or the actual
//		Table Object
// @~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@
function ClearTable(sTable)
{
	// Clear the table
	if (typeof(sTable) != "object")
	{
		//Try to create it (in case the string was passed)
		oTable=getElem(sTable)
		if (oTable == null) return
	}
	else
	{
		oTable = sTable
	}
	
	
	var iCount = oTable.rows.length-1
	for (i = 0; oTable.rows.length; i++)
	{
		oTable.deleteRow(0);
	}
}
// @~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@
//	Select the row specified
// @~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@
function SelectTableRow(TableId, RowId, RowNumber)
{

	var oTable = getElem(TableId);
	
	for(i=0;i<oTable.rows.length;i++)
	{
		var row = getElem(RowId + i)
		
		if (i==RowNumber)
		{
			if (i % 2 ==0)
				row.className="DataGridItemAltSelectedItem"
			else
				row.className="DataGridItemSelectedItem"
		}
		else
		{
			if (i % 2 ==0)
				row.className="DataGridItemAlt"
			else
				row.className="DataGridItem"
		}

	}
}

// String Extensions
String.prototype.lTrim=function()
{
    return this.replace(/^(\s|\xA0)*/,"");
};
String.prototype.rTrim=function()
{
    return this.replace(/(\s|\xA0)*$/,"");
};
String.prototype.trim=function()
{
    return this.rTrim().lTrim();
};
String.prototype.endsWith=function(c)
{
    return this.substr(this.length-c.length)==c;
};
String.prototype.startsWith=function(e)
{
    return this.substr(0,e.length)==e;
};
String.prototype.format=function()
{
    var s=this;
    for(var i=0;
    i<arguments.length;i++)
    {
        s=s.replace("{"+i+"}",arguments[i]);
    }
    return s;
};
String.prototype.removeSpaces=function()
{
    return this.replace(/ /ig,"");
};
String.prototype.removeExtraSpaces=function()
{
    return this.replace(String.prototype.removeExtraSpaces.re," ");
};
String.prototype.removeExtraSpaces.re=new RegExp("\\s+","g");
String.prototype.removeSpaceDelimitedString=function(r)
{
    var s=" "+this.trim()+" ";
    return s.replace(" "+r,"").rTrim();
};
String.prototype.encodeURI=function()
{
    var returnString;
    returnString=escape(this);
    returnString=returnString.replace(/\+/g,"%2B");
    return returnString;
};
String.prototype.decodeURI=function()
{
    return unescape(this);
};
String.prototype.encodeHtml=function()
{
    var returnString=this.replace(/\>/g,"&gt;").replace(/\</g,"&lt;").replace(/\&/g,"&amp;").replace(/\'/g,"&#039;").replace(/\"/g,"&quot;");
    return returnString;
};

// Array Extensions
Array.prototype.indexOf=function(R)
{
    for(var i=0;
    i<this.length;i++)
    {
        if(this[i]==R)
            return i;
    }
    return -1;
};
Array.prototype.exists=function(S)
{
    return this.indexOf(S)!=-1;
};
Array.prototype.add=Array.prototype.queue=function(T)
{
    this.push(T);
};
Array.prototype.addRange=function(U)
{
    var length=U.length;
    if(length!=0)
        for(var index=0;
        index<length;index++)
        {
            this.push(U[index]);
        }
};
Array.prototype.contains=function(V)
{
    var index=this.indexOf(V);
    return index>=0;
};
Array.prototype.dequeue=function()
{
    return this.shift();
};
Array.prototype.insert=function(W,X)
{
    this.splice(W,0,X);
};
Array.prototype.clone=function()
{
    var clonedArray=[];
    var length=this.length;
    for(var index=0;
    index<length;index++)
    {
        clonedArray[index]=this[index];
    }
    return clonedArray;
};
Array.prototype.removeAt=function(Y)
{
    return this.splice(Y,1);
};
Array.prototype.remove=function(o)
{
    var i=this.indexOf(o);
    if(i>-1)
        this.splice(i,1);
    return i>-1;
};
Array.prototype.clear=function()
{
    if(this.length>0)
        this.splice(0,this.length);
}

function buildBubble(x,y, h, w)
{
	if (x=-null || y==null || h==null || w==null)
		return;
	
	var dBubble = document.createElement("DIV");
	var dNW = createDiv("NE", "images/gmaps/iw_nw.png");
	var dNE = createDiv("NE", "images/gmaps/iw_ne.png");
	var dSW = createDiv("SW", "images/gmaps/iw_sw.png");
	var dSE = createDiv("SE", "images/gmaps/iw_se.png");
	var dN = createDiv("N", "images/gmaps/iw_n.png");
	var dS = createDiv("S", "images/gmaps/iw_s.png");
	var dE = createDiv("E", "images/gmaps/iw_e.png");
	var dW = createDiv("W", "images/gmaps/iw_w.png");
	var dTAP = createDiv("TAP", "images/gmaps/iw_tap_sw.png");
	var dShadow = createDiv("Shadow", "images/gmaps/shadow_sw.png");
	
	dNW.left = 10;
	dNW.width=10;
	dNW.top = 100;
	dNE.left = 100;
	dNE.top = 100
	dNE.width = 10; 
	dN.width = 90; 
	dN.left= dNW.left + dNW.width;
	
	dBubble.insertBefore(dNW,null);
	dBubble.insertBefore(dNE,null);
	dBubble.insertBefore(dSW,null);
	dBubble.insertBefore(dSE,null);
	dBubble.insertBefore(dN,null);
	dBubble.insertBefore(dS,null);
	dBubble.insertBefore(dE,null);
	dBubble.insertBefore(dW,null);
	dBubble.insertBefore(dTAP,null);
	dBubble.insertBefore(dShadow,null);
	dBubble.style.display = "block";
	dBubble.style.position = "absolute";
	
}

function createDiv(idName, src)
{
	var dN = document.createElement("DIV");
	var img = document.createElement("IMG");
	
	dN.className = 'wb' + idName;
	dN.id = "d" + idName;
	img.id = "i" + idName;
	img.style.visibility = "hidden";
	img.src = src;
	dN.insertBefore(img, null);
	
	return dN;
}

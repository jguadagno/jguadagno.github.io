function GetContact()
{

	DisplayMessage(msgTypePleaseWait, "Loading record", "");
	// Clear the table
	ClearTable("tblContact");
	CreateRowTitle("Property", "&nbsp;", "Value");
	
	// Get the contact id
	var oContactId = getElem("txtLoadContactId");
	var contactId = oContactId.value;
	
	// Short cut to avoid Callback rountine
	Contacts.Sample6_ContactWithTeam.ReturnClass(contactId, GetContact_Callback); 

}
function GetContact_Callback(response)
{

	if (response.error != null)
	{
		//alert (response.message);
		DisplayMessage(msgTypeCritical, response.error, "GetContact");
		return;
	}

	var oReadOnly = getElem("chkReadOnly");
	var bReadOnly = oReadOnly.checked;

	var contact = response.value;
	
	CreateRow("ContactId", contact.ContactId, 1, bReadOnly);
	CreateRow("FirstName", contact.FirstName, 0, bReadOnly);
	CreateRow("MiddleName", contact.MiddleName, 1, bReadOnly);
	CreateRow("LastName", contact.LastName, 0, bReadOnly);
	CreateRow("HomeNumber", contact.HomeNumber, 1, bReadOnly);
	CreateRow("WorkNumber", contact.WorkNumber, 0, bReadOnly);
	CreateRow("MobileNumber", contact.MobileNumber, 1, bReadOnly);
	CreateRow("Email1", contact.Email1, 0, bReadOnly);
	CreateRow("Email2", contact.Email2, 1, bReadOnly);
	CreateRow("Email3", contact.Email3, 0, bReadOnly);
	CreateRow("Address1", contact.Address1, 1, bReadOnly);
	CreateRow("Address2", contact.Address2, 0, bReadOnly);
	CreateRow("CityName", contact.CityName, 1, bReadOnly);
	CreateRow("State", contact.State, 0, bReadOnly);
	CreateRow("ZipCode", contact.ZipCode, 1, bReadOnly);
	CreateRow("ZipPlus4", contact.ZipPlus4, 0, bReadOnly);
	
	if (typeof(contact.Team) != "undefined" && contact.Team != null)
	{
		CreateDDLRow("League", contact.Team.LeagueName, contact.Team.LeagueId, "", 1, bReadOnly);
		CreateDDLRow("Conference", contact.Team.ConferenceName, contact.Team.ConferenceId, contact.Team.LeagueId, 0, bReadOnly);
		CreateDDLRow("Division", contact.Team.DivisionName, contact.Team.DivisionId, contact.Team.ConferenceId, 1, bReadOnly);
		CreateDDLRow("Team", contact.Team.TeamName, contact.Team.TeamId, contact.Team.DivisionId, 0, bReadOnly);
	}
	else
	{
		CreateDDLRow("League", "","", "", 1, bReadOnly);
		CreateDDLRow("Conference", "","", "", 0, bReadOnly);
		CreateDDLRow("Division", "","", "", 1, bReadOnly);
		CreateDDLRow("Team", "","", "", 0, bReadOnly);
	}
		
	DisableControl("txtContactId");
	
	contact = null;
	DisplayMessage(msgTypeSuccessComplete, "Done!", "")
	
}

function AddContact()
{

	// Clear the table
	ClearTable("tblContact");
	CreateRowTitle("Property", "&nbsp;", "Value");

	var oReadOnly = getElem("chkReadOnly");
	var bReadOnly = oReadOnly.checked = false;
	
	CreateRow("ContactId", "0", 1, bReadOnly);
	CreateRow("FirstName", "", 0, bReadOnly);
	CreateRow("MiddleName", "", 1, bReadOnly);
	CreateRow("LastName", "", 0, bReadOnly);
	CreateRow("HomeNumber", "", 1, bReadOnly);
	CreateRow("WorkNumber", "", 0, bReadOnly);
	CreateRow("MobileNumber", "", 1, bReadOnly);
	CreateRow("Email1", "", 0, bReadOnly);
	CreateRow("Email2", "", 1, bReadOnly);
	CreateRow("Email3", "", 0, bReadOnly);
	CreateRow("Address1", "", 1, bReadOnly);
	CreateRow("Address2", "", 0, bReadOnly);
	CreateRow("CityName", "", 1, bReadOnly);
	CreateRow("State", "", 0, bReadOnly);
	CreateRow("ZipCode", "", 1, bReadOnly);
	CreateRow("ZipPlus4", "", 0, bReadOnly);

	CreateDDLRow("League", "", "", "", 1, bReadOnly);
	CreateDDLRow("Conference", "", "", "", 0, bReadOnly);
	CreateDDLRow("Division", "", "", "", 1, bReadOnly);
	CreateDDLRow("Team", "", "", "", 0, bReadOnly);

	
	DisableControl("txtContactId");
}

function SaveContact()
{
	DisplayMessage(msgTypePleaseWait, "Saving Record", "");
	
	var contact = new Object();
	
	contact.ContactId = getElem("txtContactId").value;
	contact.FirstName = getElem("txtFirstName").value;
	contact.MiddleName = getElem("txtMiddleName").value;
	contact.LastName = getElem("txtLastName").value;
	contact.HomeNumber = getElem("txtHomeNumber").value;
	contact.WorkNumber = getElem("txtWorkNumber").value;
	contact.MobileNumber  = getElem("txtMobileNumber").value;
	contact.Email1 = getElem("txtEmail1").value;
	contact.Email2  = getElem("txtEmail2").value;
	contact.Email3 = getElem("txtEmail3").value;
	contact.Address1  = getElem("txtAddress1").value;
	contact.Address2  = getElem("txtAddress2").value;
	contact.CityName = getElem("txtCityName").value;
	contact.State  = getElem("txtState").value;
	contact.ZipCode = getElem("txtZipCode").value;
	contact.ZipPlus4 = getElem("txtZipPlus4").value;
	var Team = new Object();
	var oTeam = getElem("ddlTeam");
	if (oTeam != null)
		Team.TeamId = oTeam.value;
	else
		Team.TeamId = "";
		
	contact.Team = Team;
	
	Contacts.Sample6_ContactWithTeam.SaveContact(contact, SaveContact_Callback);
	
	contact = null;

}

function SaveContact_Callback(response)
{

	if (response.error != null)
	{
		DisplayMessage(msgTypeCritical, response.error, "SaveContact");
		return;
	}

	DisplayMessage(msgTypeSuccessComplete, "Save was successful!", "");
}

function CreateRowTitle(Field1, Field2, Field3)
{
	var oTR = getElem("tblContact").insertRow(-1);
	var oTDName;
	var oTDBlank;
	var oTDValue;
	oTR.className="PropertyGridSubHeader";
	oTDName = oTR.insertCell(-1);
	oTDName.innerHTML = Field1
	oTDBlank = oTR.insertCell(-1);
	oTDBlank.innerHTML = Field2
	oTDValue = oTR.insertCell(-1);
	oTDValue.width="100%";
	oTDValue.innerHTML = Field3
}
function CreateRow(PropertyName, PropertyValue, OddOrEven, ReadOnly)
{
	var oTR = getElem("tblContact").insertRow(-1);
	var oTDName;
	var oTDBlank;
	var oTDValue;

	if (OddOrEven == 0)
		oTR.className = "PropertyRow";
	else
		oTR.className = "PropertyRowAlt";

	oTDName = oTR.insertCell(-1);
	oTDName.innerHTML = GetHTMLText(PropertyName, false);
	oTDBlank = oTR.insertCell(-1);
	oTDBlank.innerHTML = "&nbsp;"
	oTDValue = oTR.insertCell(-1);
	oTDValue.width="100%";
	if (ReadOnly == true)
		oTDValue.innerHTML = GetHTMLText(PropertyValue, false);
	else
	{
		var oText = document.createElement("INPUT");
		oText.type = "text";
		oText.value = GetText(PropertyValue, false);
		oText.width=255;
		oText.id = "txt" + PropertyName;
		oTDValue.insertBefore(oText, null);
		oText = null;
	}
	
	oTDName = null;
	oTDBlank = null;
	oTDValue = null;
			
}

function CreateDDLRow(PropertyName, PropertyText, PropertyValue, ParentId, OddOrEven, ReadOnly)
{
	var oTR = getElem("tblContact").insertRow(-1);
	var oTDName;
	var oTDBlank;
	var oTDValue;

	if (OddOrEven == 0)
		oTR.className = "PropertyRow";
	else
		oTR.className = "PropertyRowAlt";

	oTDName = oTR.insertCell(-1);
	oTDName.innerHTML = GetHTMLText(PropertyName, false);
	oTDBlank = oTR.insertCell(-1);
	oTDBlank.innerHTML = "&nbsp;"
	oTDValue = oTR.insertCell(-1);
	oTDValue.width="100%";
	if (ReadOnly == true)
		oTDValue.innerHTML = GetHTMLText(PropertyText  + " (" + PropertyValue + ")", false);
	else
	{
		// Create the drop down list
		
		var oDiv = document.createElement("DIV");
		oDiv.id = "div" + PropertyName;
		oTDValue.insertBefore(oDiv, null);
		DisplayMessage(msgTypePleaseWait, "Loading the list for '" + PropertyName + "'...", "");
		switch(PropertyName)
		{
			case "League":
				Contacts.Sample6_ContactWithTeam.GetLeagues(PropertyValue, CreateLeague);
				break;
				
			case "Conference":
				if (ParentId != "")
					Contacts.Sample6_ContactWithTeam.GetConferencesByLeague(PropertyValue, ParentId, CreateConference);
				break;
				
			case "Division":
				if (ParentId != "")
					Contacts.Sample6_ContactWithTeam.GetDivisionsByConference(PropertyValue, ParentId, CreateDivision);
				break;
				
			case "Team":
				if (ParentId != "")
					Contacts.Sample6_ContactWithTeam.GetTeamsByDivision(PropertyValue, ParentId, CreateTeam);
				break;
		}
		
	}
	
	oTDName = null;
	oTDBlank = null;
	oTDValue = null;
}
function ReadOnlyClicked()
{
	if (getElem("chkReadOnly").checked == true)
		DisableButton("tbSave");
	else
		EnableButton("tbSave");
}
function CreateLeague(response)
{
	if (response.error != null)
	{
		DisplayMessage(msgTypeCritical, response.error, "LeagueClicked");
		return;
	}

	if (response.value == null)
	{
		// Nothing returned from the server
		return;
	}

	oControl = getElem("divLeague");
	oControl.innerHTML = response.value;
	
	DisplayMessage(msgTypeSuccessComplete, "Load was successful!", "");

	response = null;
}

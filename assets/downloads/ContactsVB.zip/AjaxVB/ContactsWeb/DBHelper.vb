Imports System

Namespace Utility
   '/ <summary>
   '/ Summary description for Utility.
   '/ </summary>
   
   Public Class DBHelper
      
      Public Sub New()
      End Sub 'New
      
        Public Shared Function NotNullDBValue(ByVal Invalue As String) As String
            If Invalue Is Nothing Then
                Return ""
            Else
                Return Invalue
            End If
        End Function 'NotNullDBValue


        '/ <summary>
        '/ Adds a blank row to the passed DataTable
        '/ </summary>
        '/ <param name="dt">The DataTable to add the blank rows to</param>
        '/ <returns></returns>
        Public Overloads Shared Function AddBlankRowsToTable(ByVal dt As System.Data.DataTable) As System.Data.DataTable
            ' create the "dummy" record used to add blank rows
            Dim dummyData(0) As String

            ' Add and extra row
            dt.Rows.Add(dummyData)
            Return dt
        End Function 'AddBlankRowsToTable

        Public Overloads Shared Function AddBlankRowsToTable(ByVal dt As System.Data.DataTable, ByVal NumberOfRowsToAdd As Integer) As System.Data.DataTable
            Dim i As Integer
            For i = 1 To NumberOfRowsToAdd
                dt = AddBlankRowsToTable(dt)
            Next i

            Return dt
        End Function 'AddBlankRowsToTable 
    End Class 'DBHelper
End Namespace 'Utility 

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'usp_LookupZipCodeByZipCode')
	BEGIN
		PRINT 'Dropping Procedure usp_LookupZipCodeByZipCode'
		DROP  Procedure  usp_LookupZipCodeByZipCode
	END

GO

PRINT 'Creating Procedure usp_LookupZipCodeByZipCode'
GO
CREATE Procedure usp_LookupZipCodeByZipCode
	@ZipCode varchar(5)
AS

/******************************************************************************
**		File: 
**		Name: Stored_Procedure_Name
**		Desc: 
**
**		This template can be customized:
**              
**		Return values:
** 
**		Called by:   
**              
**		Parameters:
**		Input							Output
**     ----------							-----------
**
**		Auth: 
**		Date: 
*******************************************************************************
**		Change History
*******************************************************************************
**		Date:		Author:				Description:
**		--------		--------				-------------------------------------------
**    
*******************************************************************************/

SELECT ZipCode FROM CityRef
WHERE ZipCode LIKE @ZipCode



GO

GRANT EXEC ON usp_LookupZipCodeByZipCode TO PUBLIC

GO

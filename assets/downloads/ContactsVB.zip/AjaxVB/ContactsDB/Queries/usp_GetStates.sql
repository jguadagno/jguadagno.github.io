IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'usp_GetStates')
	BEGIN
		PRINT 'Dropping Procedure usp_GetStates'
		DROP  Procedure  usp_GetStates
	END

GO

PRINT 'Creating Procedure usp_GetStates'
GO
CREATE Procedure usp_GetStates
	/* Param List */
AS

/******************************************************************************
**		File: 
**		Name: Stored_Procedure_Name
**		Desc: 
**
**		This template can be customized:
**              
**		Return values:
** 
**		Called by:   
**              
**		Parameters:
**		Input							Output
**     ----------							-----------
**
**		Auth: 
**		Date: 
*******************************************************************************
**		Change History
*******************************************************************************
**		Date:		Author:				Description:
**		--------		--------				-------------------------------------------
**    
*******************************************************************************/

SELECT * FROM StateRef



GO

GRANT EXEC ON usp_GetStates TO PUBLIC

GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'usp_LookupStatesByState')
	BEGIN
		PRINT 'Dropping Procedure usp_LookupStatesByState'
		DROP  Procedure  usp_LookupStatesByState
	END

GO

PRINT 'Creating Procedure usp_LookupStatesByState'
GO
CREATE Procedure usp_LookupStatesByState
	@State char(2)
AS

/******************************************************************************
**		File: 
**		Name: Stored_Procedure_Name
**		Desc: 
**
**		This template can be customized:
**              
**		Return values:
** 
**		Called by:   
**              
**		Parameters:
**		Input							Output
**     ----------							-----------
**
**		Auth: 
**		Date: 
*******************************************************************************
**		Change History
*******************************************************************************
**		Date:		Author:				Description:
**		--------		--------				-------------------------------------------
**    
*******************************************************************************/

SELECT * FROM StateRef WHERE State Like @State



GO

GRANT EXEC ON usp_LookupStatesByState TO PUBLIC

GO

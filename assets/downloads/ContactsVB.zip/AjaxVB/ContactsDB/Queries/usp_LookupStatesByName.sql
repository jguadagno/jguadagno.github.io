IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'usp_LookupStatesByName')
	BEGIN
		PRINT 'Dropping Procedure usp_LookupStatesByName'
		DROP  Procedure  usp_LookupStatesByName
	END

GO

PRINT 'Creating Procedure usp_LookupStatesByName'
GO
CREATE Procedure usp_LookupStatesByName
	@StateName varchar(50)
AS

/******************************************************************************
**		File: 
**		Name: Stored_Procedure_Name
**		Desc: 
**
**		This template can be customized:
**              
**		Return values:
** 
**		Called by:   
**              
**		Parameters:
**		Input							Output
**     ----------							-----------
**
**		Auth: 
**		Date: 
*******************************************************************************
**		Change History
*******************************************************************************
**		Date:		Author:				Description:
**		--------		--------				-------------------------------------------
**    
*******************************************************************************/

SELECT * FROM StateRef 
WHERE StateName LIKE @StateName


GO

GRANT EXEC ON usp_LookupStatesByName TO PUBLIC

GO

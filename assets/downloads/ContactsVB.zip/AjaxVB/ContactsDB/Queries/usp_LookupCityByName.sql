IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'usp_LookupCityByName')
	BEGIN
		PRINT 'Dropping Procedure usp_LookupCityByName'
		DROP  Procedure  usp_LookupCityByName
	END

GO

PRINT 'Creating Procedure usp_LookupCityByName'
GO
CREATE Procedure usp_LookupCityByName
	@CityName varchar(50)
AS

/******************************************************************************
**		File: 
**		Name: Stored_Procedure_Name
**		Desc: 
**
**		This template can be customized:
**              
**		Return values:
** 
**		Called by:   
**              
**		Parameters:
**		Input							Output
**     ----------							-----------
**
**		Auth: 
**		Date: 
*******************************************************************************
**		Change History
*******************************************************************************
**		Date:		Author:				Description:
**		--------		--------				-------------------------------------------
**    
*******************************************************************************/

SELECT DISTINCT(CityName) FROM CityRef
WHERE CityName Like @CityName


GO

GRANT EXEC ON usp_LookupCityByName TO PUBLIC

GO

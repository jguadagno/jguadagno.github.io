
/****** Object:  StoredProcedure [usp_LeagueLoadByPrimaryKey]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_LeagueLoadByPrimaryKey]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_LeagueLoadByPrimaryKey];
GO

CREATE PROCEDURE [usp_LeagueLoadByPrimaryKey]
(
	@LeagueId int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err int

	SELECT
		[LeagueId],
		[LeagueName]
	FROM [League]
	WHERE
		([LeagueId] = @LeagueId)

	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_LeagueLoadByPrimaryKey Succeeded'
ELSE PRINT 'Procedure Creation: usp_LeagueLoadByPrimaryKey Error on Creation'
GO

/****** Object:  StoredProcedure [usp_LeagueLoadAll]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_LeagueLoadAll]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_LeagueLoadAll];
GO

CREATE PROCEDURE [usp_LeagueLoadAll]
AS
BEGIN

	SET NOCOUNT ON
	DECLARE @Err int

	SELECT
		[LeagueId],
		[LeagueName]
	FROM [League]

	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_LeagueLoadAll Succeeded'
ELSE PRINT 'Procedure Creation: usp_LeagueLoadAll Error on Creation'
GO

/****** Object:  StoredProcedure [usp_LeagueUpdate]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_LeagueUpdate]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_LeagueUpdate];
GO

CREATE PROCEDURE [usp_LeagueUpdate]
(
	@LeagueId int,
	@LeagueName varchar(50) = NULL
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	UPDATE [League]
	SET
		[LeagueName] = @LeagueName
	WHERE
		[LeagueId] = @LeagueId


	SET @Err = @@Error


	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_LeagueUpdate Succeeded'
ELSE PRINT 'Procedure Creation: usp_LeagueUpdate Error on Creation'
GO




/****** Object:  StoredProcedure [usp_LeagueInsert]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_LeagueInsert]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_LeagueInsert];
GO

CREATE PROCEDURE [usp_LeagueInsert]
(
	@LeagueId int = NULL output,
	@LeagueName varchar(50) = NULL
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	INSERT
	INTO [League]
	(
		[LeagueName]
	)
	VALUES
	(
		@LeagueName
	)

	SET @Err = @@Error

	SELECT @LeagueId = SCOPE_IDENTITY()

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_LeagueInsert Succeeded'
ELSE PRINT 'Procedure Creation: usp_LeagueInsert Error on Creation'
GO

/****** Object:  StoredProcedure [usp_LeagueDelete]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_LeagueDelete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_LeagueDelete];
GO

CREATE PROCEDURE [usp_LeagueDelete]
(
	@LeagueId int
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	DELETE
	FROM [League]
	WHERE
		[LeagueId] = @LeagueId
	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_LeagueDelete Succeeded'
ELSE PRINT 'Procedure Creation: usp_LeagueDelete Error on Creation'
GO

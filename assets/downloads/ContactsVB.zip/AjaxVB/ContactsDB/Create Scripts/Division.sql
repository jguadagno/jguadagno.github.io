
/****** Object:  StoredProcedure [usp_DivisionLoadByPrimaryKey]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_DivisionLoadByPrimaryKey]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_DivisionLoadByPrimaryKey];
GO

CREATE PROCEDURE [usp_DivisionLoadByPrimaryKey]
(
	@DivisionId int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err int

	SELECT
		[DivisionId],
		[ConferenceId],
		[DivisionName]
	FROM [Division]
	WHERE
		([DivisionId] = @DivisionId)

	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_DivisionLoadByPrimaryKey Succeeded'
ELSE PRINT 'Procedure Creation: usp_DivisionLoadByPrimaryKey Error on Creation'
GO

/****** Object:  StoredProcedure [usp_DivisionLoadAll]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_DivisionLoadAll]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_DivisionLoadAll];
GO

CREATE PROCEDURE [usp_DivisionLoadAll]
AS
BEGIN

	SET NOCOUNT ON
	DECLARE @Err int

	SELECT
		[DivisionId],
		[ConferenceId],
		[DivisionName]
	FROM [Division]

	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_DivisionLoadAll Succeeded'
ELSE PRINT 'Procedure Creation: usp_DivisionLoadAll Error on Creation'
GO

/****** Object:  StoredProcedure [usp_DivisionUpdate]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_DivisionUpdate]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_DivisionUpdate];
GO

CREATE PROCEDURE [usp_DivisionUpdate]
(
	@DivisionId int,
	@ConferenceId int = NULL,
	@DivisionName varchar(50) = NULL
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	UPDATE [Division]
	SET
		[ConferenceId] = @ConferenceId,
		[DivisionName] = @DivisionName
	WHERE
		[DivisionId] = @DivisionId


	SET @Err = @@Error


	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_DivisionUpdate Succeeded'
ELSE PRINT 'Procedure Creation: usp_DivisionUpdate Error on Creation'
GO




/****** Object:  StoredProcedure [usp_DivisionInsert]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_DivisionInsert]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_DivisionInsert];
GO

CREATE PROCEDURE [usp_DivisionInsert]
(
	@DivisionId int = NULL output,
	@ConferenceId int = NULL,
	@DivisionName varchar(50) = NULL
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	INSERT
	INTO [Division]
	(
		[ConferenceId],
		[DivisionName]
	)
	VALUES
	(
		@ConferenceId,
		@DivisionName
	)

	SET @Err = @@Error

	SELECT @DivisionId = SCOPE_IDENTITY()

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_DivisionInsert Succeeded'
ELSE PRINT 'Procedure Creation: usp_DivisionInsert Error on Creation'
GO

/****** Object:  StoredProcedure [usp_DivisionDelete]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_DivisionDelete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_DivisionDelete];
GO

CREATE PROCEDURE [usp_DivisionDelete]
(
	@DivisionId int
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	DELETE
	FROM [Division]
	WHERE
		[DivisionId] = @DivisionId
	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_DivisionDelete Succeeded'
ELSE PRINT 'Procedure Creation: usp_DivisionDelete Error on Creation'
GO

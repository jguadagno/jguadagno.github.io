
Imports System
Imports System.Data
Imports Contacts.DAL


Namespace Contacts
   '/ <summary>
   '/ Business Layer for the contacts library
   '/ </summary>
   
   Public Class BusinessLayer
      
      Public Sub New()
      End Sub 'New
      
      
      
      '/ <summary>
      '/ Find a contact by first name
      '/ </summary>
      '/ <param name="FirstName"></param>
      '/ <returns></returns>
      Overloads Public Shared Function FindContactByName(FirstName As String) As DataSet
         Dim sFirstName As String = "%"c + FirstName + "%"c
         
         Return FindContactByName(sFirstName, "%"c.ToString())
      End Function 'FindContactByName
      
      
      '/ <summary>
      '/ Searches for a contact by partial first name, and partial last name
      '/ </summary>
      '/ <param name="FirstName">The first name to search for</param>
      '/ <param name="LastName">The last name to search for</param>
      '/ <returns></returns>
      Overloads Public Shared Function FindContactByName(FirstName As String, LastName As String) As DataSet
            ' usp_SearchForContactInformation	
            FirstName = "%" + FirstName + "%"
            LastName = "%" + LastName + "%"

            Dim oDBParms As New DBParmCollection
            oDBParms.add(New DBParms("@FirstName", FirstName, SqlDbType.Char, ParameterDirection.Input))
            oDBParms.add(New DBParms("@LastName", LastName, SqlDbType.Char, ParameterDirection.Input))

            Return New SqlConnect().datasetGen("usp_SearchForContactInformation", oDBParms)
      End Function 'FindContactByName
       
      
      '/ <summary>
      '/ Searches contact information. Search email (1,2,3), first, middle, last names
      '/ </summary>
      '/ <param name="search">Any search string</param>
      '/ <returns></returns>
      Public Shared Function FindContact(SearchString As String) As DataSet
         
         ' usp_SearchForContactInformationAll
         SearchString = "%" + SearchString + "%"
         Dim oDBParms As New DBParmCollection()
         oDBParms.add(New DBParms("@SearchString", SearchString, SqlDbType.Char, ParameterDirection.Input))
         
         Return New SqlConnect().datasetGen("usp_SearchForContactInformationAll", oDBParms)
      End Function 'FindContact
   End Class 'BusinessLayer 
   
   '/ <summary>
   '/ Post Office Lookup functions
   '/ </summary>
   
   Public Class PO
      
      Public Sub New()
      End Sub 'New
      
      
      
      Public Shared Function GetCities() As DataSet
         Return New SqlConnect().datasetGen("usp_GetCities")
      End Function 'GetCities
      
      Public Shared Function GetStates() As DataSet
         Return New SqlConnect().datasetGen("usp_GetStates")
      End Function 'GetStates
      
      Public Shared Function GetZipCodes() As DataSet
         Return New SqlConnect().datasetGen("usp_GetZipCodes")
      End Function 'GetZipCodes
      
      
      Overloads Public Shared Function LookupCityByName() As DataSet
         Return LookupCityByName("")
      End Function 'LookupCityByName
      
      Overloads Public Shared Function LookupCityByName(CityName As String) As DataSet
         CityName = CityName + "%"
         
         Dim oDBParms As New DBParmCollection()
         oDBParms.add(New DBParms("@CityName", CityName, SqlDbType.Char, ParameterDirection.Input))
         
         Return New SqlConnect().datasetGen("usp_LookupCityByName", oDBParms)
      End Function 'LookupCityByName
      
      
      Overloads Public Shared Function LookupCityByZipCode() As DataSet
         Return LookupCityByZipCode("")
      End Function 'LookupCityByZipCode
      
      Overloads Public Shared Function LookupCityByZipCode(ZipCode As String) As DataSet
         ZipCode = ZipCode + "%"
         
         Dim oDBParms As New DBParmCollection()
         oDBParms.add(New DBParms("@ZipCode", ZipCode, SqlDbType.Char, ParameterDirection.Input))
         
         Return New SqlConnect().datasetGen("usp_LookupCityByZipCode", oDBParms)
      End Function 'LookupCityByZipCode
      
      
      Overloads Public Shared Function LookupStatesByState() As DataSet
         Return LookupStatesByState("")
      End Function 'LookupStatesByState
      
      Overloads Public Shared Function LookupStatesByState(State As String) As DataSet
         State = State + "%"
         
         Dim oDBParms As New DBParmCollection()
         oDBParms.add(New DBParms("@State", State, SqlDbType.Char, ParameterDirection.Input))
         
         Return New SqlConnect().datasetGen("usp_LookupStatesByState", oDBParms)
      End Function 'LookupStatesByState
      
      Overloads Public Shared Function LookupStatesByStateName() As DataSet
         Return LookupStatesByStateName("")
      End Function 'LookupStatesByStateName
      
      Overloads Public Shared Function LookupStatesByStateName(StateName As String) As DataSet
         StateName = StateName + "%"
         
         Dim oDBParms As New DBParmCollection()
         oDBParms.add(New DBParms("@StateName", StateName, SqlDbType.Char, ParameterDirection.Input))
         
         Return New SqlConnect().datasetGen("usp_LookupStatesByStateName", oDBParms)
      End Function 'LookupStatesByStateName
      
      Overloads Public Shared Function LookupZipCodeByZipCode() As DataSet
         Return LookupZipCodeByZipCode("")
      End Function 'LookupZipCodeByZipCode
      
      Overloads Public Shared Function LookupZipCodeByZipCode(ZipCode As String) As DataSet
         ZipCode = ZipCode + "%"
         
         Dim oDBParms As New DBParmCollection()
         oDBParms.add(New DBParms("@ZipCode", ZipCode, SqlDbType.Char, ParameterDirection.Input))
         
         Return New SqlConnect().datasetGen("usp_LookupZipCodeByZipCode", oDBParms)
      End Function 'LookupZipCodeByZipCode
   End Class 'PO 
End Namespace 'Contacts
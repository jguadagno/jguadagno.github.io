
Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports Contacts.DAL


Namespace Contacts
   '/ <summary>
   '/ Summary description for Team.
   '/ </summary>
   
   Public Class Team
      
        Public Sub New()
        End Sub 'New

#Region "Private Properties"
        Private _LeagueId As Integer
        Private _LeagueName As String
        Private _ConferenceId As Integer
        Private _ConferenceName As String
        Private _DivisionId As Integer
        Private _DivisionName As String
        Private _TeamId As Integer
        Private _TeamName As String

#End Region

#Region "Public Properties"
        Public Property LeagueId() As Integer
            Get
                Return _LeagueId
            End Get
            Set(ByVal Value As Integer)
                _LeagueId = Value
            End Set
        End Property
        Public Property LeagueName() As String
            Get
                Return _LeagueName
            End Get
            Set(ByVal Value As String)
                _LeagueName = Value
            End Set
        End Property
        Public Property ConferenceId() As Integer
            Get
                Return _ConferenceId
            End Get
            Set(ByVal Value As Integer)
                _ConferenceId = Value
            End Set
        End Property
        Public Property ConferenceName() As String
            Get
                Return _ConferenceName
            End Get
            Set(ByVal Value As String)
                _ConferenceName = Value
            End Set
        End Property
        Public Property DivisionId() As Integer
            Get
                Return _DivisionId
            End Get
            Set(ByVal Value As Integer)
                _DivisionId = Value
            End Set
        End Property
        Public Property DivisionName() As String
            Get
                Return _DivisionName
            End Get
            Set(ByVal Value As String)
                _DivisionName = Value
            End Set
        End Property
        Public Property TeamId() As Integer
            Get
                Return _TeamId
            End Get
            Set(ByVal Value As Integer)
                _TeamId = Value
            End Set
        End Property
        Public Property TeamName() As String
            Get
                Return _TeamName
            End Get
            Set(ByVal Value As String)
                _TeamName = Value
            End Set
        End Property

#End Region

#Region "Load"

        '/ <summary>
        '/ Loads the specified team
        '/ </summary>
        '/ <param name="TeamId">The team to load</param>
        '/ <returns></returns>
        Public Shared Function Load(ByVal vTeamId As Integer) As Contacts.Team

            Dim dsTeam As DataSet = GetDataSet(vTeamId)

            Dim oTeam As Team = New Team

            Dim dr As DataRow
            For Each dr In dsTeam.Tables(0).Rows
                oTeam.LeagueId = CInt(dr("LeagueId"))
                oTeam.LeagueName = dr("LeagueName").ToString()
                oTeam.ConferenceId = CInt(dr("ConferenceId"))
                oTeam.ConferenceName = dr("ConferenceName").ToString()
                oTeam.DivisionId = CInt(dr("DivisionId"))
                oTeam.DivisionName = dr("DivisionName").ToString()
                oTeam.TeamId = CInt(dr("TeamId"))
                oTeam.TeamName = dr("TeamName").ToString()
            Next dr

            Return oTeam
        End Function 'Load 

#End Region

#Region "GetDataSet"

        '/ <summary>
        '/ Gets a DataSet for the specified ContactId
        '/ </summary>
        '/ <param name="TeamId">The team to retrieve</param>
        '/ <returns></returns>
        Public Shared Function GetDataSet(ByVal vTeamId As Integer) As System.Data.DataSet
            Dim dbparms As New DBParmCollection
            dbparms.add(New dbparms("@TeamId", vTeamId, SqlDbType.Int, ParameterDirection.Input))

            Return New SqlConnect().datasetGen("usp_GetTeamInformation", dbparms)
        End Function 'GetDataSet 
#End Region

    End Class 'Team 
End Namespace 'Contacts

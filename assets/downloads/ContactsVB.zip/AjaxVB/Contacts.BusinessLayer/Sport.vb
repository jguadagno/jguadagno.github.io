
Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports Contacts.DAL


Namespace Contacts
   '/ <summary>
   '/ Summary description for Sport.
   '/ </summary>
   
   Public Class Sport
      
      Public Sub New()
      End Sub 'New
      #Region "Public Static Methods"
      
      Public Shared Function LoadLeagues() As DataSet
         Return New SqlConnect().datasetGen("usp_LeagueLoadAll")
      End Function 'LoadLeagues
      
      
      Public Shared Function LoadConferences() As DataSet
         Return New SqlConnect().datasetGen("usp_ConferenceLoadAll")
      End Function 'LoadConferences
      
      
      Public Shared Function LoadDivisions() As DataSet
         Return New SqlConnect().datasetGen("usp_DivisionLoadAll")
      End Function 'LoadDivisions
      
      
      Public Shared Function LoadTeams() As DataSet
         Return New SqlConnect().datasetGen("usp_TeamLoadAll")
      End Function 'LoadTeams
      
      Public Shared Function LoadConferenceByLeague(LeagueId As Integer) As DataSet
         Dim dbparms As New DBParmCollection()
         dbparms.add(New DBParms("@LeagueId", LeagueId, SqlDbType.Int, ParameterDirection.Input))
         
         Return New SqlConnect().datasetGen("usp_GetConferenceForLeague", dbparms)
      End Function 'LoadConferenceByLeague
       
      Public Shared Function LoadDivisionsByConference(ConferenceId As Integer) As DataSet
         Dim dbparms As New DBParmCollection()
         dbparms.add(New DBParms("@ConferenceId", ConferenceId, SqlDbType.Int, ParameterDirection.Input))
         
         Return New SqlConnect().datasetGen("usp_GetDivisionForConference", dbparms)
      End Function 'LoadDivisionsByConference
       
      Public Shared Function LoadTeamsByDivision(DivisionId As Integer) As DataSet
         Dim dbparms As New DBParmCollection()
         dbparms.add(New DBParms("@DivisionId", DivisionId, SqlDbType.Int, ParameterDirection.Input))
         
         Return New SqlConnect().datasetGen("usp_GetTeamForDivision", dbparms)
      End Function 'LoadTeamsByDivision 
      
      #End Region
   End Class 'Sport
End Namespace 'Contacts
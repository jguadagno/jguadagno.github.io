
Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports Contacts.DAL


Namespace Contacts
   '/ <summary>
   '/ Contains information about the contact
   '/ </summary>
   
   Public Class Contact
      #Region "Public Contructors"
      
      Public Sub New()
      End Sub 'New
      
      
      Public Sub New(ContactId As Integer, FirstName As String, MiddleName As String, LastName As String, HomeNumber As String, WorkNumber As String, MobileNumber As String, Email1 As String, Email2 As String, Email3 As String, Address1 As String, Address2 As String, CityName As String, State As String, ZipCode As String, ZipPlus4 As String, TeamId As Integer)
         _ContactId = ContactId
         _FirstName = FirstName
         _MiddleName = MiddleName
         _LastName = LastName
         _HomeNumber = HomeNumber
         _WorkNumber = WorkNumber
         _MobileNumber = MobileNumber
         _Email1 = Email1
         _Email2 = Email2
         _Email3 = Email3
         _Address1 = Address1
         _Address2 = Address2
         _CityName = CityName
         _State = State
         _ZipCode = ZipCode
         _ZipPlus4 = ZipPlus4
         _Team = Team.Load(TeamId)
         _IsDirty = True
      End Sub 'New
      #End Region
      
      Public Const resultOK As String = "OK"
      Public Const resultFailed As String = "Failed"
      
      #Region "Private Properties"
      
      Private _ContactId As Integer
      Private _FirstName As String
      Private _MiddleName As String
      Private _LastName As String
      Private _HomeNumber As String
      Private _WorkNumber As String
      Private _MobileNumber As String
      Private _Email1 As String
      Private _Email2 As String
      Private _Email3 As String
      Private _Address1 As String
      Private _Address2 As String
      Private _CityName As String
      Private _State As String
      Private _ZipCode As String
      Private _ZipPlus4 As String
      Private _Team As Team
      Private _IsDirty As Boolean
      
      #End Region
      
      #Region "Public Properties"
      
      '/ <summary>
      '/ The unique identifier for the contact
      '/ </summary>
      
      Public Property ContactId() As Integer
         Get
            Return _ContactId
         End Get
         Set
            _ContactId = value
            _IsDirty = True
         End Set
      End Property 
      '/ <summary>
      '/ The first name of the contact
      '/ </summary>
      
      Public Property FirstName() As String
         Get
            Return _FirstName
         End Get
         Set
            _IsDirty = True
            _FirstName = value
         End Set
      End Property 
      '/ <summary>
      '/ The middle name of the contact
      '/ </summary>
      
      Public Property MiddleName() As String
         Get
            Return _MiddleName
         End Get
         Set
            _IsDirty = True
            _MiddleName = value
         End Set
      End Property 
      '/ <summary>
      '/ The last name of the client
      '/ </summary>
      
      Public Property LastName() As String
         Get
            Return _LastName
         End Get
         Set
            _IsDirty = True
            _LastName = value
         End Set
      End Property 
      '/ <summary>
      '/ The home number of the contact
      '/ </summary>
      
      Public Property HomeNumber() As String
         Get
            Return _HomeNumber
         End Get
         Set
            _IsDirty = True
            _HomeNumber = value
         End Set
      End Property 
      '/ <summary>
      '/ The work number for the contact
      '/ </summary>
      
      Public Property WorkNumber() As String
         Get
            Return _WorkNumber
         End Get
         Set
            _IsDirty = True
            _WorkNumber = value
         End Set
      End Property 
      '/ <summary>
      '/ The mobile number for the contact
      '/ </summary>
      
      Public Property MobileNumber() As String
         Get
            Return _MobileNumber
         End Get
         Set
            _IsDirty = True
            _MobileNumber = value
         End Set
      End Property 
      '/ <summary>
      '/ Email address 1 for the contact
      '/ </summary>
      
      Public Property Email1() As String
         Get
            Return _Email1
         End Get
         Set
            _IsDirty = True
            _Email1 = value
         End Set
      End Property 
      '/ <summary>
      '/ Email address 2 for the contact
      '/ </summary>
      
      Public Property Email2() As String
         Get
            Return _Email2
         End Get
         Set
            _IsDirty = True
            _Email2 = value
         End Set
      End Property 
      '/ <summary>
      '/ Email address 3 for the contact
      '/ </summary>
      
      Public Property Email3() As String
         Get
            Return _Email3
         End Get
         Set
            _IsDirty = True
            _Email3 = value
         End Set
      End Property '/ <summary>
      '/ The address 1 for the contact
      '/ </summary>
      
      Public Property Address1() As String
         Get
            Return _Address1
         End Get
         Set
            _IsDirty = True
            _Address1 = value
         End Set
      End Property '/ <summary>
      '/ The address 2 for the contact
      '/ </summary>
      
      Public Property Address2() As String
         Get
            Return _Address2
         End Get
         Set
            _IsDirty = True
            _Address2 = value
         End Set
      End Property '/ <summary>
      '/ The ciy name for the contact
      '/ </summary>
      
      Public Property CityName() As String
         Get
            Return _CityName
         End Get
         Set
            _IsDirty = True
            _CityName = value
         End Set
      End Property '/ <summary>
      '/ The state of the contact
      '/ </summary>
      
      Public Property State() As String
         Get
            Return _State
         End Get
         Set
            _IsDirty = True
            _State = value
         End Set
      End Property '/ <summary>
      '/ The Zip Code of the address
      '/ </summary>
      
      Public Property ZipCode() As String
         Get
            Return _ZipCode
         End Get
         Set
            _IsDirty = True
            _ZipCode = value
         End Set
      End Property '/ <summary>
      '/ The Zip Plus 4 code for the address
      '/ </summary>
      
      Public Property ZipPlus4() As String
         Get
            Return _ZipPlus4
         End Get
         Set
            _IsDirty = True
            _ZipPlus4 = value
         End Set
      End Property
      '/ <summary>
      '/ The contacts favorite team.
      '/ </summary>
      
      Public Property Team() As Team
         Get
            Return _Team
         End Get
         Set
            _IsDirty = True
            _Team = value
         End Set
      End Property
      '/ <summary>
      '/ Indicates if the contact has changed since it has been last saved or loaded
      '/ </summary>
      
      Public ReadOnly Property IsDirty() As Boolean
         Get
            Return _IsDirty
         End Get
      End Property
      #End Region
      
      #Region "Public Methods"
      
      #Region "Load"
      
      '/ <summary>
      '/ Loads the contact information from the database
      '/ </summary>
      '/ <param name="ContactId">The contact id to load</param>
      '/ <returns>A Contacts.Contact class</returns>
      Public Shared Function Load(ContactId As Integer) As Contacts.Contact
         
            Dim dsContact As DataSet = GetDataSet(ContactId)
         
            Dim oContact As Contact = New Contact
         
            Dim dr As DataRow
            For Each dr In dsContact.Tables(0).Rows

                oContact.ContactId = CInt(dr("ContactId"))
                oContact.FirstName = dr("FirstName").ToString()
                oContact.MiddleName = dr("MiddleName").ToString()
                oContact.LastName = dr("LastName").ToString()
                oContact.HomeNumber = dr("HomeNumber").ToString()
                oContact.WorkNumber = dr("WorkNumber").ToString()
                oContact.MobileNumber = dr("MobileNumber").ToString()
                oContact.Email1 = dr("Email1").ToString()
                oContact.Email2 = dr("Email2").ToString()
                oContact.Email3 = dr("Email3").ToString()
                oContact.Address1 = dr("Address1").ToString()
                oContact.Address2 = dr("Address2").ToString()
                oContact.CityName = dr("CityName").ToString()
                oContact.State = dr("State").ToString()
                oContact.ZipCode = dr("ZipCode").ToString()
                oContact.ZipPlus4 = dr("ZipPlus4").ToString()
                If dr("TeamId").GetType Is GetType(System.DBNull) Then
                Else
                    Dim oTeam As Team = New Team
                    oContact.Team = oTeam.Load(CInt(dr("TeamId")))
                End If
            Next dr

            Return oContact
        End Function 'Load 

#End Region

#Region "GetDataSet"

        '/ <summary>
        '/ Gets a DataSet for the specified ContactId
        '/ </summary>
        '/ <param name="ContactId">The contact to retrieve</param>
        '/ <returns></returns>
        Public Shared Function GetDataSet(ByVal ContactId As Integer) As System.Data.DataSet
            Dim dbparms As New DBParmCollection
            dbparms.add(New dbparms("@ContactId", ContactId, SqlDbType.Int, ParameterDirection.Input))

            Return New SqlConnect().datasetGen("usp_ContactsLoadByPrimaryKey", dbparms)
        End Function 'GetDataSet 
#End Region

#Region "Save"

        Public Overloads Function Save() As String
            Dim returnResult As String = resultFailed

            Dim myTrans As SqlTransaction
            Dim myConnection As SqlConnection

            myConnection = New SqlConnect().getSqlConnection()
            myConnection.Open()
            myTrans = myConnection.BeginTransaction()

            returnResult = Save(myTrans)

            myTrans.Commit()

            ' Clean up
            myTrans = Nothing
            myConnection.Close()
            myConnection = Nothing
            Return returnResult
        End Function 'Save


        Public Overloads Function Save(ByVal myTrans As SqlTransaction) As String
            Dim returnResult As String = resultFailed
            Dim myCommand As SqlCommand

            If _IsDirty = False Then
                Return resultOK
            End If
            Try
                '
                'ToDo: Error processing original source shown below
                '   {
                '    #region Save Records
                '-----^--- expression expected

                If _ContactId = 0 Then
                    myCommand = New SqlCommand("usp_ContactsInsert", myTrans.Connection, myTrans)
                    Dim parm As New SqlParameter("@ContactId", SqlDbType.Int, 4)
                    parm.Direction = ParameterDirection.Output
                    myCommand.Parameters.Add(parm)
                    parm = Nothing
                Else
                    myCommand = New SqlCommand("usp_ContactsUpdate", myTrans.Connection, myTrans)
                    Dim parm As New SqlParameter("@ContactId", SqlDbType.Int, 4)
                    parm.Value = _ContactId
                    myCommand.Parameters.Add(parm)
                    parm = Nothing
                End If
                ' Set up the parameters
                myCommand.CommandType = CommandType.StoredProcedure
                ' work with the parameters
                myCommand.Parameters.Add(New SqlParameter("@FirstName", _FirstName))
                myCommand.Parameters.Add(New SqlParameter("@LastName", _LastName))
                myCommand.Parameters.Add(New SqlParameter("@MiddleName", _MiddleName))
                myCommand.Parameters.Add(New SqlParameter("@HomeNumber", _HomeNumber))
                myCommand.Parameters.Add(New SqlParameter("@MobileNumber", _MobileNumber))
                myCommand.Parameters.Add(New SqlParameter("@WorkNumber", _WorkNumber))
                myCommand.Parameters.Add(New SqlParameter("@Email1", _Email1))
                myCommand.Parameters.Add(New SqlParameter("@Email2", _Email2))
                myCommand.Parameters.Add(New SqlParameter("@Email3", _Email3))
                myCommand.Parameters.Add(New SqlParameter("@Address1", _Address1))
                myCommand.Parameters.Add(New SqlParameter("@Address2", _Address2))
                myCommand.Parameters.Add(New SqlParameter("@CityName", _CityName))
                myCommand.Parameters.Add(New SqlParameter("@State", _State))
                myCommand.Parameters.Add(New SqlParameter("@ZipCode", _ZipCode))
                myCommand.Parameters.Add(New SqlParameter("@ZipPlus4", _ZipPlus4))
                If Not (_Team Is Nothing) Then
                    myCommand.Parameters.Add(New SqlParameter("@TeamId", _Team.TeamId))
                End If
                myCommand.ExecuteNonQuery()
                _ContactId = CInt(myCommand.Parameters("@ContactId").Value)
                _IsDirty = False

                returnResult = resultOK
                '
                'ToDo: Error processing original source shown below
                '    returnResult = resultOK;
                '    #endregion
                '-----^--- expression expected

            Catch ex As Exception
                returnResult = ex.ToString()
            Finally
                myCommand = Nothing
            End Try

            Return returnResult
        End Function 'Save 
#End Region

#End Region

    End Class 'Contact 
End Namespace 'Contacts


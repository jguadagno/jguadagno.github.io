
Imports System
Imports System.Collections


Namespace Contacts.DAL
   '/ <summary>
   '/ Summary description for DBParmCollection.
   '/ </summary>
   
    Public Class DBParmCollection
        Inherits System.Collections.CollectionBase

        Public Sub New()
        End Sub 'New

        '/ <summary>
        '/ Adding DB Parm object to collection list
        '/ </summary>
        '/ <param name="oDBParms"></param>
        Public Sub add(ByVal oDBParms As DBParms)
            Me.List.Add(oDBParms)
        End Sub 'add

    End Class 'DBParmCollection
End Namespace 'Contacts.DAL '

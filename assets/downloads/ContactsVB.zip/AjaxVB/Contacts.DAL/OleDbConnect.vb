
Imports System
Imports System.Data
Imports System.Data.OleDb


Namespace Contacts.DAL
   '/ <summary>
   '/ Summary description for OleDbConnect.
   '/ </summary>
   
   Public Class OleDbConnect
      
      Enum CONNECTION_TYPE
         SQL_SERVER = 1
         EXCEL = 2
         ACCESS = 3
      End Enum 'CONNECTION_TYPE

      Private sDbConnection As String = String.Empty
      Private oleDbConnection As OleDbConnection
      
      
      Public Sub New(sDbConnection As String, nConnectionType As Integer, sServerName As String, sDbName As String)
         If nConnectionType = CInt(CONNECTION_TYPE.EXCEL) Then
            If sDbConnection.IndexOf(".xls") > 0 Then
               sDbConnection = "Provider=Microsoft.Jet.OLEDB.4.0;Extended Properties=Excel 8.0;Data Source=" + sDbConnection
            Else
               Throw New Exception("Invalid Microsoft Excel file extension - " + sDbConnection)
            End If
         ElseIf nConnectionType = CInt(CONNECTION_TYPE.ACCESS) Then
            If sDbConnection.IndexOf(".mdb") > 0 Then
               sDbConnection = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + sDbConnection
            Else
               Throw New Exception("Invalid Microsoft Access file extension - " + sDbConnection)
            End If
         Else
            sDbConnection = "Provider=SQLOLEDB;Data Source=" + sServerName + ";Initial Catalog=" + sDbName + ";Integrated Security=SSPI;"
         End If 
         
         connect()
      End Sub 'New
       
      
      Private Sub connect()
         oleDbConnection = New OleDbConnection(sDbConnection)
      End Sub 'connect
      
      
      Public Function dataSetGen(sSqlSyntax As String) As DataSet
         Return New DataSet()
      End Function 'dataSetGen
       
      
      Private Sub disconnect()
         oleDbConnection.Close()
         oleDbConnection.Dispose()
         oleDbConnection = Nothing
      End Sub 'disconnect
      
      
      '/ <summary>
      '/ Generate dataset from stored procedure without parameter
      '/ </summary>
      '/ <param name="sSpName"></param>
      '/ <returns></returns>
      Public Function datasetGenDirect(sTableName As String) As DataSet
         Dim dset As New DataSet()
         Dim dad As New OleDbDataAdapter()
         Dim cmd As OleDbCommand
         
         Try
            cmd = New OleDbCommand(sTableName, oleDbConnection)
            cmd.CommandType = CommandType.TableDirect
            
            dad.SelectCommand = cmd
            dad.Fill(dset)
         Catch ex As Exception
            Throw New DalException("OleDbConnect.datasetGenDirect: " + ex.Source + " - " + sTableName + ". Msg: " + ex.Message)
         End Try
         
         disconnect()
         
         Return dset
      End Function 'datasetGenDirect
   End Class 'OleDbConnect
End Namespace 'Contacts.DAL

Imports System
Imports System.Data
Imports System.Data.SqlClient


Namespace Contacts.DAL
   '/ <summary>
   '/ List of database parameters
   '/ </summary>
   
   Public Class DBParms
      Private sParmName As String
      Private oParmValue As Object
      Private oParmType As SqlDbType
      Private oParmDirection As ParameterDirection
      Private nParmSize As Integer
      
      
      Public Sub New()
      End Sub 'New
       
      '/ <summary>
      '/ Add new parameter
      '/ </summary>
      '/ <param name="sParmName"></param>
      '/ <param name="sParmValue"></param>
      '/ <param name="sParmType"></param>
      Public Sub New(sParmName As String, oParmValue As Object, oParmType As SqlDbType, oParmDirection As ParameterDirection, nParmSize As Integer)
         Me.sParmName = sParmName
         Me.oParmValue = oParmValue
         Me.oParmType = oParmType
         Me.oParmDirection = oParmDirection
         Me.nParmSize = nParmSize
      End Sub 'New
      
      
      '/ <summary>
      '/ Add new parameter
      '/ </summary>
      '/ <param name="sParmName"></param>
      '/ <param name="sParmValue"></param>
      '/ <param name="sParmType"></param>
      Public Sub New(sParmName As String, oParmValue As Object, oParmType As SqlDbType, oParmDirection As ParameterDirection)
         Me.sParmName = sParmName
         Me.oParmValue = oParmValue
         Me.oParmType = oParmType
         Me.oParmDirection = oParmDirection
      End Sub 'New
      
      
      '/ <summary>
      '/ Add new parameter
      '/ </summary>
      '/ <param name="sParmName"></param>
      '/ <param name="sParmValue"></param>
      '/ <param name="sParmType"></param>
      Public Sub New(sParmName As String, oParmValue As Object, oParmType As SqlDbType)
         Me.sParmName = sParmName
         Me.oParmValue = oParmValue
         Me.oParmType = oParmType
      End Sub 'New
      
      
      '/ <summary>
      '/ Add new parameter
      '/ </summary>
      '/ <param name="sParmName"></param>
      '/ <param name="sParmValue"></param>
      Public Sub New(sParmName As String, oParmValue As Object)
         Me.sParmName = sParmName
         Me.oParmValue = oParmValue
      End Sub 'New
      

        Public ReadOnly Property parmName() As String
            Get
                Return sParmName
            End Get
        End Property

        Public ReadOnly Property parmValue() As Object
            Get
                Return oParmValue
            End Get
        End Property

        Public ReadOnly Property parmType() As SqlDbType
            Get
                Return oParmType
            End Get
        End Property

        Public ReadOnly Property parmDirection() As ParameterDirection
            Get
                Return oParmDirection
            End Get
        End Property

        Public ReadOnly Property parmSize() As Integer
            Get
                Return nParmSize
            End Get
        End Property
    End Class 'DBParms
End Namespace 'Contacts.DAL
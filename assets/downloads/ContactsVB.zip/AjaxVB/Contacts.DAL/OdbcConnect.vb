
Imports System


Namespace Contacts.DAL
   '/ <summary>
   '/ Summary description for OdbcConnect.
   '/ </summary>
   
   Public Class OdbcConnect
      
      Public Sub New()
      End Sub 'New
   End Class 'OdbcConnect '
End Namespace 'Contacts.DAL ' TODO: Add constructor logic here
'
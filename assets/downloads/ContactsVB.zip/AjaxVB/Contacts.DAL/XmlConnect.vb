
Imports System
Imports System.Data
Imports System.IO
Imports System.Xml


Namespace Contacts.DAL
   '/ <summary>
   '/ Summary description for XmlConnect.
   '/ </summary>
   
   Public Class XmlConnect
      
      Public Sub New()
      End Sub 'New
       
      Overloads Public Function dataSetGen(sXmlFilePath As String) As DataSet
         Dim dst As DataSet = Nothing
         
         ' Check existance of Xml file
         If File.Exists(sXmlFilePath) Then
            dst = New DataSet()
            dst.ReadXml(sXmlFilePath)
         Else
            ' Raise exception if file not found
            Throw New DalException(sXmlFilePath + " not found!")
         End If
         
         Return dst
      End Function 'dataSetGen
      
      
      Overloads Public Function dataSetGen(sXmlFilePath As String, sDataSetName As String) As DataSet
         Dim dst As New DataSet(sDataSetName)
         dst.ReadXml(sXmlFilePath)
         
         Return dst
      End Function 'dataSetGen
   End Class 'XmlConnect 
End Namespace 'Contacts.DAL
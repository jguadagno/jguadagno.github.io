
Imports System


Namespace Contacts.DAL
   '/ <summary>
   '/ Summary description for DmlUnit.
   '/ </summary>
   
   Public Class DmlUnit
      Private _sStoredProcName As String = String.Empty
      Private _dbParmCollection As DBParmCollection = Nothing
      
      
      Public Sub New()
      End Sub 'New
       
      Public Sub New(sStoredProcedureName As String, dbParmCollection As DBParmCollection)
         _sStoredProcName = sStoredProcedureName
         _dbParmCollection = dbParmCollection
      End Sub 'New
      
      
      Public Property storedProcedureName() As String
         Get
            Return _sStoredProcName
         End Get
         Set
            _sStoredProcName = value
         End Set
      End Property
      
      Public Property colDbParms() As DBParmCollection
         Get
            Return _dbParmCollection
         End Get
         Set
            _dbParmCollection = value
         End Set
      End Property
   End Class 'DmlUnit
End Namespace 'Contacts.DAL

Imports System
Imports System.Collections


Namespace Contacts.DAL
   '/ <summary>
   '/ Summary description for colDbParmCollection.
   '/ </summary>
   
   Public Class SqlDmlCollection
      Inherits System.Collections.CollectionBase
      
      Public Sub New()
      End Sub 'New
       
      Public Sub addSqlDml(sStoredProcedureName As String, dbParmCollection As DBParmCollection)
         ' Declare DmlUnit object
         Dim dmlUnit As New DmlUnit(sStoredProcedureName, dbParmCollection)
         
         Me.List.Add(dmlUnit)
      End Sub 'addSqlDml
   End Class 'SqlDmlCollection
End Namespace 'Contacts.DAL
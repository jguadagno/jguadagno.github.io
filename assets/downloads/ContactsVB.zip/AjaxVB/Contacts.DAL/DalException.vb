
Imports System
Imports System.Configuration
Imports System.IO


Namespace Contacts.DAL
   '/ <summary>
   '/ Summary description for DalException.
   '/ </summary>
   
   Public Class DalException
      Inherits System.ApplicationException
      ' Declare class variables
      Private Const sModule As String = "DalException"
      Private sMsg As String = String.Empty
      Private sLogDate As String = System.DateTime.Now.ToShortDateString() + " " + System.DateTime.Now.ToShortTimeString()
      
      
      Public Sub New()
      End Sub 'New
       
      ' Raise own custom exception
      Public Sub New(sMsg As String)
         MyBase.New(sMsg)
         Me.sMsg = sMsg
      End Sub 'New
   End Class 'DalException 
End Namespace 'Contacts.DAL
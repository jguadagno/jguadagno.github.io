
Imports System


Namespace Contacts.DAL
   '/ <summary>
   '/ Summary description for OracleConnect.
   '/ </summary>
   
   Public Class OracleConnect
      
      Public Sub New()
      End Sub 'New
   End Class 'OracleConnect '
End Namespace 'Contacts.DAL ' TODO: Add constructor logic here
'

Imports System
Imports System.Collections
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports intel.general


Namespace Contacts.DAL
   '/ <summary>
   '/ Connection to database using native sql connection classes
   '/ </summary>
   
   Public Class SqlConnect
      Private sDbConn As String
      Private oSqlConnection As SqlConnection
      Private nCommandTimeout As Integer = 300
       ' default command time out to 30 seconds
      '/ <summary>
      '/ Instantiate data object with connection string from web.config
      '/ </summary>
      Public Function getSqlConnection() As SqlConnection
         Return oSqlConnection
      End Function 'getSqlConnection
      
      
      Public Sub closeSqlConnection()
         disconnect()
      End Sub 'closeSqlConnection
      
      
        Public Sub New()
            ' Get connection string
            Dim sConnectionString As String = ConfigurationSettings.AppSettings("db_connection")
            Me.dbConn = sConnectionString

            ' Make database connection
            connect()
        End Sub 'New


        '/ <summary>
        '/ Using database connection other then default one from web.config
        '/ </summary>
        '/ <param name="sDbConn">Database connection string</param>
        Public Sub New(ByVal sDbConn As String)
            ' Get connection string, must be SQL Server!!!
            Me.sDbConn = sDbConn

            ' Make database connection
            connect()
        End Sub 'New


        '/ <summary>
        '/ Set command timeout for default connection
        '/ </summary>
        '/ <param name="nCommandTimeout"></param>
        Public Sub New(ByVal nCommandTimeout As Integer)
            Me.nCommandTimeout = nCommandTimeout

            ' Make database connection
            connect()
        End Sub 'New


        Public Sub New(ByVal sDbConn As String, ByVal nCommandTimeout As Integer)
            Me.sDbConn = sDbConn
            Me.nCommandTimeout = nCommandTimeout

            ' Make database connection
            connect()
        End Sub 'New


        '/ <summary>
        '/ Make connection to database
        '/ </summary>
        Private Sub connect()
            If sDbConn Is Nothing OrElse sDbConn.Equals(String.Empty) Then
                Throw New DalException("No connection string setup")
            Else
                oSqlConnection = New SqlConnection(sDbConn)
            End If
        End Sub 'connect


        '/ <summary>
        '/ Destroy connection
        '/ </summary>
        Private Sub disconnect()
            oSqlConnection.Close()
            oSqlConnection.Dispose()
        End Sub 'disconnect


        '/ <summary>
        '/ Generate dataset from stored procedure without parameter
        '/ </summary>
        '/ <param name="sSpName"></param>
        '/ <returns></returns>
        Public Overloads Function datasetGen(ByVal sSpName As String) As DataSet
            Dim dset As New DataSet
            Dim dad As New SqlDataAdapter
            Dim cmd As SqlCommand

            Try
                cmd = New SqlCommand(sSpName, oSqlConnection)
                cmd.CommandTimeout = nCommandTimeout
                cmd.CommandType = CommandType.StoredProcedure

                dad.SelectCommand = cmd
                dad.Fill(dset)
            Catch ex As Exception
                Throw New DalException("SqlConnect.dataSetGen: " + ex.Source + " - " + sSpName + ". Msg: " + ex.Message)
            End Try

            disconnect()

            Return dset
        End Function 'datasetGen


        '/ <summary>
        '/ Generate dataset with defined table name
        '/ </summary>
        '/ <param name="arlSpName">Arraylist of stored procedures</param>
        '/ <param name="arlTbl">Arraylist of Tables</param>
        '/ <returns>Dataset</returns>
        Public Overloads Function datasetGen(ByVal arlSpName As ArrayList, ByVal arlTbl As ArrayList) As DataSet
            Dim dset As New DataSet
            Dim dad As New SqlDataAdapter
            Dim cmd As SqlCommand
            Dim nIndex As Integer = 0

            Try
                For nIndex = 0 To arlSpName.Count - 1
                    cmd = New SqlCommand(arlSpName(nIndex).ToString(), oSqlConnection)
                    cmd.CommandTimeout = nCommandTimeout
                    cmd.CommandType = CommandType.StoredProcedure

                    dad.SelectCommand = cmd
                    dad.Fill(dset, arlTbl(nIndex).ToString())
                Next nIndex
            Catch ex As Exception
                Throw New DalException("Data.dataSetGen: " + ex.Source + " - " + arlSpName(nIndex).ToString() + ". Msg: " + ex.Message)
            End Try

            disconnect()

            Return dset
        End Function 'datasetGen


        '/ <summary>
        '/ Generate dataset with defined table name
        '/ </summary>
        '/ <param name="arlSpName">Arraylist of stored procedures</param>
        '/ <param name="arlTbl">Arraylist of Tables</param>
        '/ <returns>Dataset</returns>
        Public Overloads Function datasetGen(ByVal arlSpName As ArrayList, ByVal arlTbl As ArrayList, ByVal oParmCollection As DBParmCollection) As DataSet
            Dim dset As New DataSet
            Dim dad As New SqlDataAdapter
            Dim cmd As SqlCommand
            Dim parm As SqlParameter
            Dim nIndex As Integer = 0

            Try
                For nIndex = 0 To arlSpName.Count - 1
                    cmd = New SqlCommand(arlSpName(nIndex).ToString(), oSqlConnection)
                    cmd.CommandTimeout = nCommandTimeout
                    cmd.CommandType = CommandType.StoredProcedure

                    ' Build input parameters
                    Dim item As DBParms
                    For Each item In oParmCollection
                        ' Only passdown input parameter
                        If item.parmDirection = ParameterDirection.Input Then
                            ' Receive object, get parameter out
                            parm = cmd.Parameters.Add(item.parmName, item.parmType, item.parmSize)
                            parm.Value = item.parmValue
                            parm.Direction = item.parmDirection
                        End If
                    Next item

                    dad.SelectCommand = cmd
                    dad.Fill(dset, arlTbl(nIndex).ToString())
                Next nIndex
            Catch ex As Exception
                Throw New DalException("SqlConnect.dataSetGen: " + ex.Source + " - " + arlSpName(nIndex).ToString() + ". Msg: " + ex.Message)
            End Try

            disconnect()

            Return dset
        End Function 'datasetGen


        '/ <summary>
        '/ Generate dataset with defined table name
        '/ </summary>
        '/ <param name="sSpName"></param>
        '/ <param name="sTableName"></param>
        '/ <returns></returns>
        Public Overloads Function datasetGen(ByVal sSpName As String, ByVal sTableName As String) As DataSet
            Dim dset As New DataSet
            Dim dad As New SqlDataAdapter
            Dim cmd As SqlCommand

            Try
                cmd = New SqlCommand(sSpName, oSqlConnection)
                cmd.CommandType = CommandType.StoredProcedure

                dad.SelectCommand = cmd
                dad.Fill(dset, sTableName)
            Catch ex As Exception
                Throw New DalException("SqlConnect.dataSetGen: " + ex.Source + " - " + sSpName + ".  Msg: " + ex.Message)
            End Try

            disconnect()

            Return dset
        End Function 'datasetGen


        '/ <summary>
        '/ Generate data set
        '/ </summary>
        '/ <param name="sSpName">Stored procedure name</param>
        '/ <param name="sTableName">Table name</param>
        '/ <param name="oParmCollection">Parameters collection</param>
        '/ <returns>Dataset</returns>
        Public Overloads Function datasetGen(ByVal sSpName As String, ByVal sTableName As String, ByVal oParmCollection As DBParmCollection) As DataSet
            Dim dset As New DataSet
            Dim dad As New SqlDataAdapter
            Dim cmd As SqlCommand
            Dim parm As SqlParameter

            Try
                cmd = New SqlCommand(sSpName, oSqlConnection)
                cmd.CommandTimeout = nCommandTimeout
                cmd.CommandType = CommandType.StoredProcedure

                ' Build input parameters
                Dim item As DBParms
                For Each item In oParmCollection
                    ' Only passdown input parameter
                    If item.parmDirection = ParameterDirection.Input Then
                        ' Receive object, get parameter out
                        parm = cmd.Parameters.Add(item.parmName, item.parmType, item.parmSize)
                        parm.Value = item.parmValue
                        parm.Direction = item.parmDirection
                    End If
                Next item

                dad.SelectCommand = cmd
                dad.Fill(dset, sTableName)
            Catch ex As Exception
                Throw New DalException("SqlConnect.dataSetGen: " + ex.Source + " - " + sSpName + ".  Msg: " + ex.Message)
            End Try
            disconnect()

            Return dset
        End Function 'datasetGen


        '/ <summary>
        '/ Generate dataset from stored procedure without parameter
        '/ </summary>
        '/ <param name="sSpName"></param>
        '/ <returns></returns>
        Public Overloads Function datasetGen(ByVal sSpName As String, ByVal oParmCollection As DBParmCollection) As DataSet
            Dim dset As New DataSet
            Dim dad As New SqlDataAdapter
            Dim cmd As SqlCommand
            Dim parm As SqlParameter

            Try
                cmd = New SqlCommand(sSpName, oSqlConnection)
                cmd.CommandTimeout = nCommandTimeout
                cmd.CommandType = CommandType.StoredProcedure

                ' Build input parameters
                Dim item As DBParms
                For Each item In oParmCollection
                    ' Only passdown input parameter
                    If item.parmDirection = ParameterDirection.Input Then
                        ' Receive object, get parameter out
                        parm = cmd.Parameters.Add(item.parmName, item.parmType, item.parmSize)
                        parm.Value = item.parmValue
                        parm.Direction = item.parmDirection
                    End If
                Next item

                dad.SelectCommand = cmd
                dad.Fill(dset)
            Catch ex As Exception
                Throw New DalException("SqlConnection.dataSetGen: " + ex.Source + " - " + sSpName + ". Msg: " + ex.Message)
            End Try
            disconnect()

            Return dset
        End Function 'datasetGen


        '/ <summary>
        '/ Run stored procedure without parameter
        '/ </summary>
        '/ <param name="sSpName"></param>
        '/ <returns></returns>
        Public Function executeQuery(ByVal sSql As String) As DataSet
            Dim dset As New DataSet
            Dim dad As New SqlDataAdapter
            Try
                ' Create command object
                Dim cmd As New SqlCommand(sSql, oSqlConnection)
                cmd.CommandTimeout = nCommandTimeout
                cmd.CommandType = CommandType.Text

                ' Open database connection
                oSqlConnection.Open()

                dad.SelectCommand = cmd
                dad.Fill(dset)
            Catch ex As InvalidOperationException
                ' Write error to window log
                Throw New DalException("SqlConnect.executeQuery InvalidOperationException: " + ex.Source + " - " + sSql + " - " + ex.Message)
            Catch ex As SqlException
                Throw New DalException("SqlConnect.executeQuery SqlException: " + ex.Source + " - " + sSql + " - " + ex.Message)
            Catch ex As Exception
                Throw New DalException("SqlConnect.executeQuery Exception: " + ex.Source + " - " + sSql + " - " + ex.Message)
            End Try

            ' Disconnect connection
            disconnect()

            Return dset
        End Function 'executeQuery


        Public Function executeQueryWithInt(ByVal sSql As String) As Integer
            Dim nRowCount As Integer = 0

            Try
                ' Create command object
                Dim cmd As New SqlCommand(sSql, oSqlConnection)
                cmd.CommandTimeout = nCommandTimeout
                cmd.CommandType = CommandType.Text

                ' Open database connection
                oSqlConnection.Open()

                ' Execute stored procedure
                nRowCount = CInt(cmd.ExecuteScalar())
            Catch ex As InvalidOperationException
                ' Write error to window log
                Throw New DalException("SqlConnect.executeQuery InvalidOperationException: " + ex.Source + " - " + sSql + " - " + ex.Message)
            Catch ex As SqlException
                Throw New DalException("SqlConnect.executeQuery SqlException: " + ex.Source + " - " + sSql + " - " + ex.Message)
            Catch ex As Exception
                Throw New DalException("SqlConnect.executeQuery Exception: " + ex.Source + " - " + sSql + " - " + ex.Message)
            End Try

            ' Disconnect connection
            disconnect()

            Return nRowCount
        End Function 'executeQueryWithInt


        Public Overloads Function runStoredProc(ByVal sSpName As String) As Integer

            Dim nRowCount As Integer = 0

            Try

                ' Create command object
                Dim cmd As New SqlCommand(sSpName, oSqlConnection)
                cmd.CommandTimeout = nCommandTimeout
                cmd.CommandType = CommandType.StoredProcedure

                Dim parm As SqlParameter = cmd.Parameters.Add("return_value", SqlDbType.Int)
                parm.Direction = ParameterDirection.ReturnValue

                ' Open database connection
                oSqlConnection.Open()

                ' Execute stored procedure
                cmd.ExecuteNonQuery()

                ' Obtain return count
                nRowCount = Convert.ToInt32(cmd.Parameters("return_value").Value.ToString())
            Catch ex As InvalidOperationException


                ' Write error to window log
                Throw New DalException("SqlConnect.runStoredProc InvalidOperationException: " + ex.Source + " - " + sSpName + " - " + ex.Message)
            Catch ex As SqlException


                Throw New DalException("SqlConnect.runStoredProc SqlException: " + ex.Source + " - " + sSpName + " - " + ex.Message)
            Catch ex As Exception


                Throw New DalException("SqlConnect.runStoredProc Exception: " + ex.Source + " - " + sSpName + " - " + ex.Message)
            End Try

            ' Disconnect connection
            disconnect()

            Return nRowCount
        End Function 'runStoredProc



        Public Overloads Function runStoredProc(ByVal sSpName As String, ByVal oParmCollection As DBParmCollection) As Integer

            Dim nRowCount As Integer = 0

            Try
                ' Create command object
                Dim cmd As New SqlCommand(sSpName, oSqlConnection)
                cmd.CommandTimeout = nCommandTimeout
                cmd.CommandType = CommandType.StoredProcedure

                ' Obtain return parameter
                Dim parm As SqlParameter = cmd.Parameters.Add("return_value", SqlDbType.Int)
                parm.Direction = ParameterDirection.ReturnValue

                ' Build input parameters
                Dim item As DBParms
                For Each item In oParmCollection
                    If item.parmValue.Equals(System.DBNull.Value) Then
                        parm = cmd.Parameters.Add(item.parmName, item.parmType)
                        parm.Value = System.DBNull.Value
                    Else
                        ' Receive object, get parameter out
                        parm = cmd.Parameters.Add(item.parmName, item.parmType, item.parmSize)
                        parm.Value = item.parmValue
                        parm.Direction = item.parmDirection
                    End If
                Next item

                ' Open database connection
                oSqlConnection.Open()

                ' Execute stored procedure
                cmd.ExecuteNonQuery()

                ' Obtain return count
                nRowCount = Convert.ToInt32(cmd.Parameters("return_value").Value.ToString())
            Catch ex As InvalidOperationException
                ' Write error to window log
                Throw New DalException("SqlConnect.runStoredProc InvalidOperationException: " + ex.Source + " - " + sSpName + ". Msg: " + ex.Message)
            Catch ex As SqlException
                Throw New DalException("SqlConnect.runStoredProc SqlException: " + ex.Source + " - " + sSpName + ". Msg: " + ex.Message)
            Catch ex As Exception
                Throw New DalException("SqlConnect.runStoredProc Exception: " + ex.Source + " - " + sSpName + ". Msg: " + ex.Message)
            End Try

            Return nRowCount
        End Function 'runStoredProc



        Public Overloads Function runStoredProc(ByVal sSpName As String, ByVal oParmCollection As DBParmCollection, ByVal htbl As Hashtable) As Integer
            Dim nRowCount As Integer = 0

            Try
                ' Create command object
                Dim cmd As New SqlCommand(sSpName, oSqlConnection)
                cmd.CommandTimeout = nCommandTimeout
                cmd.CommandType = CommandType.StoredProcedure

                ' Obtain return parameter
                Dim parm As SqlParameter = cmd.Parameters.Add("return_value", SqlDbType.Int)
                parm.Direction = ParameterDirection.ReturnValue

                ' Build input parameters
                Dim item As DBParms
                For Each item In oParmCollection
                    ' Receive object, get parameter out
                    parm = cmd.Parameters.Add(item.parmName, item.parmType, item.parmSize)
                    parm.Value = item.parmValue
                    parm.Direction = item.parmDirection
                Next item

                ' Open database connection
                oSqlConnection.Open()

                ' Execute stored procedure
                cmd.ExecuteNonQuery()

                ' Obtain return count
                nRowCount = Convert.ToInt32(cmd.Parameters("return_value").Value.ToString())

                ' Obtain output parameter
                For Each item In oParmCollection
                    If item.parmDirection = ParameterDirection.Output Then
                        htbl.Add(item.parmName, cmd.Parameters(item.parmName).Value.ToString())
                    End If
                Next item
            Catch ex As InvalidOperationException
                ' Write error to window log
                Throw New DalException("SqlConnect.runStoredProc InvalidOperationException: " + ex.Source + " - " + sSpName + ". Msg: " + ex.Message)
            Catch ex As SqlException
                Throw New DalException("SqlConnect.runStoredProc SqlException: " + ex.Source + " - " + sSpName + ". Msg: " + ex.Message)
            Catch ex As Exception
                Throw New DalException("SqlConnect.runStoredProc Exception: " + ex.Source + " - " + sSpName + ". Msg: " + ex.Message)
            End Try

            Return nRowCount
        End Function 'runStoredProc



        '/ <summary>
        '/ Execute multiple line of SQL syntax with one connection
        '/ </summary>
        '/ <param name="colSqlDml">Collection of SqlDml object</param>
        '/ <returns></returns>
        Public Overloads Sub runStoredProc(ByVal colSqlDml As SqlDmlCollection)
            Dim sStoredProcedureName As String = String.Empty
            Dim parm As SqlParameter

            Try
                ' Open database connection
                oSqlConnection.Open()

                Dim dmlUnit As dmlUnit
                For Each dmlUnit In colSqlDml
                    sStoredProcedureName = dmlUnit.storedProcedureName
                    Dim colDbParm As DBParmCollection = dmlUnit.colDbParms

                    ' Execute stored procedure
                    Dim cmd As New SqlCommand(sStoredProcedureName, oSqlConnection)
                    cmd.CommandTimeout = nCommandTimeout
                    cmd.CommandType = CommandType.StoredProcedure

                    ' Build input parameters
                    Dim dbParm As DBParms
                    For Each dbParm In colDbParm
                        ' Receive object, get parameter out
                        parm = cmd.Parameters.Add(dbParm.parmName, dbParm.parmType, dbParm.parmSize)
                        parm.Value = dbParm.parmValue
                        parm.Direction = dbParm.parmDirection
                    Next dbParm

                    ' Execute stored procedure
                    cmd.ExecuteNonQuery()
                Next dmlUnit
            Catch ex As InvalidOperationException
                ' Write error to window log
                Throw New DalException("SqlConnect.runStoredProc InvalidOperationException: " + ex.Source + " - " + sStoredProcedureName + ". Msg: " + ex.Message)
            Catch ex As SqlException
                Throw New DalException("SqlConnect.runStoredProc SqlException: " + ex.Source + " - " + sStoredProcedureName + ". Msg: " + ex.Message)
            Catch ex As Exception
                Throw New DalException("SqlConnect.runStoredProc Exception: " + ex.Source + " - " + sStoredProcedureName + ". Msg: " + ex.Message)
            Finally
                disconnect()
            End Try
        End Sub 'runStoredProc


        Public Sub runStoredProcWithTransaction(ByVal colSqlDml As SqlDmlCollection)
            ' Open database connection
            oSqlConnection.Open()

            ' Create command object
            Dim cmd As New SqlCommand

            ' Begin local transaction
            Dim sqlTransaction As sqlTransaction = oSqlConnection.BeginTransaction()
            cmd.Connection = oSqlConnection
            cmd.Transaction = sqlTransaction
            cmd.CommandTimeout = nCommandTimeout
            cmd.CommandType = CommandType.StoredProcedure

            Dim sqlParameter As sqlParameter

            Try
                Dim dmlUnit As dmlUnit
                For Each dmlUnit In colSqlDml
                    Dim sStoredProcedureName As String = dmlUnit.storedProcedureName
                    Dim colDbParm As DBParmCollection = dmlUnit.colDbParms

                    ' Build input parameters
                    Dim dbParms As dbParms
                    For Each dbParms In colDbParm
                        ' Receive object, get parameter out
                        sqlParameter = cmd.Parameters.Add(dbParms.parmName, dbParms.parmType, dbParms.parmSize)
                        sqlParameter.Value = dbParms.parmValue
                        sqlParameter.Direction = dbParms.parmDirection
                    Next dbParms

                    ' Define stored procedure to execute
                    cmd.CommandText = sStoredProcedureName

                    ' Execute stored procedure
                    cmd.ExecuteNonQuery()
                Next dmlUnit

                ' Commit transaction
                sqlTransaction.Commit()
            Catch ex As Exception
                Try
                    sqlTransaction.Rollback()
                Catch sqlException As sqlException
                    If Not (sqlTransaction Is Nothing) Then
                        Throw New Exception("An exception of type " + sqlException.GetType().ToString() + " was encountered while attempting to roll back the transaction.")
                    End If
                End Try

                Throw New DalException("SqlConnect.runStoredProc Exception: " + ex.Source + ", Msg: " + ex.Message)
            Finally
                disconnect()
            End Try
        End Sub 'runStoredProcWithTransaction 

        ' Begin class properties region
#Region "Class Properties"
        '/ <summary>
        '/ Class properties
        '/ </summary>

        Public Property dbConn() As String
            Get
                Return Me.sDbConn
            End Get
            Set(ByVal Value As String)
                Me.sDbConn = Value
            End Set
        End Property

        Public ReadOnly Property rowCount() As Long
            Get
                Return Me.rowCount
            End Get
        End Property
#End Region
    End Class 'SqlConnect 
End Namespace 'Contacts.DAL ' End Data class

USE [Contacts]
GO

/****** Object:  StoredProcedure [usp_CityRefLoadByPrimaryKey]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_CityRefLoadByPrimaryKey]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_CityRefLoadByPrimaryKey];
GO

CREATE PROCEDURE [usp_CityRefLoadByPrimaryKey]
(
	@ZipCode char(5)
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err int

	SELECT
		[CityName],
		[State],
		[ZipCode],
		[ZipPlus4],
		[FullZip]
	FROM [CityRef]
	WHERE
		([ZipCode] = @ZipCode)

	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_CityRefLoadByPrimaryKey Succeeded'
ELSE PRINT 'Procedure Creation: usp_CityRefLoadByPrimaryKey Error on Creation'
GO

/****** Object:  StoredProcedure [usp_CityRefLoadAll]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_CityRefLoadAll]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_CityRefLoadAll];
GO

CREATE PROCEDURE [usp_CityRefLoadAll]
AS
BEGIN

	SET NOCOUNT ON
	DECLARE @Err int

	SELECT
		[CityName],
		[State],
		[ZipCode],
		[ZipPlus4],
		[FullZip]
	FROM [CityRef]

	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_CityRefLoadAll Succeeded'
ELSE PRINT 'Procedure Creation: usp_CityRefLoadAll Error on Creation'
GO

/****** Object:  StoredProcedure [usp_CityRefUpdate]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_CityRefUpdate]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_CityRefUpdate];
GO

CREATE PROCEDURE [usp_CityRefUpdate]
(
	@CityName varchar(50),
	@State char(2),
	@ZipCode char(5),
	@ZipPlus4 char(4) = NULL,
	@FullZip varchar(10) = NULL output
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	UPDATE [CityRef]
	SET
		[CityName] = @CityName,
		[State] = @State,
		[ZipPlus4] = @ZipPlus4
	WHERE
		[ZipCode] = @ZipCode


	SET @Err = @@Error

    SELECT @FullZip = [FullZip]
      FROM [CityRef]
     WHERE [ZipCode] = @ZipCode


	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_CityRefUpdate Succeeded'
ELSE PRINT 'Procedure Creation: usp_CityRefUpdate Error on Creation'
GO




/****** Object:  StoredProcedure [usp_CityRefInsert]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_CityRefInsert]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_CityRefInsert];
GO

CREATE PROCEDURE [usp_CityRefInsert]
(
	@CityName varchar(50),
	@State char(2),
	@ZipCode char(5),
	@ZipPlus4 char(4) = NULL,
	@FullZip varchar(10) = NULL output
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	INSERT
	INTO [CityRef]
	(
		[CityName],
		[State],
		[ZipCode],
		[ZipPlus4]
	)
	VALUES
	(
		@CityName,
		@State,
		@ZipCode,
		@ZipPlus4
	)

	SET @Err = @@Error


    SELECT @FullZip = [FullZip]
      FROM [CityRef]
     WHERE [ZipCode] = @ZipCode

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_CityRefInsert Succeeded'
ELSE PRINT 'Procedure Creation: usp_CityRefInsert Error on Creation'
GO

/****** Object:  StoredProcedure [usp_CityRefDelete]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_CityRefDelete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_CityRefDelete];
GO

CREATE PROCEDURE [usp_CityRefDelete]
(
	@ZipCode char(5)
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	DELETE
	FROM [CityRef]
	WHERE
		[ZipCode] = @ZipCode
	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_CityRefDelete Succeeded'
ELSE PRINT 'Procedure Creation: usp_CityRefDelete Error on Creation'
GO

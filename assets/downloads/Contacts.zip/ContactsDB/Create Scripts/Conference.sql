
/****** Object:  StoredProcedure [usp_ConferenceLoadByPrimaryKey]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_ConferenceLoadByPrimaryKey]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_ConferenceLoadByPrimaryKey];
GO

CREATE PROCEDURE [usp_ConferenceLoadByPrimaryKey]
(
	@ConferenceId int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err int

	SELECT
		[ConferenceId],
		[LeagueId],
		[ConferenceName]
	FROM [Conference]
	WHERE
		([ConferenceId] = @ConferenceId)

	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_ConferenceLoadByPrimaryKey Succeeded'
ELSE PRINT 'Procedure Creation: usp_ConferenceLoadByPrimaryKey Error on Creation'
GO

/****** Object:  StoredProcedure [usp_ConferenceLoadAll]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_ConferenceLoadAll]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_ConferenceLoadAll];
GO

CREATE PROCEDURE [usp_ConferenceLoadAll]
AS
BEGIN

	SET NOCOUNT ON
	DECLARE @Err int

	SELECT
		[ConferenceId],
		[LeagueId],
		[ConferenceName]
	FROM [Conference]

	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_ConferenceLoadAll Succeeded'
ELSE PRINT 'Procedure Creation: usp_ConferenceLoadAll Error on Creation'
GO

/****** Object:  StoredProcedure [usp_ConferenceUpdate]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_ConferenceUpdate]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_ConferenceUpdate];
GO

CREATE PROCEDURE [usp_ConferenceUpdate]
(
	@ConferenceId int,
	@LeagueId int = NULL,
	@ConferenceName varchar(50) = NULL
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	UPDATE [Conference]
	SET
		[LeagueId] = @LeagueId,
		[ConferenceName] = @ConferenceName
	WHERE
		[ConferenceId] = @ConferenceId


	SET @Err = @@Error


	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_ConferenceUpdate Succeeded'
ELSE PRINT 'Procedure Creation: usp_ConferenceUpdate Error on Creation'
GO




/****** Object:  StoredProcedure [usp_ConferenceInsert]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_ConferenceInsert]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_ConferenceInsert];
GO

CREATE PROCEDURE [usp_ConferenceInsert]
(
	@ConferenceId int = NULL output,
	@LeagueId int = NULL,
	@ConferenceName varchar(50) = NULL
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	INSERT
	INTO [Conference]
	(
		[LeagueId],
		[ConferenceName]
	)
	VALUES
	(
		@LeagueId,
		@ConferenceName
	)

	SET @Err = @@Error

	SELECT @ConferenceId = SCOPE_IDENTITY()

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_ConferenceInsert Succeeded'
ELSE PRINT 'Procedure Creation: usp_ConferenceInsert Error on Creation'
GO

/****** Object:  StoredProcedure [usp_ConferenceDelete]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_ConferenceDelete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_ConferenceDelete];
GO

CREATE PROCEDURE [usp_ConferenceDelete]
(
	@ConferenceId int
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	DELETE
	FROM [Conference]
	WHERE
		[ConferenceId] = @ConferenceId
	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_ConferenceDelete Succeeded'
ELSE PRINT 'Procedure Creation: usp_ConferenceDelete Error on Creation'
GO

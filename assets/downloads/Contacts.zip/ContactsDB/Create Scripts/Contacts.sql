
/****** Object:  StoredProcedure [usp_ContactsLoadByPrimaryKey]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_ContactsLoadByPrimaryKey]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_ContactsLoadByPrimaryKey];
GO

CREATE PROCEDURE [usp_ContactsLoadByPrimaryKey]
(
	@ContactId int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err int

	SELECT
		[ContactId],
		[FirstName],
		[MiddleName],
		[LastName],
		[HomeNumber],
		[WorkNumber],
		[MobileNumber],
		[Email1],
		[Email2],
		[Email3],
		[Address1],
		[Address2],
		[CityName],
		[State],
		[ZipCode],
		[ZipPlus4],
		[TeamId]
	FROM [Contacts]
	WHERE
		([ContactId] = @ContactId)

	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_ContactsLoadByPrimaryKey Succeeded'
ELSE PRINT 'Procedure Creation: usp_ContactsLoadByPrimaryKey Error on Creation'
GO

/****** Object:  StoredProcedure [usp_ContactsLoadAll]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_ContactsLoadAll]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_ContactsLoadAll];
GO

CREATE PROCEDURE [usp_ContactsLoadAll]
AS
BEGIN

	SET NOCOUNT ON
	DECLARE @Err int

	SELECT
		[ContactId],
		[FirstName],
		[MiddleName],
		[LastName],
		[HomeNumber],
		[WorkNumber],
		[MobileNumber],
		[Email1],
		[Email2],
		[Email3],
		[Address1],
		[Address2],
		[CityName],
		[State],
		[ZipCode],
		[ZipPlus4],
		[TeamId]
	FROM [Contacts]

	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_ContactsLoadAll Succeeded'
ELSE PRINT 'Procedure Creation: usp_ContactsLoadAll Error on Creation'
GO

/****** Object:  StoredProcedure [usp_ContactsUpdate]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_ContactsUpdate]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_ContactsUpdate];
GO

CREATE PROCEDURE [usp_ContactsUpdate]
(
	@ContactId int,
	@FirstName varchar(255) = NULL,
	@MiddleName varchar(255) = NULL,
	@LastName varchar(255) = NULL,
	@HomeNumber char(13) = NULL,
	@WorkNumber char(13) = NULL,
	@MobileNumber char(13) = NULL,
	@Email1 varchar(255) = NULL,
	@Email2 varchar(255) = NULL,
	@Email3 varchar(255) = NULL,
	@Address1 varchar(255) = NULL,
	@Address2 varchar(255) = NULL,
	@CityName varchar(255) = NULL,
	@State char(2) = NULL,
	@ZipCode char(5) = NULL,
	@ZipPlus4 char(4) = NULL,
	@TeamId int = NULL
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	UPDATE [Contacts]
	SET
		[FirstName] = @FirstName,
		[MiddleName] = @MiddleName,
		[LastName] = @LastName,
		[HomeNumber] = @HomeNumber,
		[WorkNumber] = @WorkNumber,
		[MobileNumber] = @MobileNumber,
		[Email1] = @Email1,
		[Email2] = @Email2,
		[Email3] = @Email3,
		[Address1] = @Address1,
		[Address2] = @Address2,
		[CityName] = @CityName,
		[State] = @State,
		[ZipCode] = @ZipCode,
		[ZipPlus4] = @ZipPlus4,
		[TeamId] = @TeamId
	WHERE
		[ContactId] = @ContactId


	SET @Err = @@Error


	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_ContactsUpdate Succeeded'
ELSE PRINT 'Procedure Creation: usp_ContactsUpdate Error on Creation'
GO




/****** Object:  StoredProcedure [usp_ContactsInsert]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_ContactsInsert]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_ContactsInsert];
GO

CREATE PROCEDURE [usp_ContactsInsert]
(
	@ContactId int = NULL output,
	@FirstName varchar(255) = NULL,
	@MiddleName varchar(255) = NULL,
	@LastName varchar(255) = NULL,
	@HomeNumber char(13) = NULL,
	@WorkNumber char(13) = NULL,
	@MobileNumber char(13) = NULL,
	@Email1 varchar(255) = NULL,
	@Email2 varchar(255) = NULL,
	@Email3 varchar(255) = NULL,
	@Address1 varchar(255) = NULL,
	@Address2 varchar(255) = NULL,
	@CityName varchar(255) = NULL,
	@State char(2) = NULL,
	@ZipCode char(5) = NULL,
	@ZipPlus4 char(4) = NULL,
	@TeamId int = NULL
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	INSERT
	INTO [Contacts]
	(
		[FirstName],
		[MiddleName],
		[LastName],
		[HomeNumber],
		[WorkNumber],
		[MobileNumber],
		[Email1],
		[Email2],
		[Email3],
		[Address1],
		[Address2],
		[CityName],
		[State],
		[ZipCode],
		[ZipPlus4],
		[TeamId]
	)
	VALUES
	(
		@FirstName,
		@MiddleName,
		@LastName,
		@HomeNumber,
		@WorkNumber,
		@MobileNumber,
		@Email1,
		@Email2,
		@Email3,
		@Address1,
		@Address2,
		@CityName,
		@State,
		@ZipCode,
		@ZipPlus4,
		@TeamId
	)

	SET @Err = @@Error

	SELECT @ContactId = SCOPE_IDENTITY()

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_ContactsInsert Succeeded'
ELSE PRINT 'Procedure Creation: usp_ContactsInsert Error on Creation'
GO

/****** Object:  StoredProcedure [usp_ContactsDelete]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_ContactsDelete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_ContactsDelete];
GO

CREATE PROCEDURE [usp_ContactsDelete]
(
	@ContactId int
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	DELETE
	FROM [Contacts]
	WHERE
		[ContactId] = @ContactId
	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_ContactsDelete Succeeded'
ELSE PRINT 'Procedure Creation: usp_ContactsDelete Error on Creation'
GO

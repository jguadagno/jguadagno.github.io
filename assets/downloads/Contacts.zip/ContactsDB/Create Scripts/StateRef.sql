
/****** Object:  StoredProcedure [usp_StateRefLoadByPrimaryKey]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_StateRefLoadByPrimaryKey]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_StateRefLoadByPrimaryKey];
GO

CREATE PROCEDURE [usp_StateRefLoadByPrimaryKey]
(
	@State char(2)
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err int

	SELECT
		[State],
		[StateName]
	FROM [StateRef]
	WHERE
		([State] = @State)

	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_StateRefLoadByPrimaryKey Succeeded'
ELSE PRINT 'Procedure Creation: usp_StateRefLoadByPrimaryKey Error on Creation'
GO

/****** Object:  StoredProcedure [usp_StateRefLoadAll]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_StateRefLoadAll]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_StateRefLoadAll];
GO

CREATE PROCEDURE [usp_StateRefLoadAll]
AS
BEGIN

	SET NOCOUNT ON
	DECLARE @Err int

	SELECT
		[State],
		[StateName]
	FROM [StateRef]

	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_StateRefLoadAll Succeeded'
ELSE PRINT 'Procedure Creation: usp_StateRefLoadAll Error on Creation'
GO

/****** Object:  StoredProcedure [usp_StateRefUpdate]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_StateRefUpdate]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_StateRefUpdate];
GO

CREATE PROCEDURE [usp_StateRefUpdate]
(
	@State char(2),
	@StateName varchar(50)
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	UPDATE [StateRef]
	SET
		[StateName] = @StateName
	WHERE
		[State] = @State


	SET @Err = @@Error


	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_StateRefUpdate Succeeded'
ELSE PRINT 'Procedure Creation: usp_StateRefUpdate Error on Creation'
GO




/****** Object:  StoredProcedure [usp_StateRefInsert]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_StateRefInsert]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_StateRefInsert];
GO

CREATE PROCEDURE [usp_StateRefInsert]
(
	@State char(2),
	@StateName varchar(50)
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	INSERT
	INTO [StateRef]
	(
		[State],
		[StateName]
	)
	VALUES
	(
		@State,
		@StateName
	)

	SET @Err = @@Error


	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_StateRefInsert Succeeded'
ELSE PRINT 'Procedure Creation: usp_StateRefInsert Error on Creation'
GO

/****** Object:  StoredProcedure [usp_StateRefDelete]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_StateRefDelete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_StateRefDelete];
GO

CREATE PROCEDURE [usp_StateRefDelete]
(
	@State char(2)
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	DELETE
	FROM [StateRef]
	WHERE
		[State] = @State
	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_StateRefDelete Succeeded'
ELSE PRINT 'Procedure Creation: usp_StateRefDelete Error on Creation'
GO


/****** Object:  StoredProcedure [usp_TeamLoadByPrimaryKey]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_TeamLoadByPrimaryKey]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_TeamLoadByPrimaryKey];
GO

CREATE PROCEDURE [usp_TeamLoadByPrimaryKey]
(
	@TeamId int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err int

	SELECT
		[TeamId],
		[DivisionId],
		[TeamName]
	FROM [Team]
	WHERE
		([TeamId] = @TeamId)

	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_TeamLoadByPrimaryKey Succeeded'
ELSE PRINT 'Procedure Creation: usp_TeamLoadByPrimaryKey Error on Creation'
GO

/****** Object:  StoredProcedure [usp_TeamLoadAll]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_TeamLoadAll]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_TeamLoadAll];
GO

CREATE PROCEDURE [usp_TeamLoadAll]
AS
BEGIN

	SET NOCOUNT ON
	DECLARE @Err int

	SELECT
		[TeamId],
		[DivisionId],
		[TeamName]
	FROM [Team]

	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_TeamLoadAll Succeeded'
ELSE PRINT 'Procedure Creation: usp_TeamLoadAll Error on Creation'
GO

/****** Object:  StoredProcedure [usp_TeamUpdate]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_TeamUpdate]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_TeamUpdate];
GO

CREATE PROCEDURE [usp_TeamUpdate]
(
	@TeamId int,
	@DivisionId int = NULL,
	@TeamName varchar(50) = NULL
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	UPDATE [Team]
	SET
		[DivisionId] = @DivisionId,
		[TeamName] = @TeamName
	WHERE
		[TeamId] = @TeamId


	SET @Err = @@Error


	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_TeamUpdate Succeeded'
ELSE PRINT 'Procedure Creation: usp_TeamUpdate Error on Creation'
GO




/****** Object:  StoredProcedure [usp_TeamInsert]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_TeamInsert]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_TeamInsert];
GO

CREATE PROCEDURE [usp_TeamInsert]
(
	@TeamId int = NULL output,
	@DivisionId int = NULL,
	@TeamName varchar(50) = NULL
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	INSERT
	INTO [Team]
	(
		[DivisionId],
		[TeamName]
	)
	VALUES
	(
		@DivisionId,
		@TeamName
	)

	SET @Err = @@Error

	SELECT @TeamId = SCOPE_IDENTITY()

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_TeamInsert Succeeded'
ELSE PRINT 'Procedure Creation: usp_TeamInsert Error on Creation'
GO

/****** Object:  StoredProcedure [usp_TeamDelete]    Script Date: 4/26/2006 7:54:00 PM ******/
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[usp_TeamDelete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
    DROP PROCEDURE [usp_TeamDelete];
GO

CREATE PROCEDURE [usp_TeamDelete]
(
	@TeamId int
)
AS
BEGIN

	SET NOCOUNT OFF
	DECLARE @Err int

	DELETE
	FROM [Team]
	WHERE
		[TeamId] = @TeamId
	SET @Err = @@Error

	RETURN @Err
END
GO


-- Display the status of Proc creation
IF (@@Error = 0) PRINT 'Procedure Creation: usp_TeamDelete Succeeded'
ELSE PRINT 'Procedure Creation: usp_TeamDelete Error on Creation'
GO

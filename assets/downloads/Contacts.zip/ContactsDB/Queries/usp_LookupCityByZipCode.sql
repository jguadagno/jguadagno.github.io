IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'usp_LookupCityByZipCode')
	BEGIN
		PRINT 'Dropping Procedure usp_LookupCityByZipCode'
		DROP  Procedure  usp_LookupCityByZipCode
	END

GO

PRINT 'Creating Procedure usp_LookupCityByZipCode'
GO
CREATE Procedure usp_LookupCityByZipCode
	@ZipCode varchar(5)
AS

/******************************************************************************
**		File: 
**		Name: Stored_Procedure_Name
**		Desc: 
**
**		This template can be customized:
**              
**		Return values:
** 
**		Called by:   
**              
**		Parameters:
**		Input							Output
**     ----------							-----------
**
**		Auth: 
**		Date: 
*******************************************************************************
**		Change History
*******************************************************************************
**		Date:		Author:				Description:
**		--------		--------				-------------------------------------------
**    
*******************************************************************************/

SELECT DISTINCT(CityName) FROM CityRef
WHERE ZipCode Like @ZipCode


GO

GRANT EXEC ON usp_LookupCityByZipCode TO PUBLIC

GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'usp_GetCities')
	BEGIN
		PRINT 'Dropping Procedure usp_GetCities'
		DROP  Procedure  usp_GetCities
	END

GO

PRINT 'Creating Procedure usp_GetCities'
GO
CREATE Procedure usp_GetCities
	/* Param List */
AS

/******************************************************************************
**		File: 
**		Name: Stored_Procedure_Name
**		Desc: 
**
**		This template can be customized:
**              
**		Return values:
** 
**		Called by:   
**              
**		Parameters:
**		Input							Output
**     ----------							-----------
**
**		Auth: 
**		Date: 
*******************************************************************************
**		Change History
*******************************************************************************
**		Date:		Author:				Description:
**		--------		--------				-------------------------------------------
**    
*******************************************************************************/

SELECT * FROM CityRef



GO

GRANT EXEC ON usp_GetCities TO PUBLIC

GO

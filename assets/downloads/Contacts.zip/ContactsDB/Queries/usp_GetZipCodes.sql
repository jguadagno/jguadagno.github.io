IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'usp_GetZipCodes')
	BEGIN
		PRINT 'Dropping Procedure usp_GetZipCodes'
		DROP  Procedure  usp_GetZipCodes
	END

GO

PRINT 'Creating Procedure usp_GetZipCodes'
GO
CREATE Procedure usp_GetZipCodes
	/* Param List */
AS

/******************************************************************************
**		File: 
**		Name: Stored_Procedure_Name
**		Desc: 
**
**		This template can be customized:
**              
**		Return values:
** 
**		Called by:   
**              
**		Parameters:
**		Input							Output
**     ----------							-----------
**
**		Auth: 
**		Date: 
*******************************************************************************
**		Change History
*******************************************************************************
**		Date:		Author:				Description:
**		--------		--------				-------------------------------------------
**    
*******************************************************************************/

SELECT ZipCode FROM CityRef




GO

GRANT EXEC ON usp_GetZipCodes TO PUBLIC

GO

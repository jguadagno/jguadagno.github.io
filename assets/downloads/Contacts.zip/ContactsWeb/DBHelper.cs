using System;


namespace Utility
{
	/// <summary>
	/// Summary description for Utility.
	/// </summary>
	public class DBHelper
	{
		public DBHelper()
		{

		}

		public static string NotNullDBValue(string Invalue)
		{
			if (Invalue == null)
			{
				return "";
			}
			else
			{
				return Invalue;
			}
		}

		/// <summary>
		/// Adds a blank row to the passed DataTable
		/// </summary>
		/// <param name="dt">The DataTable to add the blank rows to</param>
		/// <returns></returns>
		public static System.Data.DataTable AddBlankRowsToTable(System.Data.DataTable dt)
		{
			// create the "dummy" record used to add blank rows
			string[] dummyData = new string[1];

			// Add and extra row
			dt.Rows.Add(dummyData);
			return dt;

		}
		public static System.Data.DataTable AddBlankRowsToTable(System.Data.DataTable dt, int NumberOfRowsToAdd)
		{
			for (int i = 1; i <= NumberOfRowsToAdd; i++)
			{
				dt = AddBlankRowsToTable(dt);
			}
										
			return dt;

		}


	}
}

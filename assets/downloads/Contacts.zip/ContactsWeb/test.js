function GetZipCodes()
{
	Contacts.Test.GetZipCodes(GetZipCodes_Callback)
}
function GetZipCodes_Callback(response)
{

  //if the server side code threw an exception
  if (response.error != null)
  {    
	DisplayError(msgTypeCritical, response.error, "GetZipCodes");
    return;
  }  
	
  var zipCodes = response.value;  
  //if the response wasn't what we expected  
  if (zipCodes == null || typeof(zipCodes) != "object")
  {
	var Message = "An unexpected error happened retrieving the teams list";
	DisplayError (msgTypeWarning, Message, "GetZipCodes");
  }
  
  var oControlList = zipCodes.Tables[0];
  
  oControl = getElem("ajaxZipCode");
  
  oControl.options.length = 0; //reset the zipCode dropdown    
  
  // Add a blank row
  // oControl.options[oControl.options.length] = new Option("", ""); 

  for (var i = 0; i < oControlList.Rows.length; ++i)
  {
    oControl.options[oControl.options.length] = new Option(oControlList.Rows[i].ZipCode, oControlList.Rows[i].ZipCode);       
  }  

}

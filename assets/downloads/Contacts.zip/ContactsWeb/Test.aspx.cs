using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Contacts
{
	/// <summary>
	/// Summary description for Test.
	/// </summary>
	public class Test : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DropDownList ddlGetCities;
		protected System.Web.UI.WebControls.DropDownList ddlGetStates;
		protected System.Web.UI.WebControls.DropDownList ddlGetZipCodes;
		protected System.Web.UI.WebControls.DropDownList ddlLookupCityByName;
		protected System.Web.UI.WebControls.DropDownList ddlLookupZipCodeByZipCode;
		protected System.Web.UI.WebControls.DropDownList ddlLookupStatesByState;
		protected System.Web.UI.WebControls.DropDownList ddlLookupStatesByStateName;
		protected System.Web.UI.WebControls.DropDownList ddlLookupCityByZipCode;
	
		private void Page_Load(object sender, System.EventArgs e)
		{

			// Need to register the ajax functions
			//AjaxPro.Utility.RegisterTypeForAjax(typeof(Namespace.class));
			AjaxPro.Utility.RegisterTypeForAjax(typeof(Contacts.Test));


			// Put user code to initialize the page here
			if (!Page.IsPostBack)
				LoadDropDownLists();
		}

		private void LoadDropDownLists()
		{

			Utility.utility.BindDataSet(PO.GetCities(),ddlGetCities, "CityName", "CityName");
			Utility.utility.BindDataSet(PO.GetStates(),ddlGetStates, "StateName", "State");
			Utility.utility.BindDataSet(PO.GetZipCodes(),ddlGetZipCodes, "ZipCode", "ZipCode");
			Utility.utility.BindDataSet(PO.LookupCityByName(),ddlLookupCityByName, "CityName", "CityName");
			Utility.utility.BindDataSet(PO.LookupCityByZipCode(),ddlLookupCityByZipCode, "CityName", "CityName");
			Utility.utility.BindDataSet(PO.LookupStatesByState(),ddlLookupStatesByState, "StateName", "State");
			Utility.utility.BindDataSet(PO.LookupStatesByStateName(),ddlLookupStatesByStateName, "StateName", "State");
			Utility.utility.BindDataSet(PO.LookupZipCodeByZipCode(),ddlLookupZipCodeByZipCode, "ZipCode", "ZipCode");

		}
		[AjaxPro.AjaxMethod()]
		public DataSet GetZipCodes()
		{
			return PO.GetZipCodes();
		}
		[AjaxPro.AjaxMethod()]
		public DataSet LookupZipCodeByZipCode(string ZipCode)
		{
			return PO.LookupZipCodeByZipCode(ZipCode);
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}

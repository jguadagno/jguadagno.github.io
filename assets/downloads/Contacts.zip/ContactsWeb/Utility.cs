using System;
using System.Web;
using System.Web.UI.WebControls;


namespace Utility
{
	/// <summary>
	/// Summary description for Utility.
	/// </summary>
	public class utility
	{
		public utility()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		/// <summary>
		/// Searchs the dropdownlist for the value passed
		/// </summary>
		/// <param name="dropdownList">The DropDownList to search for</param>
		/// <param name="SearchFor">The value to search for</param>
		public static void SelectComboboxItemByValue(System.Web.UI.WebControls.DropDownList dropdownList, string SearchFor)
		{
	
			ListItem ddItem;

			// Clear out any previous selections
			ddItem = dropdownList.Items.FindByValue(SearchFor);
			if (ddItem == null)
			{
				ListItem ddNewItem = new ListItem(SearchFor, SearchFor);
				dropdownList.Items.Add (ddNewItem);
				ddNewItem.Selected = true;
				ddNewItem = null;
			}
			else
			{
				ddItem.Selected = true;
			}

			ddItem = null;

		}

		/// <summary>
		/// Searchs the dropdownlist for the text passed
		/// </summary>
		/// <param name="dropdownList">The DropDownList to search for</param>
		/// <param name="SearchFor">The text value to search for</param>
		public static void SelectComboboxItemByText(System.Web.UI.WebControls.DropDownList dropdownList, string SearchFor)
		{
	
			ListItem ddItem;

			ddItem = dropdownList.Items.FindByText(SearchFor);
			if (ddItem == null)
			{
				ListItem ddNewItem = new ListItem(SearchFor, SearchFor);
				dropdownList.Items.Add (ddNewItem);
				ddNewItem.Selected = true;
				ddNewItem = null;
			}
			else
			{
				ddItem.Selected = true;
			}

			ddItem = null;
		}


		/// <summary>
		/// Binds the passed DataSet to the DropDownList
		/// </summary>
		/// <param name="ds">The DataSet</param>
		/// <param name="comboboxItem">The DropDownList to bind</param>
		/// <param name="textField">The column to bind the text to</param>
		public static void BindDataSet(System.Data.DataSet ds, System.Web.UI.WebControls.DropDownList comboboxItem, string textField)
		{
			BindDataSet(ds,comboboxItem, textField, textField);
		}


		/// <summary>
		/// Binds the passed DataSet to the DropDownList
		/// </summary>
		/// <param name="ds">The DataSet</param>
		/// <param name="comboboxItem">The DropDownList to bind</param>
		/// <param name="textField">The column to bind the text to</param>
		/// <param name="valueField">The column to bind the value to</param>
		public static void BindDataSet(System.Data.DataSet ds, 
				System.Web.UI.WebControls.DropDownList comboboxItem, 
				string textField,
				string valueField)
		{
			comboboxItem.DataSource = ds;
			comboboxItem.DataTextField= textField;
			comboboxItem.DataValueField = valueField;
			comboboxItem.DataBind();
		}
		public static string NotNullDBValue(string Invalue)
		{
			if (Invalue == null)
			{
				return "";
			}
			else
			{
				return Invalue;
			}
		}

		/// <summary>
		/// Adds a blank row to the passed DataTable
		/// </summary>
		/// <param name="dt">The DataTable to add the blank rows to</param>
		/// <returns></returns>
		public static System.Data.DataTable AddBlankRowsToTable(System.Data.DataTable dt)
		{
			// create the "dummy" record used to add blank rows
			string[] dummyData = new string[1];

			// Add and extra row
			dt.Rows.Add(dummyData);
			return dt;

		}
		public static System.Data.DataTable AddBlankRowsToTable(System.Data.DataTable dt, int NumberOfRowsToAdd)
		{
			for (int i = 1; i <= NumberOfRowsToAdd; i++)
			{
				dt = AddBlankRowsToTable(dt);
			}
										
			return dt;

		}

		#region ControlOnOrOff
		/// <summary>
		/// Enables or disables a control with a standard look
		/// </summary>
		/// <param name="controlIn">The System.Web.UI.WebControls.Textbox control to set the attributes for.</param>
		/// <param name="OnOrOff">True indicates the control is enabled, false indicates it is disabled.</param>
		public static void ControlOnOrOff(System.Web.UI.WebControls.TextBox controlIn, bool OnOrOff)
		{
			if (OnOrOff == true)
			{
				controlIn.BackColor = System.Drawing.Color.White;
				controlIn.ReadOnly = false;
			}
			else
			{
				controlIn.BackColor = System.Drawing.Color.Gainsboro;
				controlIn.ReadOnly = true;
			}
		}

		/// <summary>
		/// Enables or disables a control with a standard look
		/// </summary>
		/// <param name="controlIn">The System.Web.UI.WebControls.Label control to set the attributes for.</param>
		/// <param name="OnOrOff">True indicates the control is enabled, false indicates it is disabled.</param>
		public static void ControlOnOrOff(System.Web.UI.WebControls.Label controlIn, bool OnOrOff)
		{
			if (OnOrOff == true)
			{
				controlIn.BackColor = System.Drawing.Color.White;
				controlIn.Enabled = true;
			}
			else
			{
				controlIn.BackColor = System.Drawing.Color.Gainsboro;
				controlIn.Enabled = false;
			}
		}

		/// <summary>
		/// Enables or disables a control with a standard look
		/// </summary>
		/// <param name="controlIn">The System.Web.UI.WebControls.DropDownList control to set the attributes for.</param>
		/// <param name="OnOrOff">True indicates the control is enabled, false indicates it is disabled.</param>
		public static void ControlOnOrOff(System.Web.UI.WebControls.DropDownList controlIn, bool OnOrOff)
		{
			if (OnOrOff == true)
			{
				controlIn.BackColor = System.Drawing.Color.White;
				controlIn.Enabled = true;
			}
			else
			{
				controlIn.BackColor = System.Drawing.Color.Gainsboro;
				controlIn.Enabled = false;
			}
		}

		/// <summary>
		/// Enables or disables a control with a standard look
		/// </summary>
		/// <param name="controlIn">The System.Web.UI.HtmlInputButton control to set the attributes for.</param>
		/// <param name="OnOrOff">True indicates the control is enabled, false indicates it is disabled.</param>
		public static void ControlOnOrOff(System.Web.UI.HtmlControls.HtmlInputButton controlIn, bool OnOrOff)
		{
			if (OnOrOff == true)
			{
				controlIn.Disabled = false;
			}
			else
			{
				controlIn.Disabled = true;
			}
		}
		#endregion
	}
}

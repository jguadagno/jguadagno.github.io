using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Contacts
{
	/// <summary>
	/// This page adds search functionality to the contact.
	/// </summary>
	public class Sample8_Keydown : System.Web.UI.Page
	{
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			AjaxPro.Utility.RegisterTypeForAjax(typeof(Contacts.Sample8_Keydown));
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		[AjaxPro.AjaxMethod()]
		public Contacts.Contact ReturnClass(int ContactId)
		{
			return Contacts.Contact.Load(ContactId);
		}

		[AjaxPro.AjaxMethod()]
		public string SaveContact(Contacts.Contact oContact)
		{
			return oContact.Save();
		}

		#region Search
		[AjaxPro.AjaxMethod()]
		public DataSet NameSearch(string FirstName, string LastName)
		{

			return Contacts.BusinessLayer.FindContactByName(FirstName, LastName);
		}

		[AjaxPro.AjaxMethod()]
		public DataSet Search(string SearchString)
		{
			return Contacts.BusinessLayer.FindContact(SearchString);
		}

		#endregion

		#region DropDownList Methods

		[AjaxPro.AjaxMethod()]
		public System.Web.UI.HtmlControls.HtmlSelect GetLeagues(string selectedItem)
		{
		
			System.Web.UI.HtmlControls.HtmlSelect dropdown = new HtmlSelect();
			
			DataSet ds = Sport.LoadLeagues();
			Utility.utility.AddBlankRowsToTable(ds.Tables[0]);
			dropdown.Items.Clear();
			dropdown.ID = "ddlLeague";
			foreach (DataRow dr in ds.Tables[0].Rows)
			{
				System.Web.UI.WebControls.ListItem oItem = new System.Web.UI.WebControls.ListItem();
				oItem.Text = dr["LeagueName"].ToString().Trim();
				oItem.Value = dr["LeagueId"].ToString().Trim();
				oItem.Selected = (dr["LeagueId"].ToString().Trim() == selectedItem.Trim());
				dropdown.Items.Add(oItem);
			}
			dropdown.Attributes["onchange"] = "LeagueClicked(this);";
			ds = null;
			return dropdown;
		}

		[AjaxPro.AjaxMethod()]
		public System.Web.UI.HtmlControls.HtmlSelect GetConferencesByLeague(
			string selectedItem,
			string LeagueId)
		{
		
			System.Web.UI.HtmlControls.HtmlSelect dropdown = new HtmlSelect();
			
			DataSet ds = Sport.LoadConferenceByLeague(int.Parse(LeagueId));
			Utility.utility.AddBlankRowsToTable(ds.Tables[0]);
			dropdown.Items.Clear();
			dropdown.ID = "ddlConference";
			foreach (DataRow dr in ds.Tables[0].Rows)
			{
				System.Web.UI.WebControls.ListItem oItem = new System.Web.UI.WebControls.ListItem();
				oItem.Text = dr["ConferenceName"].ToString().Trim();
				oItem.Value = dr["ConferenceId"].ToString().Trim();
				oItem.Selected = (dr["ConferenceId"].ToString().Trim() == selectedItem.Trim());
				dropdown.Items.Add(oItem);
			}
			dropdown.Attributes["onchange"] = "ConferenceClicked(this);";
			ds = null;
			return dropdown;
		}

		[AjaxPro.AjaxMethod()]
		public System.Web.UI.HtmlControls.HtmlSelect GetDivisionsByConference(
			string selectedItem,
			string ConferenceId)
		{
		
			System.Web.UI.HtmlControls.HtmlSelect dropdown = new HtmlSelect();
			
			DataSet ds = Sport.LoadDivisionsByConference(int.Parse(ConferenceId));
			Utility.utility.AddBlankRowsToTable(ds.Tables[0]);
			dropdown.Items.Clear();
			dropdown.ID = "ddlDivision";
			foreach (DataRow dr in ds.Tables[0].Rows)
			{
				System.Web.UI.WebControls.ListItem oItem = new System.Web.UI.WebControls.ListItem();
				oItem.Text = dr["DivisionName"].ToString().Trim();
				oItem.Value = dr["DivisionId"].ToString().Trim();
				oItem.Selected = (dr["DivisionId"].ToString().Trim() == selectedItem.Trim());
				dropdown.Items.Add(oItem);
			}
			dropdown.Attributes["onchange"] = "DivisionClicked(this);";
			ds = null;
			return dropdown;
		}

		[AjaxPro.AjaxMethod()]
		public System.Web.UI.HtmlControls.HtmlSelect GetTeamsByDivision(
			string selectedItem,
			string divisionId)
		{
		
			System.Web.UI.HtmlControls.HtmlSelect dropdown = new HtmlSelect();
			
			DataSet ds = Sport.LoadTeamsByDivision(int.Parse(divisionId));
			Utility.utility.AddBlankRowsToTable(ds.Tables[0]);
			dropdown.Items.Clear();
			dropdown.ID = "ddlTeam";
			foreach (DataRow dr in ds.Tables[0].Rows)
			{
				System.Web.UI.WebControls.ListItem oItem = new System.Web.UI.WebControls.ListItem();
				oItem.Text = dr["TeamName"].ToString().Trim();
				oItem.Value = dr["TeamId"].ToString().Trim();
				oItem.Selected = (dr["TeamId"].ToString().Trim() == selectedItem.Trim());
				dropdown.Items.Add(oItem);
			}
			dropdown.Attributes["onchange"] = "TeamClicked(this);";
			ds = null;
			return dropdown;
		}


		#endregion
	}

}

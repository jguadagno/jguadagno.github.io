
 ///////////////////////////
//Start Timer Class
///////////////////////////
var internalTimer;
Timer = function(delegate, interval, cycles){
    this.delegate = delegate;
    this.interval = interval;
    this.cycles = (isNaN(cycles)) ? null : cycles;
    this.currentCycle = 0;
    internalTimer = this;
}
Timer.prototype = {
    Stop: function(){
        clearInterval(this.intervalId);
    },
    Start: function(){
        this.intervalId = setInterval("Timer._cycle()",this.interval);
    },
    _cycle: function(){
        if(this.cycles == null || this.currentCycle < this.cycles){
            this.delegate();
        }else{
            this.Stop();
        }
        this.currentCycle++;
    }
}
Timer._cycle = function(){
    internalTimer._cycle();
}
///////////////////////////
//End Timer Class
///////////////////////////
//is the custom action code you should write to your own needs.
TimerElapsed = function(){
    var table = document.getElementById('userTable');
    var visible = (table.style.visibility == 'visible') ? true : false;
    table.style.visibility = (visible == true) ? 'hidden' : 'visible';
    table.style.display = (visible == true) ? 'none' : 'block';
}

var tableTimer = new Timer(TimerElapsed, 1000, 5);
tableTimer.Start();


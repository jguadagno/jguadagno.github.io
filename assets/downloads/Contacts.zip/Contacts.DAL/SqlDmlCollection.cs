using System;
using System.Collections;

namespace Contacts.DAL {
	/// <summary>
	/// Summary description for colDbParmCollection.
	/// </summary>
	public class SqlDmlCollection : System.Collections.CollectionBase 	{
		public SqlDmlCollection() {}

		public void addSqlDml(string sStoredProcedureName, DBParmCollection dbParmCollection) {
			// Declare DmlUnit object
			DmlUnit dmlUnit = new DmlUnit(sStoredProcedureName, dbParmCollection);

			this.List.Add(dmlUnit);
		}
	}
}

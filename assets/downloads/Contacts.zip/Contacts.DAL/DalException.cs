using System;
using System.Configuration;
using System.IO;

namespace Contacts.DAL {
	/// <summary>
	/// Summary description for DalException.
	/// </summary>
	public class DalException : System.ApplicationException {
		// Declare class variables
		const string sModule = "DalException";
		string sMsg = string.Empty;
		string sLogDate = System.DateTime.Now.ToShortDateString() + " " + System.DateTime.Now.ToShortTimeString();

		public DalException() {}

		// Raise own custom exception
		public DalException(string sMsg) : base(sMsg) {
			this.sMsg = sMsg;
		}

	}
}

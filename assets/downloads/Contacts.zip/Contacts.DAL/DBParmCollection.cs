using System;
using System.Collections;

namespace Contacts.DAL {
	/// <summary>
	/// Summary description for DBParmCollection.
	/// </summary>
	public class DBParmCollection : System.Collections.CollectionBase {
		public DBParmCollection() {}

		/// <summary>
		/// Adding DB Parm object to collection list
		/// </summary>
		/// <param name="oDBParms"></param>
		public void add (DBParms oDBParms) {
			this.List.Add (oDBParms);
		}

		#region
		public DBParms this [int nIndex] {
			get {
				return (DBParms)(this.List[nIndex]);
			}
			set {
				this.List[nIndex] = value;
			}
		}
		#endregion
	}	// End DBParmCollection class
}

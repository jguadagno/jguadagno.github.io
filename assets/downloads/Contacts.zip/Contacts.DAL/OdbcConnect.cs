using System;

namespace Contacts.DAL
{
	/// <summary>
	/// Summary description for OdbcConnect.
	/// </summary>
	public class OdbcConnect
	{
		public OdbcConnect()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}

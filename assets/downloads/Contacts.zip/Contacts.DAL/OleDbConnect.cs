using System;
using System.Data;
using System.Data.OleDb;

namespace Contacts.DAL {
	/// <summary>
	/// Summary description for OleDbConnect.
	/// </summary>
	public class OleDbConnect {
		enum CONNECTION_TYPE {
			SQL_SERVER = 1,
			EXCEL = 2,
			ACCESS = 3
		};

		private string sDbConnection = string.Empty;
		private OleDbConnection oleDbConnection;

		public OleDbConnect(string sDbConnection, int nConnectionType, string sServerName, string sDbName) {
			if (nConnectionType == (int)CONNECTION_TYPE.EXCEL) {
				if (sDbConnection.IndexOf(".xls") > 0) {
					sDbConnection = @"Provider=Microsoft.Jet.OLEDB.4.0;Extended Properties=Excel 8.0;Data Source=" + sDbConnection;
				} else {
					throw new Exception("Invalid Microsoft Excel file extension - " + sDbConnection);
				}
			} else if (nConnectionType == (int)CONNECTION_TYPE.ACCESS) {
				if (sDbConnection.IndexOf(".mdb") > 0) {
					sDbConnection = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + sDbConnection;
				} else {
					throw new Exception("Invalid Microsoft Access file extension - " + sDbConnection);
				}
			} else {
				sDbConnection = @"Provider=SQLOLEDB;Data Source=" + sServerName + ";Initial Catalog=" + sDbName + ";Integrated Security=SSPI;";

			}

			connect();

		}

		private void connect() {
			oleDbConnection = new OleDbConnection(sDbConnection);
		}

		public DataSet dataSetGen(string sSqlSyntax) {
			return new DataSet();
		
		}

		private void disconnect() {
			oleDbConnection.Close();
			oleDbConnection.Dispose();
			oleDbConnection = null;
		}

		/// <summary>
		/// Generate dataset from stored procedure without parameter
		/// </summary>
		/// <param name="sSpName"></param>
		/// <returns></returns>
		public DataSet datasetGenDirect(String sTableName) {
			DataSet dset = new DataSet();
			OleDbDataAdapter dad = new OleDbDataAdapter();
			OleDbCommand cmd;

			try {
				cmd = new OleDbCommand(sTableName, oleDbConnection);
				cmd.CommandType = CommandType.TableDirect;

				dad.SelectCommand = cmd;
				dad.Fill (dset);
			} catch (Exception ex) {
				throw(new DalException("OleDbConnect.datasetGenDirect: " + ex.Source + " - " + sTableName + ". Msg: " + ex.Message));				
			}

			disconnect();

			return dset;
		}
	}
}

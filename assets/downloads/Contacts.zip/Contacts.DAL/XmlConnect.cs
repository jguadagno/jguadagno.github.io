using System;
using System.Data;
using System.IO;
using System.Xml;

namespace Contacts.DAL {
	/// <summary>
	/// Summary description for XmlConnect.
	/// </summary>
	public class XmlConnect {
		public XmlConnect() 	{}

		public DataSet dataSetGen(string sXmlFilePath) {
			DataSet dst = null;

			// Check existance of Xml file
			if (File.Exists(sXmlFilePath)) {
				dst = new DataSet();
				dst.ReadXml(sXmlFilePath);
			} else {
				// Raise exception if file not found
				throw new DalException(sXmlFilePath + " not found!");
			}
		
			return dst;		
		}

		public DataSet dataSetGen(string sXmlFilePath, string sDataSetName) {
			DataSet dst = new DataSet(sDataSetName);
			dst.ReadXml(sXmlFilePath);	
	
			return dst;		
		}

	}
}

using System;

namespace Contacts.DAL
{
	/// <summary>
	/// Summary description for OracleConnect.
	/// </summary>
	public class OracleConnect
	{
		public OracleConnect()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}

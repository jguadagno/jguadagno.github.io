using System;

namespace Contacts.DAL {
	/// <summary>
	/// Summary description for DmlUnit.
	/// </summary>
	public class DmlUnit {
		private string _sStoredProcName = string.Empty;
		private DBParmCollection _dbParmCollection = null;

		public DmlUnit() {}

		public DmlUnit(string sStoredProcedureName, DBParmCollection dbParmCollection) {
			_sStoredProcName = sStoredProcedureName;
			_dbParmCollection = dbParmCollection;
		}

		public string storedProcedureName {get{return _sStoredProcName;} set{_sStoredProcName = value;}}
		public DBParmCollection colDbParms {get {return _dbParmCollection;} set{_dbParmCollection = value;}}
	}
}

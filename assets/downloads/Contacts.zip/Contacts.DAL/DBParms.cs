using System;
using System.Data;
using System.Data.SqlClient;

namespace Contacts.DAL {
	/// <summary>
	/// List of database parameters
	/// </summary>
	public class DBParms {
		private String sParmName;
		private object oParmValue;
		private SqlDbType oParmType;
		private ParameterDirection oParmDirection;
		private int nParmSize;

		public DBParms () {}

		/// <summary>
		/// Add new parameter
		/// </summary>
		/// <param name="sParmName"></param>
		/// <param name="sParmValue"></param>
		/// <param name="sParmType"></param>
		public DBParms (String sParmName, object oParmValue, SqlDbType oParmType, ParameterDirection oParmDirection, int nParmSize) {
			this.sParmName = sParmName;
			this.oParmValue = oParmValue;
			this.oParmType = oParmType;
			this.oParmDirection = oParmDirection;
			this.nParmSize = nParmSize;
		}

		/// <summary>
		/// Add new parameter
		/// </summary>
		/// <param name="sParmName"></param>
		/// <param name="sParmValue"></param>
		/// <param name="sParmType"></param>
		public DBParms (String sParmName, object oParmValue, SqlDbType oParmType, ParameterDirection oParmDirection) {
			this.sParmName = sParmName;
			this.oParmValue = oParmValue;
			this.oParmType = oParmType;
			this.oParmDirection = oParmDirection;
		}

		/// <summary>
		/// Add new parameter
		/// </summary>
		/// <param name="sParmName"></param>
		/// <param name="sParmValue"></param>
		/// <param name="sParmType"></param>
		public DBParms (String sParmName, object oParmValue, SqlDbType oParmType) {
			this.sParmName = sParmName;
			this.oParmValue = oParmValue;
			this.oParmType = oParmType;
		}

		/// <summary>
		/// Add new parameter
		/// </summary>
		/// <param name="sParmName"></param>
		/// <param name="sParmValue"></param>
		public DBParms (String sParmName, object oParmValue) {
			this.sParmName = sParmName;
			this.oParmValue = oParmValue;
		}

		#region
		public String parmName {get {return sParmName;}}
		public object parmValue {get {return oParmValue;}}
		public SqlDbType parmType {get {return oParmType;}}
		public ParameterDirection parmDirection {get{return oParmDirection;}}
		public int parmSize {get{return nParmSize;}}
		#endregion
}
}

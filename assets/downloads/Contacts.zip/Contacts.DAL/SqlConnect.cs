using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using intel.general;

namespace Contacts.DAL {
	/// <summary>
	/// Connection to database using native sql connection classes
	/// </summary>
	public class SqlConnect {
		private String sDbConn;
		private SqlConnection oSqlConnection;
		private int nCommandTimeout = 300;		// default command time out to 30 seconds

		/// <summary>
		/// Instantiate data object with connection string from web.config
		/// </summary>
		public SqlConnection getSqlConnection()
		{
			return oSqlConnection;
		}

		public void closeSqlConnection()
		{
			disconnect();
		}

		public SqlConnect () {
			// Get connection string
			bool bIsEncryptOn = (ConfigurationSettings.AppSettings["encrypt_connection"] != null) ? Boolean.Parse(ConfigurationSettings.AppSettings["encrypt_connection"]) : false;

			if (bIsEncryptOn) {
				string sEncryptKey = ConfigurationSettings.AppSettings["db_connection"];
				this.sDbConn = new Encryption().DecryptData("dbconn", sEncryptKey);
			} else {
				string sConnectionString = ConfigurationSettings.AppSettings["db_connection"];
				this.dbConn = sConnectionString;
			}

			// Make database connection
			connect();
		}

		/// <summary>
		/// Using database connection other then default one from web.config
		/// </summary>
		/// <param name="sDbConn">Database connection string</param>
		public SqlConnect (String sDbConn) {
			// Get connection string, must be SQL Server!!!
			this.sDbConn = sDbConn;

			// Make database connection
			connect();
		}

		/// <summary>
		/// Set command timeout for default connection
		/// </summary>
		/// <param name="nCommandTimeout"></param>
		public SqlConnect(int nCommandTimeout) {
			this.nCommandTimeout = nCommandTimeout;

			// Make database connection
			connect();
		}

		public SqlConnect(String sDbConn, int nCommandTimeout) {
			this.sDbConn = sDbConn;
			this.nCommandTimeout = nCommandTimeout;

			// Make database connection
			connect();
		}

		/// <summary>
		/// Make connection to database
		/// </summary>
		private void connect() {
			if ((sDbConn == null) || (sDbConn.Equals(string.Empty))) {
				throw (new DalException("No connection string setup"));
			} else {
				oSqlConnection = new SqlConnection (sDbConn);
			}
		}

		/// <summary>
		/// Destroy connection
		/// </summary>
		private void disconnect() {
			oSqlConnection.Close();
			oSqlConnection.Dispose();
		}

		/// <summary>
		/// Generate dataset from stored procedure without parameter
		/// </summary>
		/// <param name="sSpName"></param>
		/// <returns></returns>
		public DataSet datasetGen(String sSpName) {
			DataSet dset = new DataSet();
			SqlDataAdapter dad = new SqlDataAdapter();
			SqlCommand cmd;

			try {
				cmd = new SqlCommand (sSpName, oSqlConnection);
				cmd.CommandTimeout = nCommandTimeout;
				cmd.CommandType = CommandType.StoredProcedure;

				dad.SelectCommand = cmd;
				dad.Fill (dset);
			} catch (Exception ex) {
				throw(new DalException("SqlConnect.dataSetGen: " + ex.Source + " - " + sSpName + ". Msg: " + ex.Message));				
			}

			disconnect();

			return dset;
		}

		/// <summary>
		/// Generate dataset with defined table name
		/// </summary>
		/// <param name="arlSpName">Arraylist of stored procedures</param>
		/// <param name="arlTbl">Arraylist of Tables</param>
		/// <returns>Dataset</returns>
		public DataSet datasetGen(ArrayList arlSpName, ArrayList arlTbl) {
			DataSet dset = new DataSet();
			SqlDataAdapter dad = new SqlDataAdapter();
			SqlCommand cmd;
			int nIndex = 0;

			try {
				for (nIndex = 0; nIndex < arlSpName.Count; nIndex++) {
					cmd = new SqlCommand (arlSpName[nIndex].ToString(), oSqlConnection);
					cmd.CommandTimeout = nCommandTimeout;
					cmd.CommandType = CommandType.StoredProcedure;

					dad.SelectCommand = cmd;
					dad.Fill (dset, arlTbl[nIndex].ToString());
				}
			} catch (Exception ex) {
				throw new DalException("Data.dataSetGen: " + ex.Source + " - " + arlSpName[nIndex] + ". Msg: " + ex.Message);				
			}

			disconnect();

			return dset;
		}

		/// <summary>
		/// Generate dataset with defined table name
		/// </summary>
		/// <param name="arlSpName">Arraylist of stored procedures</param>
		/// <param name="arlTbl">Arraylist of Tables</param>
		/// <returns>Dataset</returns>
		public DataSet datasetGen(ArrayList arlSpName, ArrayList arlTbl, DBParmCollection oParmCollection) {
			DataSet dset = new DataSet();
			SqlDataAdapter dad = new SqlDataAdapter();
			SqlCommand cmd;
			SqlParameter parm;
			int nIndex = 0;

			try {
				for (nIndex = 0; nIndex < arlSpName.Count; nIndex++) {
					cmd = new SqlCommand (arlSpName[nIndex].ToString(), oSqlConnection);
					cmd.CommandTimeout = nCommandTimeout;
					cmd.CommandType = CommandType.StoredProcedure;

					// Build input parameters
					foreach (DBParms item in oParmCollection) {
						// Only passdown input parameter
						if (item.parmDirection == ParameterDirection.Input) {
							// Receive object, get parameter out
							parm = cmd.Parameters.Add(item.parmName, item.parmType, item.parmSize);
							parm.Value = item.parmValue;
							parm.Direction = item.parmDirection;
						}
					}

					dad.SelectCommand = cmd;
					dad.Fill (dset, arlTbl[nIndex].ToString());
				}
			} catch (Exception ex) {
				throw new DalException(("SqlConnect.dataSetGen: " + ex.Source + " - " + arlSpName[nIndex] + ". Msg: " + ex.Message));				
			}

			disconnect();

			return dset;
		}

		/// <summary>
		/// Generate dataset with defined table name
		/// </summary>
		/// <param name="sSpName"></param>
		/// <param name="sTableName"></param>
		/// <returns></returns>
		public DataSet datasetGen(String sSpName, String sTableName) {
			DataSet dset = new DataSet();
			SqlDataAdapter dad = new SqlDataAdapter();
			SqlCommand cmd;

			try {
				cmd = new SqlCommand (sSpName, oSqlConnection);
				cmd.CommandType = CommandType.StoredProcedure;

				dad.SelectCommand = cmd;
				dad.Fill (dset, sTableName);
			} catch (Exception ex) {
				throw new DalException("SqlConnect.dataSetGen: " + ex.Source + " - " + sSpName + ".  Msg: " + ex.Message);				
			}

			disconnect();

			return dset;
		}

		/// <summary>
		/// Generate data set
		/// </summary>
		/// <param name="sSpName">Stored procedure name</param>
		/// <param name="sTableName">Table name</param>
		/// <param name="oParmCollection">Parameters collection</param>
		/// <returns>Dataset</returns>
		public DataSet datasetGen(String sSpName, String sTableName, DBParmCollection oParmCollection) {
			DataSet dset = new DataSet();
			SqlDataAdapter dad = new SqlDataAdapter();
			SqlCommand cmd;
			SqlParameter parm;

			try {
				cmd = new SqlCommand (sSpName, oSqlConnection);
				cmd.CommandTimeout = nCommandTimeout;
				cmd.CommandType = CommandType.StoredProcedure;

				// Build input parameters
				foreach (DBParms item in oParmCollection) {
					// Only passdown input parameter
					if (item.parmDirection == ParameterDirection.Input) {
						// Receive object, get parameter out
						parm = cmd.Parameters.Add(item.parmName, item.parmType, item.parmSize);
						parm.Value = item.parmValue;
						parm.Direction = item.parmDirection;
					}
				}

				dad.SelectCommand = cmd;
				dad.Fill (dset, sTableName);
			} catch (Exception ex) {
				throw new DalException("SqlConnect.dataSetGen: " + ex.Source + " - " + sSpName + ".  Msg: " + ex.Message);					}

			disconnect();

			return dset;
		}

		/// <summary>
		/// Generate dataset from stored procedure without parameter
		/// </summary>
		/// <param name="sSpName"></param>
		/// <returns></returns>
		public DataSet datasetGen(String sSpName, DBParmCollection oParmCollection) {
			DataSet dset = new DataSet();
			SqlDataAdapter dad = new SqlDataAdapter();
			SqlCommand cmd;
			SqlParameter parm;

			try {
				cmd = new SqlCommand (sSpName, oSqlConnection);
				cmd.CommandTimeout = nCommandTimeout;
				cmd.CommandType = CommandType.StoredProcedure;

				// Build input parameters
				foreach (DBParms item in oParmCollection) {
					// Only passdown input parameter
					if (item.parmDirection == ParameterDirection.Input) {
						// Receive object, get parameter out
						parm = cmd.Parameters.Add(item.parmName, item.parmType, item.parmSize);
						parm.Value = item.parmValue;
						parm.Direction = item.parmDirection;
					}
				}

				dad.SelectCommand = cmd;
				dad.Fill (dset);
			} catch (Exception ex) {
				throw new DalException("SqlConnection.dataSetGen: " + ex.Source + " - " + sSpName + ". Msg: " + ex.Message);					}

			disconnect();

			return dset;
		}

		/// <summary>
		/// Run stored procedure without parameter
		/// </summary>
		/// <param name="sSpName"></param>
		/// <returns></returns>
		public DataSet executeQuery (String sSql) {
			DataSet dset = new DataSet();
			SqlDataAdapter dad = new SqlDataAdapter();
			try 
			{
				// Create command object
				SqlCommand cmd = new SqlCommand (sSql, oSqlConnection);
				cmd.CommandTimeout = nCommandTimeout;
				cmd.CommandType = CommandType.Text;

				// Open database connection
				oSqlConnection.Open();

				dad.SelectCommand = cmd;
				dad.Fill (dset);
			} catch (InvalidOperationException ex) {
				// Write error to window log
				throw new DalException("SqlConnect.executeQuery InvalidOperationException: " + ex.Source + " - " + sSql + " - " + ex.Message);
			} catch (SqlException ex) {
				throw new DalException("SqlConnect.executeQuery SqlException: " + ex.Source + " - " + sSql + " - " + ex.Message);
			} catch (Exception ex) {
				throw new DalException("SqlConnect.executeQuery Exception: " + ex.Source + " - " + sSql + " - " + ex.Message);
			}

			// Disconnect connection
			disconnect();

			return dset;
		}

		public int executeQueryWithInt (String sSql) 
		{
			int nRowCount = 0;

			try 
			{
				// Create command object
				SqlCommand cmd = new SqlCommand (sSql, oSqlConnection);
				cmd.CommandTimeout = nCommandTimeout;
				cmd.CommandType = CommandType.Text;

				// Open database connection
				oSqlConnection.Open();

				// Execute stored procedure
				nRowCount = (int)cmd.ExecuteScalar();
			} 
			catch (InvalidOperationException ex) 
			{
				// Write error to window log
				throw new DalException("SqlConnect.executeQuery InvalidOperationException: " + ex.Source + " - " + sSql + " - " + ex.Message);
			} 
			catch (SqlException ex) 
			{
				throw new DalException("SqlConnect.executeQuery SqlException: " + ex.Source + " - " + sSql + " - " + ex.Message);
			} 
			catch (Exception ex) 
			{
				throw new DalException("SqlConnect.executeQuery Exception: " + ex.Source + " - " + sSql + " - " + ex.Message);
			}

			// Disconnect connection
			disconnect();

			return nRowCount;
		}

		public int runStoredProc (String sSpName) 
		{

			int nRowCount = 0;

			try 
			{

				// Create command object
				SqlCommand cmd = new SqlCommand (sSpName, oSqlConnection);
				cmd.CommandTimeout = nCommandTimeout;
				cmd.CommandType = CommandType.StoredProcedure;

				SqlParameter parm = cmd.Parameters.Add ("return_value", SqlDbType.Int);
				parm.Direction = ParameterDirection.ReturnValue;

				// Open database connection
				oSqlConnection.Open();

				// Execute stored procedure
				cmd.ExecuteNonQuery();

				// Obtain return count
				nRowCount = Convert.ToInt32(cmd.Parameters["return_value"].Value.ToString());
			} 
			catch (InvalidOperationException ex) 
			{


				// Write error to window log
				throw new DalException("SqlConnect.runStoredProc InvalidOperationException: " + ex.Source + " - " + sSpName + " - " + ex.Message);
			} 
			catch (SqlException ex) 
			{


				throw new DalException("SqlConnect.runStoredProc SqlException: " + ex.Source + " - " + sSpName + " - " + ex.Message);
			} 
			catch (Exception ex) 
			{


				throw new DalException("SqlConnect.runStoredProc Exception: " + ex.Source + " - " + sSpName + " - " + ex.Message);
			}

			// Disconnect connection
			disconnect();

			return nRowCount;
		}


		public int runStoredProc (String sSpName, DBParmCollection oParmCollection) 
		{

			int nRowCount = 0;

			try 
			{
				// Create command object
				SqlCommand cmd = new SqlCommand (sSpName, oSqlConnection);
				cmd.CommandTimeout = nCommandTimeout;
				cmd.CommandType = CommandType.StoredProcedure;

				// Obtain return parameter
				SqlParameter parm = cmd.Parameters.Add ("return_value", SqlDbType.Int);
				parm.Direction = ParameterDirection.ReturnValue;

				// Build input parameters
				foreach (DBParms item in oParmCollection) 
				{
					if (item.parmValue.Equals(System.DBNull.Value)) 
					{
						parm = cmd.Parameters.Add(item.parmName, item.parmType);
						parm.Value = System.DBNull.Value;
					} 
					else 
					{
						// Receive object, get parameter out
						parm = cmd.Parameters.Add(item.parmName, item.parmType, item.parmSize);
						parm.Value = item.parmValue;
						parm.Direction = item.parmDirection;
					}
				}

				// Open database connection
				oSqlConnection.Open();

				// Execute stored procedure
				cmd.ExecuteNonQuery();

				// Obtain return count
				nRowCount = Convert.ToInt32(cmd.Parameters["return_value"].Value.ToString());
			} 
			catch (InvalidOperationException ex) 
			{
				// Write error to window log
				throw new DalException("SqlConnect.runStoredProc InvalidOperationException: " + ex.Source + " - " + sSpName + ". Msg: " + ex.Message);
			} 
			catch (SqlException ex) 
			{
				throw new DalException("SqlConnect.runStoredProc SqlException: " + ex.Source + " - " + sSpName + ". Msg: " + ex.Message);
			} 
			catch (Exception ex) 
			{
				throw new DalException("SqlConnect.runStoredProc Exception: " + ex.Source + " - " + sSpName + ". Msg: " + ex.Message);
			}

			return nRowCount;
		}


		public int runStoredProc (String sSpName, DBParmCollection oParmCollection, Hashtable htbl) 
		{
			int nRowCount = 0;

			try 
			{
				// Create command object
				SqlCommand cmd = new SqlCommand (sSpName, oSqlConnection);
				cmd.CommandTimeout = nCommandTimeout;
				cmd.CommandType = CommandType.StoredProcedure;

				// Obtain return parameter
				SqlParameter parm = cmd.Parameters.Add ("return_value", SqlDbType.Int);
				parm.Direction = ParameterDirection.ReturnValue;

				// Build input parameters
				foreach (DBParms item in oParmCollection) 
				{
					// Receive object, get parameter out
					parm = cmd.Parameters.Add(item.parmName, item.parmType, item.parmSize);
					parm.Value = item.parmValue;
					parm.Direction = item.parmDirection;
				}

				// Open database connection
				oSqlConnection.Open();

				// Execute stored procedure
				cmd.ExecuteNonQuery();

				// Obtain return count
				nRowCount = Convert.ToInt32(cmd.Parameters["return_value"].Value.ToString());

				// Obtain output parameter
				foreach (DBParms item in oParmCollection) 
				{
					if (item.parmDirection == ParameterDirection.Output) 
					{
						htbl.Add (item.parmName, cmd.Parameters[item.parmName].Value.ToString());
					}
				}
			} 
			catch (InvalidOperationException ex) 
			{
				// Write error to window log
				throw new DalException("SqlConnect.runStoredProc InvalidOperationException: " + ex.Source + " - " + sSpName + ". Msg: " + ex.Message);
			} 
			catch (SqlException ex) 
			{
				throw new DalException("SqlConnect.runStoredProc SqlException: " + ex.Source + " - " + sSpName + ". Msg: " + ex.Message);
			} 
			catch (Exception ex) 
			{
				throw new DalException("SqlConnect.runStoredProc Exception: " + ex.Source + " - " + sSpName + ". Msg: " + ex.Message);
			}

			return nRowCount;
		}


		/// <summary>
		/// Execute multiple line of SQL syntax with one connection
		/// </summary>
		/// <param name="colSqlDml">Collection of SqlDml object</param>
		/// <returns></returns>
		public void runStoredProc(SqlDmlCollection colSqlDml) {
			string sStoredProcedureName = string.Empty;
			SqlParameter parm;

			try {
				// Open database connection
				oSqlConnection.Open();

				foreach(DmlUnit dmlUnit in colSqlDml) {
					sStoredProcedureName = dmlUnit.storedProcedureName;
					DBParmCollection colDbParm = dmlUnit.colDbParms;
	
					// Execute stored procedure
					SqlCommand cmd = new SqlCommand (sStoredProcedureName, oSqlConnection);
					cmd.CommandTimeout = nCommandTimeout;
					cmd.CommandType = CommandType.StoredProcedure;

					// Build input parameters
					foreach (DBParms dbParm in colDbParm) {
						// Receive object, get parameter out
						parm = cmd.Parameters.Add(dbParm.parmName, dbParm.parmType, dbParm.parmSize);
						parm.Value = dbParm.parmValue;
						parm.Direction = dbParm.parmDirection;
					}

					// Execute stored procedure
					cmd.ExecuteNonQuery();
				}
			} catch (InvalidOperationException ex) {
				// Write error to window log
				throw new DalException("SqlConnect.runStoredProc InvalidOperationException: " + ex.Source + " - " + sStoredProcedureName + ". Msg: " + ex.Message);
			} catch (SqlException ex) {
				throw new DalException("SqlConnect.runStoredProc SqlException: " + ex.Source + " - " + sStoredProcedureName + ". Msg: " + ex.Message);
			} catch (Exception ex) {
				throw new DalException("SqlConnect.runStoredProc Exception: " + ex.Source + " - " + sStoredProcedureName + ". Msg: " + ex.Message);
			} finally {
				disconnect();
			}
		}

		public void runStoredProcWithTransaction(SqlDmlCollection colSqlDml) {
			// Open database connection
			oSqlConnection.Open();

			// Create command object
			SqlCommand cmd = new SqlCommand ();

			// Begin local transaction
			SqlTransaction sqlTransaction = oSqlConnection.BeginTransaction();
			cmd.Connection = oSqlConnection;
			cmd.Transaction = sqlTransaction;
			cmd.CommandTimeout = nCommandTimeout;
			cmd.CommandType = CommandType.StoredProcedure;

			SqlParameter sqlParameter;

			try {
				foreach(DmlUnit dmlUnit in colSqlDml) {
					string sStoredProcedureName = dmlUnit.storedProcedureName;
					DBParmCollection colDbParm = dmlUnit.colDbParms;
	
					// Build input parameters
					foreach (DBParms dbParms in colDbParm) {
						// Receive object, get parameter out
						sqlParameter = cmd.Parameters.Add(dbParms.parmName, dbParms.parmType, dbParms.parmSize);
						sqlParameter.Value = dbParms.parmValue;
						sqlParameter.Direction = dbParms.parmDirection;
					}

					// Define stored procedure to execute
					cmd.CommandText = sStoredProcedureName;

					// Execute stored procedure
					cmd.ExecuteNonQuery();
				}

				// Commit transaction
				sqlTransaction.Commit();
			} catch (Exception ex) {
				try {
					sqlTransaction.Rollback();
				} catch (SqlException sqlException) {
					if (sqlTransaction != null) {
						throw new Exception("An exception of type " + sqlException.GetType() + " was encountered while attempting to roll back the transaction.");
					}
				}

				throw new DalException("SqlConnect.runStoredProc Exception: " + ex.Source + ", Msg: " + ex.Message);
			} finally {
				disconnect();
			}

		}

		// Begin class properties region
		#region Class Properties
		/// <summary>
		/// Class properties
		/// </summary>
		public String dbConn {set{this.sDbConn = value;} get {return this.sDbConn;}}
		public long rowCount {get {return this.rowCount;}}
		#endregion

	}	// End Data class
}

using System;
using System.Data;
using System.Data.SqlClient;
using Contacts.DAL;

namespace Contacts
{
	/// <summary>
	/// Contains information about the contact
	/// </summary>
	public class Contact
	{
		#region Public Contructors
		public Contact()
		{

		}
		public Contact(
			int ContactId,
			string FirstName,
			string MiddleName,
			string LastName,
			string HomeNumber,
			string WorkNumber,
			string MobileNumber,
			string Email1,
			string Email2,
			string Email3,
			string Address1,
			string Address2,
			string CityName, 
			string State, 
			string ZipCode, 
			string ZipPlus4,
			int TeamId
			)
		{
			_ContactId = ContactId;
			_FirstName = FirstName;
			_MiddleName = MiddleName;
			_LastName = LastName;
			_HomeNumber = HomeNumber;
			_WorkNumber = WorkNumber;
			_MobileNumber = MobileNumber;
			_Email1 = Email1;
			_Email2 = Email2;
			_Email3 = Email3;
			_Address1 = Address1;
			_Address2 = Address2;
			_CityName = CityName;
			_State = State;
			_ZipCode = ZipCode;
			_ZipPlus4 = ZipPlus4;
			_Team = Team.Load(TeamId);
			_IsDirty = true;
		}
		#endregion

		public const string resultOK = "OK";
		public const string resultFailed = "Failed";

		#region Private Properties

		private int _ContactId;
		private string _FirstName;
		private string _MiddleName;
		private string _LastName;
		private string _HomeNumber;
		private string _WorkNumber;
		private string _MobileNumber;
		private string _Email1;
		private string _Email2;
		private string _Email3;
		private string _Address1;
		private string _Address2;
		private string _CityName;
		private string _State;
		private string _ZipCode;
		private string _ZipPlus4;
		private Team _Team;
		private bool _IsDirty;

		#endregion

		#region Public Properties

		/// <summary>
		/// The unique identifier for the contact
		/// </summary>
		public int ContactId
		{
			get {return _ContactId;}
			set 
			{
				_ContactId = value;
				_IsDirty = true;}
		}

		/// <summary>
		/// The first name of the contact
		/// </summary>
		public string FirstName
		{
			get {return _FirstName;}
			set 
			{
				_IsDirty = true;
				_FirstName = value;}
		}

		/// <summary>
		/// The middle name of the contact
		/// </summary>
		public string MiddleName
		{
			get {return _MiddleName;}
			set 
			{
				_IsDirty = true;
				_MiddleName = value;}
		}
		
		/// <summary>
		/// The last name of the client
		/// </summary>
		public string LastName
		{
			get {return _LastName;}
			set 
			{
				_IsDirty = true;
				_LastName = value;}
		}
		
		/// <summary>
		/// The home number of the contact
		/// </summary>
		public string HomeNumber
		{
			get {return _HomeNumber;}
			set 
			{
				_IsDirty = true;
				_HomeNumber = value;}
		}

		/// <summary>
		/// The work number for the contact
		/// </summary>
		public string WorkNumber
		{
			get {return _WorkNumber;}
			set 
			{
				_IsDirty = true;
				_WorkNumber = value;}
		}
		
		/// <summary>
		/// The mobile number for the contact
		/// </summary>
		public string MobileNumber
		{
			get {return _MobileNumber;}
			set 
			{
				_IsDirty = true;
				_MobileNumber = value;}
		}
		
		/// <summary>
		/// Email address 1 for the contact
		/// </summary>
		public string Email1
		{
			get {return _Email1;}
			set 
			{
				_IsDirty = true;
				_Email1 = value;}
		}
		
		/// <summary>
		/// Email address 2 for the contact
		/// </summary>
		public string Email2
		{
			get {return _Email2;}
			set 
			{
				_IsDirty = true;
				_Email2 = value;}
		}
		
		/// <summary>
		/// Email address 3 for the contact
		/// </summary>
		public string Email3
		{
			get {return _Email3;}
			set 
			{
				_IsDirty = true;
				_Email3 = value;}
		}
		/// <summary>
		/// The address 1 for the contact
		/// </summary>
		public string Address1
		{
			get {return _Address1;}
			set 
			{
				_IsDirty = true;
				_Address1 = value;}
		}
		/// <summary>
		/// The address 2 for the contact
		/// </summary>
		public string Address2
		{
			get {return _Address2;}
			set 
			{
				_IsDirty = true;
				_Address2 = value;}
		}
		/// <summary>
		/// The ciy name for the contact
		/// </summary>
		public string CityName
		{
			get {return _CityName;}
			set 
			{
				_IsDirty = true;
				_CityName = value;}
		}
		/// <summary>
		/// The state of the contact
		/// </summary>
		public string State
		{
			get {return _State;}
			set 
			{
				_IsDirty = true;
				_State = value;}
		}
		/// <summary>
		/// The Zip Code of the address
		/// </summary>
		public string ZipCode
		{
			get {return _ZipCode;}
			set 
			{
				_IsDirty = true;
				_ZipCode = value;}
		}
		/// <summary>
		/// The Zip Plus 4 code for the address
		/// </summary>
		public string ZipPlus4
		{
			get {return _ZipPlus4;}
			set 
			{
				_IsDirty = true;
				_ZipPlus4 = value;
			}
		}
		/// <summary>
		/// The contacts favorite team.
		/// </summary>
		public Team Team
		{
			get {return _Team;}
			set
			{
				_IsDirty = true;
				_Team = value;
			}
		}
		/// <summary>
		/// Indicates if the contact has changed since it has been last saved or loaded
		/// </summary>
		public bool IsDirty
		{
			get {return _IsDirty;}
		}
		#endregion

		#region Public Methods

		#region Load
		/// <summary>
		/// Loads the contact information from the database
		/// </summary>
		/// <param name="ContactId">The contact id to load</param>
		/// <returns>A Contacts.Contact class</returns>
		public static Contacts.Contact Load (int ContactId)
		{
			
			DataSet dsContact = GetDataSet(ContactId);

			Contacts.Contact oContact = new Contact();

			foreach(DataRow dr in dsContact.Tables[0].Rows)
			{
				
				oContact.ContactId = (int) dr["ContactId"];
				oContact.FirstName = dr["FirstName"].ToString();
				oContact.MiddleName = dr["MiddleName"].ToString();
				oContact.LastName = dr["LastName"].ToString();
				oContact.HomeNumber = dr["HomeNumber"].ToString();
				oContact.WorkNumber = dr["WorkNumber"].ToString();
				oContact.MobileNumber = dr["MobileNumber"].ToString();
				oContact.Email1 = dr["Email1"].ToString();
				oContact.Email2 = dr["Email2"].ToString();
				oContact.Email3 = dr["Email3"].ToString();
				oContact.Address1 = dr["Address1"].ToString();
				oContact.Address2 = dr["Address2"].ToString();
				oContact.CityName = dr["CityName"].ToString();
				oContact.State = dr["State"].ToString();
				oContact.ZipCode = dr["ZipCode"].ToString();
				oContact.ZipPlus4 = dr["ZipPlus4"].ToString();
				if (dr["TeamId"].GetType() != typeof(System.DBNull))
					oContact.Team = Team.Load((int) dr["TeamId"]);
				
			}

			return oContact;

		}

		#endregion

		#region GetDataSet
		/// <summary>
		/// Gets a DataSet for the specified ContactId
		/// </summary>
		/// <param name="ContactId">The contact to retrieve</param>
		/// <returns></returns>
		public static System.Data.DataSet GetDataSet(int ContactId)
		{
			DBParmCollection dbparms = new DBParmCollection();
			dbparms.add(new DBParms("@ContactId", ContactId, SqlDbType.Int, ParameterDirection.Input));

			return new SqlConnect().datasetGen("usp_ContactsLoadByPrimaryKey", dbparms);

		}
		#endregion

		#region Save
		public string Save()
		{
			string returnResult = resultFailed;
			
			SqlTransaction myTrans;
			SqlConnection myConnection;

			myConnection = new Contacts.DAL.SqlConnect().getSqlConnection();
			myConnection.Open();
			myTrans = myConnection.BeginTransaction();
			
			returnResult = Save(myTrans);

			myTrans.Commit();
			
			// Clean up
			myTrans = null;
			myConnection.Close();
			myConnection = null;
			return returnResult;

		}

		public string Save(SqlTransaction myTrans)
		{
			string returnResult = resultFailed;
			SqlCommand myCommand;

			if (_IsDirty == false)
				return resultOK;

			try
			{
				#region Save Records

				if (_ContactId == 0)
				{
					myCommand = new SqlCommand("usp_ContactsInsert", myTrans.Connection, myTrans);
					SqlParameter parm = new SqlParameter("@ContactId", SqlDbType.Int,4);
					parm.Direction = ParameterDirection.Output;
					myCommand.Parameters.Add(parm);
					parm = null;
				}
				else
				{
					myCommand = new SqlCommand("usp_ContactsUpdate", myTrans.Connection, myTrans);
					SqlParameter parm = new SqlParameter("@ContactId", SqlDbType.Int, 4);
					parm.Value = _ContactId;
					myCommand.Parameters.Add(parm);
					parm = null;
				}
				// Set up the parameters
				myCommand.CommandType = CommandType.StoredProcedure;
				// work with the parameters

				myCommand.Parameters.Add(new SqlParameter("@FirstName", _FirstName));
				myCommand.Parameters.Add(new SqlParameter("@LastName", _LastName));
				myCommand.Parameters.Add(new SqlParameter("@MiddleName", _MiddleName));
				myCommand.Parameters.Add(new SqlParameter("@HomeNumber", _HomeNumber));
				myCommand.Parameters.Add(new SqlParameter("@MobileNumber", _MobileNumber));
				myCommand.Parameters.Add(new SqlParameter("@WorkNumber", _WorkNumber));
				myCommand.Parameters.Add(new SqlParameter("@Email1", _Email1));
				myCommand.Parameters.Add(new SqlParameter("@Email2", _Email2));
				myCommand.Parameters.Add(new SqlParameter("@Email3", _Email3));
				myCommand.Parameters.Add(new SqlParameter("@Address1", _Address1));
				myCommand.Parameters.Add(new SqlParameter("@Address2", _Address2));
				myCommand.Parameters.Add(new SqlParameter("@CityName", _CityName));
				myCommand.Parameters.Add(new SqlParameter("@State", _State));
				myCommand.Parameters.Add(new SqlParameter("@ZipCode", _ZipCode));
				myCommand.Parameters.Add(new SqlParameter("@ZipPlus4", _ZipPlus4));
				if (_Team != null)
					myCommand.Parameters.Add(new SqlParameter("@TeamId", _Team.TeamId));

				myCommand.ExecuteNonQuery();
				_ContactId = (int) myCommand.Parameters["@ContactId"].Value;
				_IsDirty = false;

				returnResult = resultOK;
				#endregion

			}
			catch  (Exception ex)
			{
				returnResult = ex.ToString();
			}
			finally
			{
				myCommand = null;

			}

			return returnResult;

		}
		#endregion

		#endregion

	}

	
}

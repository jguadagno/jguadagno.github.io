using System;
using System.Data;
using System.Data.SqlClient;
using Contacts.DAL;

namespace Contacts
{
	/// <summary>
	/// Summary description for Sport.
	/// </summary>
	public class Sport
	{
		public Sport()
		{
		}
		#region Public Static Methods
		public static DataSet LoadLeagues()
		{
			return new SqlConnect().datasetGen("usp_LeagueLoadAll");
		}

		public static DataSet LoadConferences()
		{
			return new SqlConnect().datasetGen("usp_ConferenceLoadAll");
		}

		public static DataSet LoadDivisions()
		{
			return new SqlConnect().datasetGen("usp_DivisionLoadAll");
		}

		public static DataSet LoadTeams()
		{
			return new SqlConnect().datasetGen("usp_TeamLoadAll");
		}
		public static DataSet LoadConferenceByLeague(int LeagueId)
		{
			DBParmCollection dbparms = new DBParmCollection();
			dbparms.add(new DBParms("@LeagueId", LeagueId, SqlDbType.Int, ParameterDirection.Input));

			return new SqlConnect().datasetGen("usp_GetConferenceForLeague", dbparms);

		}
		public static DataSet LoadDivisionsByConference(int ConferenceId)
		{
			DBParmCollection dbparms = new DBParmCollection();
			dbparms.add(new DBParms("@ConferenceId", ConferenceId, SqlDbType.Int, ParameterDirection.Input));

			return new SqlConnect().datasetGen("usp_GetDivisionForConference", dbparms);

		}
		public static DataSet LoadTeamsByDivision(int DivisionId)
		{
			DBParmCollection dbparms = new DBParmCollection();
			dbparms.add(new DBParms("@DivisionId", DivisionId, SqlDbType.Int, ParameterDirection.Input));

			return new SqlConnect().datasetGen("usp_GetTeamForDivision", dbparms);

		}

		#endregion
	}
}

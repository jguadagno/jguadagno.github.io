using System;
using System.Data;
using System.Data.SqlClient;
using Contacts.DAL;

namespace Contacts
{
	/// <summary>
	/// Summary description for Team.
	/// </summary>
	public class Team
	{
		public Team()
		{
		}

		public int LeagueId;
		public string LeagueName;
		public int ConferenceId;
		public string ConferenceName;
		public int DivisionId;
		public string DivisionName;
		public int TeamId;
		public string TeamName;

		#region Load
		/// <summary>
		/// Loads the specified team
		/// </summary>
		/// <param name="TeamId">The team to load</param>
		/// <returns></returns>
		public static Contacts.Team Load (int TeamId)
		{
			
			DataSet dsTeam = GetDataSet(TeamId);

			Contacts.Team oTeam = new Team();

			foreach(DataRow dr in dsTeam.Tables[0].Rows)
			{
				oTeam.LeagueId = (int) dr["LeagueId"];
				oTeam.LeagueName = dr["LeagueName"].ToString();
				oTeam.ConferenceId = (int) dr["ConferenceId"];
				oTeam.ConferenceName = dr["ConferenceName"].ToString();
				oTeam.DivisionId = (int) dr["DivisionId"];
				oTeam.DivisionName = dr["DivisionName"].ToString();
				oTeam.TeamId = (int) dr["TeamId"];
				oTeam.TeamName = dr["TeamName"].ToString();
			}

			return oTeam;

		}

		#endregion

		#region GetDataSet
		/// <summary>
		/// Gets a DataSet for the specified ContactId
		/// </summary>
		/// <param name="TeamId">The team to retrieve</param>
		/// <returns></returns>
		public static System.Data.DataSet GetDataSet(int TeamId)
		{
			DBParmCollection dbparms = new DBParmCollection();
			dbparms.add(new DBParms("@TeamId", TeamId, SqlDbType.Int, ParameterDirection.Input));

			return new SqlConnect().datasetGen("usp_GetTeamInformation", dbparms);

		}
		#endregion

	}

}

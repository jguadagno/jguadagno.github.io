using System;
using System.Data;
using Contacts.DAL;

namespace Contacts
{
	/// <summary>
	/// Business Layer for the contacts library
	/// </summary>
	public class BusinessLayer
	{
		public BusinessLayer()
		{


		}
		/// <summary>
		/// Find a contact by first name
		/// </summary>
		/// <param name="FirstName"></param>
		/// <returns></returns>
		public static DataSet FindContactByName(string FirstName)
		{
			string sFirstName = '%' + FirstName + '%';

			return FindContactByName(sFirstName, '%'.ToString());
		}

		/// <summary>
		/// Searches for a contact by partial first name, and partial last name
		/// </summary>
		/// <param name="FirstName">The first name to search for</param>
		/// <param name="LastName">The last name to search for</param>
		/// <returns></returns>
		public static DataSet FindContactByName(string FirstName, string LastName)
		{
			// usp_SearchForContactInformation	
			FirstName = "%" + FirstName + "%";
			LastName = "%" + LastName + "%";
			DBParmCollection oDBParms = new DBParmCollection();
			oDBParms.add(new DBParms("@FirstName", FirstName, SqlDbType.Char,ParameterDirection.Input));
			oDBParms.add(new DBParms("@LastName", LastName, SqlDbType.Char,ParameterDirection.Input));
			
			return new SqlConnect().datasetGen("usp_SearchForContactInformation", oDBParms);


		}
		/// <summary>
		/// Searches contact information. Search email (1,2,3), first, middle, last names
		/// </summary>
		/// <param name="search">Any search string</param>
		/// <returns></returns>
		public static DataSet FindContact(string SearchString)
		{

			// usp_SearchForContactInformationAll
			SearchString = "%" + SearchString + "%";
			DBParmCollection oDBParms = new DBParmCollection();
			oDBParms.add(new DBParms("@SearchString", SearchString, SqlDbType.Char,ParameterDirection.Input));
			
			return new SqlConnect().datasetGen("usp_SearchForContactInformationAll", oDBParms);
		}


	}
	/// <summary>
	/// Post Office Lookup functions
	/// </summary>
	public class PO
	{
		public PO()
		{

		}

		public static DataSet GetCities()
		{
			return new SqlConnect().datasetGen("usp_GetCities");
		}
		public static DataSet GetStates()
		{
			return new SqlConnect().datasetGen("usp_GetStates");
		}
		public static DataSet GetZipCodes()
		{
			return new SqlConnect().datasetGen("usp_GetZipCodes");
		}

		public static DataSet LookupCityByName()
		{
			return LookupCityByName("");
		}
		public static DataSet LookupCityByName(string CityName)
		{
			CityName = CityName + "%";

			DBParmCollection oDBParms = new DBParmCollection();
			oDBParms.add(new DBParms("@CityName", CityName, SqlDbType.Char,ParameterDirection.Input));
			
			return new SqlConnect().datasetGen("usp_LookupCityByName", oDBParms);
		}

		public static DataSet LookupCityByZipCode()
		{
			return LookupCityByZipCode("");
		}
		public static DataSet LookupCityByZipCode(string ZipCode)
		{
			ZipCode = ZipCode + "%";

			DBParmCollection oDBParms = new DBParmCollection();
			oDBParms.add(new DBParms("@ZipCode", ZipCode, SqlDbType.Char,ParameterDirection.Input));
			
			return new SqlConnect().datasetGen("usp_LookupCityByZipCode", oDBParms);			
		}
		
		public static DataSet LookupStatesByState()
		{
			return LookupStatesByState("");
		}
		public static DataSet LookupStatesByState(string State)
		{
			State = State + "%";

			DBParmCollection oDBParms = new DBParmCollection();
			oDBParms.add(new DBParms("@State", State, SqlDbType.Char,ParameterDirection.Input));
			
			return new SqlConnect().datasetGen("usp_LookupStatesByState", oDBParms);
		}
		public static DataSet LookupStatesByStateName()
		{
			return LookupStatesByStateName("");
		}
		public static DataSet LookupStatesByStateName(string StateName)
		{
			StateName = StateName + "%";

			DBParmCollection oDBParms = new DBParmCollection();
			oDBParms.add(new DBParms("@StateName", StateName, SqlDbType.Char,ParameterDirection.Input));
			
			return new SqlConnect().datasetGen("usp_LookupStatesByStateName", oDBParms);
		}
		public static DataSet LookupZipCodeByZipCode()
		{
			return LookupZipCodeByZipCode("");
		}
		public static DataSet LookupZipCodeByZipCode(string ZipCode)
		{
			ZipCode = ZipCode + "%";

			DBParmCollection oDBParms = new DBParmCollection();
			oDBParms.add(new DBParms("@ZipCode", ZipCode, SqlDbType.Char,ParameterDirection.Input));
			
			return new SqlConnect().datasetGen("usp_LookupZipCodeByZipCode", oDBParms);
		}

	}
}
